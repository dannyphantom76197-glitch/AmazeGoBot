import com.example.amazegobot.ManualMoveCore;
import java.util.Arrays;

/** Runs on desktop with javac; no Android SDK required. */
public final class ManualMoveCoreTest {
    private static final int BG=0xfff6eddf, BLUE=0xff226bf4, GREEN=0xff06af3c, ORANGE=0xffff8a10;
    private static final int W=260,H=180;
    private static int[] empty(){int[] a=new int[W*H];Arrays.fill(a,BG);return a;}
    private static void pixel(int[] a,int x,int y,int color){a[y*W+x]=color;}
    private static void rectOutline(int[] a,int x0,int y0,int x1,int y1,int color){
        for(int x=x0;x<=x1;x++)for(int t=-1;t<=1;t++){
            pixel(a,x,y0+t,color);pixel(a,x,y1+t,color);
        }
        for(int y=y0;y<=y1;y++)for(int t=-1;t<=1;t++){
            pixel(a,x0+t,y,color);pixel(a,x1+t,y,color);
        }
    }
    private static void assertTrue(boolean truth,String why){if(!truth)throw new AssertionError(why);}
    public static void main(String[] args){
        int[] before=empty(),after=empty();
        // A hollow BLUE moving outline surrounds separately stationary GREEN and ORANGE ink.
        // Interior is not the moving arrow's occupied footprint.
        rectOutline(before,45,35,205,135,BLUE);
        for(int y=65;y<=102;y++){
            for(int x=94;x<=96;x++)pixel(before,x,y,ORANGE);
            for(int x=154;x<=156;x++)pixel(before,x,y,GREEN);
        }
        after=before.clone();
        for(int y=0;y<H;y++)for(int x=0;x<W;x++)if(before[y*W+x]==BLUE)after[y*W+x]=BG;
        int[] roi={10,10,245,165};
        ManualMoveCore.Result r=ManualMoveCore.compare(before,after,W,H,roi);
        assertTrue(r.plausibleSingleRemoval(),"missing blue outline should look like one ink removal: "+r.summary());
        assertTrue(r.removed>700,"blue outline missing; should count its pixels only");
        assertTrue(r.added==0,"no new ink after outline disappears");
        assertTrue(r.retained>=220,"enclosed stationary arrow ink should remain");
        assertTrue(r.retainedInsideLargest>=220,"stationary ink inside hollow region should be recognized");
        assertTrue(r.largestBounds[0]<=45&&r.largestBounds[2]>=206,"region bbox spans the outer shape");
        System.out.println("PASS: hollow outline disappears while inner ink remains: "+r.summary());

        ManualMoveCore.Result same=ManualMoveCore.compare(before,before,W,H,roi);
        assertTrue(same.removed==0&&same.added==0&&!same.plausibleSingleRemoval(),"unchanged board not move");
        System.out.println("PASS: unchanged frame does not look like move");

        int[] afterAddition=before.clone();
        rectOutline(afterAddition,18,18,26,26,ORANGE);
        ManualMoveCore.Result addition=ManualMoveCore.compare(before,afterAddition,W,H,roi);
        assertTrue(addition.removed==0&&addition.added>10&&!addition.plausibleSingleRemoval(),"added ink not removal");
        System.out.println("PASS: new ink not mistaken for a departing arrow");

        int[] recolored=before.clone();
        for(int i=0;i<before.length;i++)if(before[i]==BLUE)recolored[i]=ORANGE;
        ManualMoveCore.Result recolor=ManualMoveCore.compare(before,recolored,W,H,roi);
        assertTrue(recolor.added>700&&recolor.removed>700&&!recolor.plausibleSingleRemoval(),
            "blue-to-orange recolor should not be classified as a disappearing arrow");
        System.out.println("PASS: color replacement counted as both vanished and new ink");

        int[] uiOnly=before.clone();for(int x=10;x<180;x++)pixel(uiOnly,x,2,BLUE);
        ManualMoveCore.Result ui=ManualMoveCore.compare(before,uiOnly,W,H,roi);
        assertTrue(ui.removed==0&&ui.added==0,"HUD outside board ignored");
        System.out.println("PASS: UI/HUD outside ROI ignored");

        try{ManualMoveCore.compare(before,empty(),W,H,new int[]{3,10,500,165});
            throw new AssertionError("bad roi should be rejected");
        }catch(IllegalArgumentException expected){}
        System.out.println("PASS: invalid board bounds rejected");
    }
}
