package com.example.amazegobot;

import android.graphics.Bitmap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

/**
 * EXPERIMENTAL tap advisor. Uses actual ink components, arrowhead width profiles,
 * and a head-direction corridor. This is NOT a proof of the game's collision rules.
 * Every move must be followed by a real new screenshot and a life-count check.
 */
public final class AutoMovePlanner {
    private AutoMovePlanner() {}
    public static final class Move {
        public final int x,y,headX,headY,dir,score,region;
        Move(int x,int y,int hx,int hy,int d,int score,int id) {
            this.x=x;this.y=y;headX=hx;headY=hy;dir=d;this.score=score;region=id;
        }
        public String toString() {return "tap=("+x+","+y+") tip=("+headX+","+headY+") dir="+"URDL".charAt(dir)+" score="+score+" id="+region;}
    }
    public static final class Plan {
        public final List<Move> moves;
        public final long signature;
        public final int lives,regions,tips;
        Plan(List<Move> moves,long sig,int lives,int regions,int tips){this.moves=moves;signature=sig;this.lives=lives;this.regions=regions;this.tips=tips;}
        public String summary(){return "regions="+regions+" possible heads="+tips+" outward candidates="+moves.size()+" lives="+lives+" board="+Long.toHexString(signature);}
    }
    private static class Region {
        int id,minX,minY,maxX,maxY,tx,ty;
        int[] pixels;
        ArrayList<Integer> ends=new ArrayList<>();
        Region(int id,int[] pix,int minX,int minY,int maxX,int maxY){
            this.id=id;pixels=pix;this.minX=minX;this.minY=minY;this.maxX=maxX;this.maxY=maxY;
        }
    }
    private static int[] around(byte[] a,int i,int w){return new int[]{a[i-w]&255,a[i-w+1]&255,a[i+1]&255,a[i+w+1]&255,a[i+w]&255,a[i+w-1]&255,a[i-1]&255,a[i-w-1]&255};}
    private static void thin(byte[] a,int w,int[] roi){
        byte[] erased=new byte[a.length];
        for(int iter=0;iter<18;iter++){
            boolean changed=false;
            for(int pass=0;pass<2;pass++){
                int erasedCount=0;
                for(int y=roi[1]+1;y<roi[3]-1;y++)for(int x=roi[0]+1;x<roi[2]-1;x++){
                    int i=y*w+x;if(a[i]==0)continue;
                    int[] p=around(a,i,w);int n=0,trans=0;
                    for(int k=0;k<8;k++){n+=p[k];if(p[k]==0&&p[(k+1)&7]==1)trans++;}
                    if(n<2||n>6||trans!=1)continue;
                    if(pass==0?(p[0]*p[2]*p[4]!=0||p[2]*p[4]*p[6]!=0):
                            (p[0]*p[2]*p[6]!=0||p[0]*p[4]*p[6]!=0))continue;
                    erased[i]=1;erasedCount++;
                }
                if(erasedCount>0){changed=true;for(int y=roi[1]+1;y<roi[3]-1;y++)for(int x=roi[0]+1;x<roi[2]-1;x++){
                    int i=y*w+x;if(erased[i]!=0){a[i]=0;erased[i]=0;}
                }}
            }
            if(!changed)break;
        }
    }
    private static int widthAt(Region r,int[] owner,int w,int[] roi,int x,int y,int dir,int backward){
        int dx=dir==1?1:dir==3?-1:0,dy=dir==2?1:dir==0?-1:0;
        int cx=x-backward*dx,cy=y-backward*dy,wd=0;
        for(int shift=-12;shift<=12;shift++){
            int px=cx-shift*dy,py=cy+shift*dx;
            if(px>=roi[0]&&px<roi[2]&&py>=roi[1]&&py<roi[3]&&owner[py*w+px]==r.id)wd++;
        }
        return wd;
    }
    private static class Tip {int x,y,dir,weight;Tip(int x,int y,int d,int wt){this.x=x;this.y=y;dir=d;weight=wt;}}
    private static Tip classify(Region r,int[] owner,int w,int[] roi){
        if(r.ends.size()<2||r.ends.size()>8)return null;
        Tip best=null;int hits=0;
        for(int e:r.ends){int x=e%w,y=e/w;
            for(int dir=0;dir<4;dir++){
                int[] widths=new int[5];for(int t=0;t<5;t++)widths[t]=widthAt(r,owner,w,roi,x,y,dir,t*4);
                int bulge=Math.max(widths[1],widths[2]);
                int baseline=Math.max(widths[0],Math.max(widths[3],widths[4]));
                if(bulge-baseline>=3&&widths[2]>=8&&widths[0]<=10&&widths[3]>=3&&widths[4]>=3){
                    Tip t=new Tip(x,y,dir,bulge-baseline);hits++;best=t;
                }
            }
        }
        return hits==1?best:null;
    }
    private static int[] dirsX={0,1,0,-1},dirsY={-1,0,1,0};
    private static int headClearance(int[] owner,int w,int[] roi,int x,int y,int dir,int self){
        int dx=dirsX[dir],dy=dirsY[dir];
        int distance=0;
        for(int step=8;step<2400;step+=2){
            int cx=x+step*dx,cy=y+step*dy;
            if(cx<roi[0]||cx>=roi[2]||cy<roi[1]||cy>=roi[3])return distance;
            distance+=2;
            for(int guard=-3;guard<=3;guard++){
                int xx=cx-guard*dy,yy=cy+guard*dx;
                if(xx<roi[0]||xx>=roi[2]||yy<roi[1]||yy>=roi[3])continue;
                int found=owner[yy*w+xx];
                if(found!=0&&found!=self)return -1;
            }
        }
        return -1;
    }
    private static int countLives(int[] pix,int w,int h){
        // Blue droplet HUD markers. Conservative: unknown -> -1 (never assume a loss).
        int count=0,roiBottom=Math.min(h/5,430);
        int fromX=Math.max(0,w/40),toX=Math.min(w,w*40/100);
        int[] cols=new int[toX-fromX];
        for(int y=120;y<roiBottom;y+=2)for(int x=fromX;x<toX;x+=2){
            int c=pix[y*w+x],r=(c>>>16)&255,g=(c>>>8)&255,b=c&255;
            if(b>170&&b>r+50&&b>g+12&&g>90)cols[x-fromX]++;
        }
        int run=0;
        for(int i=0;i<cols.length;i+=2){
            if(cols[i]>=6)run++;
            else{if(run>=7&&run<=140)count++;run=0;}
        }
        if(run>=7&&run<=140)count++;
        return count<=3?count:-1;
    }
    public static Plan plan(Bitmap screenshot){
        int w=screenshot.getWidth(),h=screenshot.getHeight(),n=w*h;
        int[] roi=ArrowDetector.boardRoi(screenshot);
        int[] color=new int[n];screenshot.getPixels(color,0,w,0,0,w,h);
        byte[] ink=new byte[n];int[] owner=new int[n];
        long hash=1469598103934665603L;
        for(int y=roi[1];y<roi[3];y++)for(int x=roi[0];x<roi[2];x++){
            int i=y*w+x;
            if(ArrowDetector.pathPixel(color[i]))ink[i]=1;
            // Small-area fingerprint, deliberately excludes life icons and toolbar.
            if((x&7)==0&&(y&7)==0){hash^=ink[i];hash*=1099511628211L;}
        }
        byte[] skel=ink.clone();int[] queue=new int[n];
        List<Region> regions=new ArrayList<>();int id=0;
        for(int y=roi[1];y<roi[3];y++)for(int x=roi[0];x<roi[2];x++){
            int i=y*w+x;if(ink[i]==0)continue;
            int head=0,tail=0;id++;ink[i]=0;owner[i]=id;queue[tail++]=i;
            int minX=x,maxX=x,minY=y,maxY=y;
            while(head<tail){int cur=queue[head++],cx=cur%w,cy=cur/w;
                if(cx<minX)minX=cx;if(cx>maxX)maxX=cx;if(cy<minY)minY=cy;if(cy>maxY)maxY=cy;
                for(int yy=cy-1;yy<=cy+1;yy++)for(int xx=cx-1;xx<=cx+1;xx++){
                    if(xx<roi[0]||xx>=roi[2]||yy<roi[1]||yy>=roi[3])continue;
                    int q=yy*w+xx;if(ink[q]!=0){ink[q]=0;owner[q]=id;queue[tail++]=q;}
                }
            }
            if(tail<45 || tail>18000){
                for(int q=0;q<tail;q++)owner[queue[q]]=0;
            }
            if(tail>=45&&tail<=18000){
                int[] pixels=Arrays.copyOf(queue,tail);
                Region r=new Region(id,pixels,minX,minY,maxX,maxY);
                int midX=(minX+maxX)/2,midY=(minY+maxY)/2,best=Integer.MAX_VALUE;
                for(int p:pixels){int px=p%w,py=p/w,d=Math.abs(px-midX)+Math.abs(py-midY);
                    if(d<best){best=d;r.tx=px;r.ty=py;}
                }
                regions.add(r);
            }
        }
        thin(skel,w,roi);
        HashMap<Integer,Region> lookup=new HashMap<>();for(Region r:regions)lookup.put(r.id,r);
        for(int y=roi[1]+1;y<roi[3]-1;y++)for(int x=roi[0]+1;x<roi[2]-1;x++){
            int p=y*w+x;if(skel[p]==0)continue;
            Region r=lookup.get(owner[p]);if(r==null)continue;
            int degree=0;
            for(int yy=y-1;yy<=y+1;yy++)for(int xx=x-1;xx<=x+1;xx++)if((x!=xx||y!=yy)&&skel[yy*w+xx]!=0&&owner[yy*w+xx]==r.id)degree++;
            if(degree==1)r.ends.add(p);
        }
        int tips=0;List<Move> choices=new ArrayList<>();
        for(Region r:regions){
            Tip tip=classify(r,owner,w,roi);if(tip==null)continue;tips++;
            int clearance=headClearance(owner,w,roi,tip.x,tip.y,tip.dir,r.id);
            if(clearance<0)continue;
            int margin=(tip.dir==0?tip.y-roi[1]:tip.dir==1?roi[2]-tip.x:
                tip.dir==2?roi[3]-tip.y:tip.x-roi[0]);
            int score=100+tip.weight*6 + Math.max(0,800-margin)/20;
            // Contact at the very outer edge often indicates the intended exit move.
            if(margin<90)score+=25;
            // Never select a tap on a life icon, app chrome or nearly clipped component.
            choices.add(new Move(r.tx,r.ty,tip.x,tip.y,tip.dir,score,r.id));
        }
        choices.sort(Comparator.comparingInt((Move m)->m.score).reversed());
        return new Plan(choices,hash,countLives(color,w,h),regions.size(),tips);
    }
}
