package com.example.amazegobot;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import java.util.ArrayList;
import java.util.List;

/**
 * V11.1 diagnostic-only: find full-resolution color-neutral ink regions, then conservatively
 * test the space occupied if every pixel in a region translated rigidly toward
 * a board edge. Region identities and travel directions are NOT proven game arrows.
 * Zero gestures are dispatched by this class.
 */
public final class FullPathAudit {
    private FullPathAudit() {}
    private static final class Region {
        int id, minX, minY, maxX, maxY;
        int[] pixels;
        int len;
        boolean clipped;
        Region(int id,int x,int y,int size){this.id=id;minX=maxX=x;minY=maxY=y;pixels=new int[size];}
    }
    // No hue class here: a single continuous arrow may change color.
    // ArrowDetector.pathPixel applies the calibrated saturation threshold.
    // Full rigid-pixel swept corridor, not only an arrowhead ray.
    // Every source pixel must reach beyond the board without intersecting ANY
    // other detected ink region. The 1px perpendicular margin is conservative.
    private static boolean raySweep(Region region,int[] owners,int w,int[] roi,int dx,int dy) {
        if(region.clipped)return false;
        final int left=roi[0],top=roi[1],right=roi[2],bottom=roi[3];
        // A label cannot be trusted as a whole arrow if it touches the ROI boundary.
        for(int k=0;k<region.len;k++) {
            int pt=region.pixels[k],x=pt%w,y=pt/w;
            for(int xx=x+dx,yy=y+dy; xx>=left&&xx<right&&yy>=top&&yy<bottom;xx+=dx,yy+=dy) {
                int pos=yy*w+xx;
                if(owners[pos]!=0&&owners[pos]!=region.id)return false;
                // The arrow has nonzero width. Check a one-pixel margin perpendicular
                // to translation but do not count any pixel belonging to this region.
                int ax=xx-dy,ay=yy+dx,bx=xx+dy,by=yy-dx;
                if(ax>=left&&ax<right&&ay>=top&&ay<bottom){int other=owners[ay*w+ax];if(other!=0&&other!=region.id)return false;}
                if(bx>=left&&bx<right&&by>=top&&by<bottom){int other=owners[by*w+bx];if(other!=0&&other!=region.id)return false;}
            }
        }
        return true;
    }
    public static Bitmap render(Bitmap source) {
        final int w=source.getWidth(),h=source.getHeight(),n=w*h;
        final int[] roi=ArrowDetector.boardRoi(source);
        int[] image=new int[n]; source.getPixels(image,0,w,0,0,w,h);
        byte[] inkMask=new byte[n];int[] owners=new int[n];
        for(int y=roi[1];y<roi[3];y++)for(int x=roi[0];x<roi[2];x++){
            int i=y*w+x;
            if(ArrowDetector.pathPixel(image[i]))inkMask[i]=1;
        }
        int[] queue=new int[n];
        List<Region> regions=new ArrayList<>();int total=0,tiny=0;
        for(int y=roi[1];y<roi[3];y++)for(int x=roi[0];x<roi[2];x++){
            int start=y*w+x;if(inkMask[start]==0)continue;
            int head=0,tail=0,id=++total;
            inkMask[start]=0;owners[start]=id;queue[tail++]=start;
            int minX=x,minY=y,maxX=x,maxY=y;
            while(head<tail){
                int at=queue[head++],px=at%w,py=at/w;
                if(px<minX)minX=px;if(px>maxX)maxX=px;
                if(py<minY)minY=py;if(py>maxY)maxY=py;
                for(int oy=-1;oy<=1;oy++)for(int ox=-1;ox<=1;ox++){
                    if(ox==0&&oy==0)continue;
                    int xx=px+ox,yy=py+oy;
                    if(xx<roi[0]||xx>=roi[2]||yy<roi[1]||yy>=roi[3])continue;
                    int next=yy*w+xx;
                    if(inkMask[next]!=0){inkMask[next]=0;owners[next]=id;queue[tail++]=next;}
                }
            }
            if(tail<45){tiny++;continue;}
            Region r=new Region(id,x,y,tail);
            System.arraycopy(queue,0,r.pixels,0,tail);r.len=tail;
            r.minX=minX;r.maxX=maxX;r.minY=minY;r.maxY=maxY;
            r.clipped=minX<=roi[0]+3||maxX>=roi[2]-4||minY<=roi[1]+3||maxY>=roi[3]-4;
            regions.add(r);
        }
        Bitmap output=source.copy(Bitmap.Config.ARGB_8888,true);
        Canvas canvas=new Canvas(output);Paint pen=new Paint(3);
        // Use conspicuous outlines but do not paint over the shape itself.
        int[] vx={0,1,0,-1},vy={-1,0,1,0};
        String[] direction={"U","R","D","L"};
        int edge=0,possible=0,blocked=0,untested=0;
        for(Region r:regions){
            if(r.clipped)edge++;
            int clears=0;StringBuilder dirs=new StringBuilder();
            // Skip huge components: they can be merged arrows and are expensive.
            if(!r.clipped&&r.len<=5000){
                for(int k=0;k<4;k++){
                    if(raySweep(r,owners,w,roi,vx[k],vy[k])){clears++;dirs.append(direction[k]);}
                }
            } else if(!r.clipped) untested++;
            if(clears>0)possible++;else blocked++;
            pen.setStyle(Paint.Style.STROKE);
            pen.setColor(r.clipped?Color.rgb(255,60,80):clears>0?Color.rgb(0,180,220):Color.rgb(255,150,0));
            pen.setStrokeWidth(2);
            canvas.drawRect(r.minX-2,r.minY-2,r.maxX+2,r.maxY+2,pen);
            // Limit labels to prevent unreadable overlays for dense boards.
            if(r.len>=90){
                pen.setStyle(Paint.Style.FILL);pen.setTextSize(17);
                canvas.drawText("#"+r.id+" "+(r.clipped?"EDGE":clears>0?dirs.toString():"?"),
                        r.minX,Math.max(roi[1]+18,r.minY-5),pen);
            }
        }
        pen.setColor(Color.rgb(0,160,70));pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(2);
        canvas.drawRect(roi[0],roi[1],roi[2],roi[3],pen);
        pen.setStyle(Paint.Style.FILL);pen.setColor(Color.BLACK);canvas.drawRect(0,0,w,218,pen);
        pen.setColor(Color.WHITE);pen.setTextSize(22);
        canvas.drawText("V11.1 CLEAN INK / SWEPT PATH AUDIT",12,35,pen);
        pen.setTextSize(18);
        canvas.drawText("Regions="+regions.size()+" tiny="+tiny+" ROI-edge="+edge,12,71,pen);
        canvas.drawText("Unverified sweep="+possible+" blocked/unknown="+blocked,12,104,pen);
        canvas.drawText("Skipped huge="+untested+"; no head-direction proof",12,135,pen);
        canvas.drawText("CYAN=possible sweep; ORANGE=blocked; RED=edge",12,168,pen);
        canvas.drawText("SHAPES NOT VERIFIED AS ARROWS. NO TAPS.",12,201,pen);
        return output;
    }
}
