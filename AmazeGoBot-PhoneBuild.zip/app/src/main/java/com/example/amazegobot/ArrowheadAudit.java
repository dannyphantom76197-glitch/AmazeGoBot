package com.example.amazegobot;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * V11.2 diagnostic only. Recovers a tentative tip direction from a pixel-skeleton
 * signature (three arrowhead endpoints + one far-end endpoint) and tests the
 * FULL connected ink component swept toward that tip, not just a head ray.
 * Neither a region nor a clear ink sweep proves a valid game move.
 * This class cannot send any input gestures.
 */
public final class ArrowheadAudit {
    private ArrowheadAudit() {}
    private static final class Region {
        final int id;
        int minX, minY, maxX, maxY;
        final int[] pixels;
        final ArrayList<int[]> ends=new ArrayList<>();
        Region(int id,int[] pixels,int minX,int minY,int maxX,int maxY){
            this.id=id;this.pixels=pixels;this.minX=minX;this.minY=minY;this.maxX=maxX;this.maxY=maxY;
        }
    }
    private static final class Guess {
        int x, y, dir;
        Guess(int x,int y,int dir){this.x=x;this.y=y;this.dir=dir;}
    }
    private static int root(int[] parent,int x) {
        while(parent[x]!=x){parent[x]=parent[parent[x]];x=parent[x];}return x;
    }
    // Skeleton 8-neighbors clockwise, starting North.
    private static int[] neighbors(byte[] a,int index,int width) {
        return new int[]{a[index-width]&255,a[index-width+1]&255,a[index+1]&255,
            a[index+width+1]&255,a[index+width]&255,a[index+width-1]&255,
            a[index-1]&255,a[index-width-1]&255};
    }
    private static int thin(byte[] a,byte[] remove,int w,int[] roi) {
        int rounds=0;
        for(;rounds<18;rounds++) {
            boolean changed=false;
            for(int pass=0;pass<2;pass++){
                int nRemove=0;
                for(int y=roi[1]+1;y<roi[3]-1;y++)for(int x=roi[0]+1;x<roi[2]-1;x++){
                    int pos=y*w+x;
                    if(a[pos]==0)continue;
                    int[] p=neighbors(a,pos,w);
                    int count=0,transitions=0;
                    for(int k=0;k<8;k++){count+=p[k];if(p[k]==0&&p[(k+1)&7]!=0)transitions++;}
                    if(count<2||count>6||transitions!=1)continue;
                    if(pass==0){if(p[0]*p[2]*p[4]!=0||p[2]*p[4]*p[6]!=0)continue;}
                    else {if(p[0]*p[2]*p[6]!=0||p[0]*p[4]*p[6]!=0)continue;}
                    remove[pos]=1;nRemove++;
                }
                if(nRemove>0){
                    changed=true;
                    for(int y=roi[1]+1;y<roi[3]-1;y++)for(int x=roi[0]+1;x<roi[2]-1;x++){
                        int pos=y*w+x;if(remove[pos]!=0){a[pos]=0;remove[pos]=0;}
                    }
                }
            }
            if(!changed)break;
        }
        return rounds;
    }
    // At a real triangular arrowhead, a cross-section typically widens a few
    // pixels behind the apex, then narrows again to the ~5px arrow shaft.
    // A plain stroke tail has approximately constant width. We only accept
    // one unambiguous triangle-shaped endpoint/direction candidate per region.
    private static int crossWidth(int[] owners,int w,int[] roi,Region r,
                                  int x,int y,int dir,int back){
        int dx=dir==1?1:dir==3?-1:0;
        int dy=dir==2?1:dir==0?-1:0;
        int cx=x-dx*back,cy=y-dy*back;
        int width=0;
        for(int q=-12;q<=12;q++){
            int px=cx-dy*q,py=cy+dx*q;
            if(px<roi[0]||px>=roi[2]||py<roi[1]||py>=roi[3])continue;
            if(owners[py*w+px]==r.id)width++;
        }
        return width;
    }
    private static Guess classify(Region r,int[] owners,int w,int[] roi){
        if(r.ends.size()<2||r.ends.size()>8)return null;
        Guess best=null;int hits=0;
        for(int[] end:r.ends)for(int dir=0;dir<4;dir++){
            int[] widths=new int[5];
            for(int step=0;step<5;step++)
                widths[step]=crossWidth(owners,w,roi,r,end[0],end[1],dir,step*4);
            int peak=Math.max(widths[1],widths[2]);
            int baseline=Math.max(widths[0],Math.max(widths[3],widths[4]));
            // These calibrated pixel widths apply to the captured 1080px board.
            // Wrong-scale/unknown arrowheads remain unclassified (safe hold).
            if(peak-baseline>=3 && widths[2]>=9 && widths[0]<=10
                    && widths[3]>=3 && widths[4]>=3){
                hits++;best=new Guess(end[0],end[1],dir);
            }
        }
        return hits==1?best:null;
    }
    // Sweep the entire component in its hypothesized travel direction. Each
    // pixel's trajectory lies in a row/column extending from the trailing-most
    // component pixel to the board edge, so use one interval per scanline.
    // A 1px crosswise guard conservatively includes the stroke's visual edge.
    private static boolean fullInkSweep(Region r,int[] owners,int w,int[] roi,int dir) {
        final int big=0x7fffffff;
        final int left=roi[0],top=roi[1],right=roi[2],bottom=roi[3];
        if(r.minX<=left+2||r.maxX>=right-3||r.minY<=top+2||r.maxY>=bottom-3)return false;
        if(dir==1||dir==3){
            int[] extreme=new int[r.maxY-r.minY+1];
            java.util.Arrays.fill(extreme,dir==1?big:-1);
            for(int pt:r.pixels){int x=pt%w,y=pt/w-r.minY;
                if(dir==1)extreme[y]=Math.min(extreme[y],x);else extreme[y]=Math.max(extreme[y],x);
            }
            for(int row=0;row<extreme.length;row++){
                if(extreme[row]==big||extreme[row]==-1)continue;
                for(int yy=r.minY+row-1; yy<=r.minY+row+1;yy++){
                    if(yy<top||yy>=bottom)continue;
                    int from=dir==1?extreme[row]:left,to=dir==1?right:extreme[row]+1;
                    for(int x=from;x<to;x++){
                        int other=owners[yy*w+x];if(other!=0&&other!=r.id)return false;
                    }
                }
            }
        } else {
            int[] extreme=new int[r.maxX-r.minX+1];
            java.util.Arrays.fill(extreme,dir==2?big:-1);
            for(int pt:r.pixels){int x=pt%w-r.minX,y=pt/w;
                if(dir==2)extreme[x]=Math.min(extreme[x],y);else extreme[x]=Math.max(extreme[x],y);
            }
            for(int col=0;col<extreme.length;col++){
                if(extreme[col]==big||extreme[col]==-1)continue;
                for(int xx=r.minX+col-1;xx<=r.minX+col+1;xx++){
                    if(xx<left||xx>=right)continue;
                    int from=dir==2?extreme[col]:top,to=dir==2?bottom:extreme[col]+1;
                    for(int y=from;y<to;y++){
                        int other=owners[y*w+xx];if(other!=0&&other!=r.id)return false;
                    }
                }
            }
        }
        return true;
    }
    public static Bitmap render(Bitmap raw) {
        int w=raw.getWidth(),h=raw.getHeight(),n=w*h;
        int[] roi=ArrowDetector.boardRoi(raw);
        int[] input=new int[n];raw.getPixels(input,0,w,0,0,w,h);
        byte[] ink=new byte[n];int[] owner=new int[n];
        for(int y=roi[1];y<roi[3];y++)for(int x=roi[0];x<roi[2];x++){
            int pos=y*w+x;if(ArrowDetector.pathPixel(input[pos]))ink[pos]=1;
        }
        byte[] skeleton=ink.clone();
        int[] queue=new int[n];ArrayList<Region> regions=new ArrayList<>();int all=0;
        for(int y=roi[1];y<roi[3];y++)for(int x=roi[0];x<roi[2];x++){
            int pos=y*w+x;if(ink[pos]==0)continue;
            int head=0,tail=0,id=++all;
            queue[tail++]=pos;ink[pos]=0;owner[pos]=id;
            int minX=x,maxX=x,minY=y,maxY=y;
            while(head<tail){
                int cur=queue[head++],xx=cur%w,yy=cur/w;
                minX=Math.min(minX,xx);maxX=Math.max(maxX,xx);
                minY=Math.min(minY,yy);maxY=Math.max(maxY,yy);
                for(int ny=yy-1;ny<=yy+1;ny++)for(int nx=xx-1;nx<=xx+1;nx++){
                    if(nx<roi[0]||nx>=roi[2]||ny<roi[1]||ny>=roi[3]||(nx==xx&&ny==yy))continue;
                    int next=ny*w+nx;
                    if(ink[next]!=0){ink[next]=0;owner[next]=id;queue[tail++]=next;}
                }
            }
            if(tail>=45){int[] pixels=new int[tail];System.arraycopy(queue,0,pixels,0,tail);
                regions.add(new Region(id,pixels,minX,minY,maxX,maxY));}
        }
        int rounds=thin(skeleton,new byte[n],w,roi);
        HashMap<Integer,Region> byId=new HashMap<>();
        for(Region r:regions)byId.put(r.id,r);
        for(int y=roi[1]+1;y<roi[3]-1;y++)for(int x=roi[0]+1;x<roi[2]-1;x++){
            int p=y*w+x;if(skeleton[p]==0)continue;
            Region r=byId.get(owner[p]);if(r==null)continue;
            int connections=0;
            for(int yy=y-1;yy<=y+1;yy++)for(int xx=x-1;xx<=x+1;xx++){
                if(xx==x&&yy==y)continue;
                int q=yy*w+xx;if(skeleton[q]!=0&&owner[q]==r.id)connections++;
            }
            if(connections==1)r.ends.add(new int[]{x,y});
        }
        Bitmap output=raw.copy(Bitmap.Config.ARGB_8888,true);
        Canvas canvas=new Canvas(output);Paint paint=new Paint(3);
        String[] dirText={"UP","RIGHT","DOWN","LEFT"};
        final int[][] vectors={{0,-1},{1,0},{0,1},{-1,0}};
        int headFound=0,ambiguous=0,inkClear=0,inkBlocked=0;
        
        for(Region r:regions){
            Guess g=classify(r,owner,w,roi);
            if(g==null){ambiguous++;continue;}
            headFound++;
            boolean sweep=fullInkSweep(r,owner,w,roi,g.dir);
            if(sweep)inkClear++;else inkBlocked++;
            // Circle is at a tentative tip; direction marked by a short vector.
            // Green is clear on colored pixels ONLY, not verified gameplay safe.
            paint.setColor(sweep?Color.rgb(20,175,120):Color.rgb(255,125,30));
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3);
            canvas.drawCircle(g.x,g.y,9,paint);
            int endX=g.x+vectors[g.dir][0]*17,endY=g.y+vectors[g.dir][1]*17;
            canvas.drawLine(g.x,g.y,endX,endY,paint);
            paint.setStyle(Paint.Style.FILL);paint.setTextSize(13);
            canvas.drawText("#"+r.id+":"+dirText[g.dir].charAt(0),
                Math.min(w-68,g.x+12),Math.max(roi[1]+13,g.y-7),paint);
        }
        paint.setStyle(Paint.Style.STROKE);paint.setColor(Color.rgb(0,140,75));paint.setStrokeWidth(2);
        canvas.drawRect(roi[0],roi[1],roi[2],roi[3],paint);
        paint.setStyle(Paint.Style.FILL);paint.setColor(Color.BLACK);
        canvas.drawRect(0,0,w,232,paint);
        paint.setColor(Color.WHITE);paint.setTextSize(23);
        canvas.drawText("V11.2 TIP-WIDTH / SWEPT-INK AUDIT",12,32,paint);
        paint.setTextSize(19);
        canvas.drawText("Regions="+regions.size()+" tip patterns="+headFound+" ambiguous="+ambiguous,12,68,paint);
        canvas.drawText("Direction-specific ink sweeps: clear="+inkClear+" blocked="+inkBlocked,12,101,paint);
        canvas.drawText("Skeleton rounds="+rounds+"; full regions, not hues",12,133,paint);
        canvas.drawText("GREEN=ink clear; ORANGE=ink blocked",12,166,paint);
        canvas.drawText("HEADS ARE HYPOTHESES, NOT VERIFIED ARROWS",12,197,paint);
        canvas.drawText("NO AUTO TAPS. HITBOX / MOTION STILL UNKNOWN.",12,225,paint);
        return output;
    }
}
