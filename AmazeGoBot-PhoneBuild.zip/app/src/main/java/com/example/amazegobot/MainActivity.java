package com.example.amazegobot;

import android.app.Activity;
import android.graphics.BitmapFactory;
import android.widget.ImageView;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.widget.ScrollView;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences prefs; private TextView status,diagnostic; private Button toggle;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Runnable refresh=new Runnable(){@Override public void run(){update();main.postDelayed(this,500);}};
    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("bot",MODE_PRIVATE);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(48,64,48,48);
        TextView title=new TextView(this);title.setText("Amaze GO Bot — V9.1 Color Stroke Mask Diagnostics");title.setTextSize(26);root.addView(title);
        TextView info=new TextView(this);info.setText("\nDiagnostic mode: screenshots, shape mask, and labeled connected fragments only. Automatic taps disabled until complete-path collision testing is validated.");info.setTextSize(16);root.addView(info);
        Button accessibility=new Button(this);accessibility.setText("Open Accessibility Settings");accessibility.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));root.addView(accessibility);
        toggle=new Button(this);root.addView(toggle);toggle.setOnClickListener(v->{boolean on=!prefs.getBoolean("enabled",false);prefs.edit().putBoolean("enabled",on).apply();update();});
        status=new TextView(this);status.setTextSize(15);status.setPadding(0,20,0,0);root.addView(status);
        diagnostic=new TextView(this);diagnostic.setTextSize(16);diagnostic.setPadding(0,30,0,0);root.addView(diagnostic);
        TextView previewStatus=new TextView(this);previewStatus.setText("Preview: not opened yet.");previewStatus.setTextSize(16);
        Button rawPreview=new Button(this);rawPreview.setText("SHOW RAW CAPTURED SCREENSHOT");root.addView(rawPreview);
        Button preview=new Button(this);preview.setText("SHOW PROCESSED GEOMETRY MASK");root.addView(preview);
        root.addView(previewStatus);
        ImageView image=new ImageView(this);image.setAdjustViewBounds(true);image.setMinimumHeight(240);root.addView(image);
        rawPreview.setOnClickListener(v->showPreview("v88-raw.png", "RAW SCREENSHOT", image, previewStatus));
        preview.setOnClickListener(v->showPreview("v88-mask.png", "GEOMETRY MASK", image, previewStatus));
        ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);update();}
    private void showPreview(String filename, String label, ImageView image, TextView previewStatus) {
        java.io.File file = new java.io.File(getFilesDir(), filename);
        if (!file.isFile() || file.length() == 0) {
            previewStatus.setText(label + " unavailable: " + filename + " not saved yet. Keep the game visible until a scan completes, then return here.");
            Toast.makeText(this, "No saved " + label.toLowerCase() + " yet", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            if (bitmap == null) throw new java.io.IOException("Image decoder returned null");
            image.setImageBitmap(bitmap);
            previewStatus.setText(label + " DISPLAYED: " + bitmap.getWidth() + " x " + bitmap.getHeight() + " pixels; " + file.length() + " bytes. Scroll down to inspect.");
            image.post(() -> {
                android.graphics.Rect rect = new android.graphics.Rect();
                image.getDrawingRect(rect);
                image.requestRectangleOnScreen(rect, true);
            });
        } catch (Exception e) {
            previewStatus.setText(label + " could not be opened: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
    @Override protected void onResume(){super.onResume();main.removeCallbacks(refresh);main.post(refresh);}
    @Override protected void onPause(){main.removeCallbacks(refresh);super.onPause();}
    private void update(){boolean on=prefs.getBoolean("enabled",false);toggle.setText(on?"BOT ON":"BOT OFF");status.setText(on?"Scanning enabled; automatic taps disabled.":"Bot is off.");diagnostic.setText("LAST RESULT:\n"+prefs.getString("diagnostic","No result yet.")+"\n\nLIVE STATUS:\n"+prefs.getString("heartbeat","Waiting for service...")+"\n\nSCAN PROGRESS:\n"+prefs.getString("scan_progress","Waiting for scan..."));}
}
