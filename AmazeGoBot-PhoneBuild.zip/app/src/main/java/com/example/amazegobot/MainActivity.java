package com.example.amazegobot;

import android.app.Activity;
import android.graphics.BitmapFactory;
import android.widget.ImageView;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.widget.ScrollView;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences prefs; private TextView status,diagnostic; private Button toggle;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Runnable refresh=new Runnable(){@Override public void run(){update();main.postDelayed(this,500);}};
    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("bot",MODE_PRIVATE);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(48,64,48,48);
        TextView title=new TextView(this);title.setText("Amaze GO Bot — V11.3 First-Blocker Diagnostics");title.setTextSize(26);root.addView(title);
        TextView info=new TextView(this);info.setText("\nDiagnostic mode: screenshots, shape mask, and labeled connected fragments only. Automatic taps disabled until complete-path collision testing is validated.");info.setTextSize(16);root.addView(info);
        Button accessibility=new Button(this);accessibility.setText("Open Accessibility Settings");accessibility.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));root.addView(accessibility);
        toggle=new Button(this);root.addView(toggle);toggle.setOnClickListener(v->{boolean on=!prefs.getBoolean("enabled",false);prefs.edit().putBoolean("enabled",on).apply();update();});
        status=new TextView(this);status.setTextSize(15);status.setPadding(0,20,0,0);root.addView(status);
        diagnostic=new TextView(this);diagnostic.setTextSize(16);diagnostic.setPadding(0,30,0,0);root.addView(diagnostic);
        TextView previewStatus=new TextView(this);previewStatus.setText("Preview: not opened yet.");previewStatus.setTextSize(16);
        Button rawPreview=new Button(this);rawPreview.setText("SHOW RAW CAPTURED SCREENSHOT");root.addView(rawPreview);
        Button preview=new Button(this);preview.setText("SHOW PROCESSED GEOMETRY MASK");root.addView(preview);
        Button nativePreview=new Button(this);nativePreview.setText("SHOW FULL-RESOLUTION STROKE MASK");root.addView(nativePreview);
        ImageView image=new ImageView(this);image.setAdjustViewBounds(true);image.setMinimumHeight(240);root.addView(image);
        Button sweepPreview=new Button(this);
        sweepPreview.setText("V11.1 SHOW CLEAN INK / SWEEP AUDIT");root.addView(sweepPreview);
        sweepPreview.setOnClickListener(v->{
            previewStatus.setText("Removing background dots, isolating puzzle, and auditing full-shape movement...");
            new Thread(()->{
                try{
                    java.io.File file=new java.io.File(getFilesDir(),"v88-raw.png");
                    if(!file.isFile())throw new java.io.IOException("No saved screenshot; scan game first");
                    Bitmap raw=BitmapFactory.decodeFile(file.getAbsolutePath());
                    if(raw==null)throw new java.io.IOException("Could not decode screenshot");
                    Bitmap result=FullPathAudit.render(raw);raw.recycle();
                    main.post(()->{image.setImageBitmap(result);previewStatus.setText("V11.1 removes background dots and HUD. Clean shapes and possible swept paths are NOT independently verified arrowheads. No automatic taps.");});
                }catch(Exception e){main.post(()->previewStatus.setText("V11.1 sweep audit failed: "+e.getMessage()));}
            }).start();
        });
        Button headAudit=new Button(this);
        headAudit.setText("V11.2 SHOW ARROW TIP / DIRECTION AUDIT");root.addView(headAudit);
        headAudit.setOnClickListener(v->{
            previewStatus.setText("Thinning strokes and testing arrow-tip width patterns. No taps.");
            new Thread(()->{
                try{
                    java.io.File file=new java.io.File(getFilesDir(),"v88-raw.png");
                    if(!file.isFile())throw new java.io.IOException("No saved screenshot; scan the game first");
                    Bitmap raw=BitmapFactory.decodeFile(file.getAbsolutePath());
                    if(raw==null)throw new java.io.IOException("Screenshot decode failed");
                    Bitmap result=ArrowheadAudit.render(raw);raw.recycle();
                    main.post(()->{image.setImageBitmap(result);previewStatus.setText("V11.2 tip directions and full-shape INK sweeps are preliminary. No verified in-game collision or automatic taps.");});
                }catch(Exception e){main.post(()->previewStatus.setText("V11.2 endpoint audit failed: "+e.getMessage()));}
            }).start();
        });
        Button blockerAudit=new Button(this);
        blockerAudit.setText("V11.3 SHOW FIRST COLLISION / DIRECTION AUDIT");root.addView(blockerAudit);
        blockerAudit.setOnClickListener(v->{
            previewStatus.setText("Measuring distance to first foreign ink in each hypothetical tip direction...");
            new Thread(()->{
                try{
                    java.io.File file=new java.io.File(getFilesDir(),"v88-raw.png");
                    if(!file.isFile())throw new java.io.IOException("No captured level. Scan the game first.");
                    Bitmap raw=BitmapFactory.decodeFile(file.getAbsolutePath());
                    if(raw==null)throw new java.io.IOException("Cannot decode last raw game screenshot");
                    Bitmap result=ArrowheadAudit.renderBlockerAudit(raw);raw.recycle();
                    main.post(()->{image.setImageBitmap(result);previewStatus.setText("V11.3 shows exact-ink/1px-guard blocking distances and the first foreign ink. No verified moves or automatic taps.");});
                }catch(Exception e){main.post(()->previewStatus.setText("V11.3 collision audit failed: "+e.getMessage()));}
            }).start();
        });
        Button saveRaw=new Button(this);
        saveRaw.setText("V11.3 SAVE ORIGINAL GAME CAPTURE TO PHOTOS");root.addView(saveRaw);
        saveRaw.setOnClickListener(v->{
            try {
                java.io.File file=new java.io.File(getFilesDir(),"v88-raw.png");
                if(!file.isFile())throw new java.io.IOException("Scan a level first");
                android.content.ContentValues values=new android.content.ContentValues();
                values.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME,"AmazeGoBot-Raw-"+System.currentTimeMillis()+".png");
                values.put(android.provider.MediaStore.Images.Media.MIME_TYPE,"image/png");
                if(android.os.Build.VERSION.SDK_INT>=29)values.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH,"Pictures/AmazeGoBot");
                android.net.Uri uri=getContentResolver().insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
                if(uri==null)throw new java.io.IOException("Photos returned no destination");
                try(java.io.InputStream in=new java.io.FileInputStream(file);
                    java.io.OutputStream out=getContentResolver().openOutputStream(uri)){
                    if(out==null)throw new java.io.IOException("Cannot open saved image");
                    byte[] buf=new byte[8192];int read;while((read=in.read(buf))!=-1)out.write(buf,0,read);
                }
                previewStatus.setText("Saved original raw game image in Photos / Pictures/AmazeGoBot. Send that PNG directly, not a camera picture of the screen.");
                Toast.makeText(this,"Raw screenshot saved to Photos",Toast.LENGTH_LONG).show();
            }catch(Exception e){previewStatus.setText("Save raw screenshot failed: "+e.getMessage());}
        });
        Button connectivityPreview=new Button(this);
        connectivityPreview.setText("V10.9 SHOW COLOR CONNECTIVITY AUDIT");root.addView(connectivityPreview);
        connectivityPreview.setOnClickListener(v->{
            previewStatus.setText("Analyzing full-resolution color connectivity...");
            new Thread(()->{
                try{
                    java.io.File file=new java.io.File(getFilesDir(),"v88-raw.png");
                    if(!file.isFile())throw new java.io.IOException("No saved screenshot; scan game first");
                    Bitmap raw=BitmapFactory.decodeFile(file.getAbsolutePath());
                    if(raw==null)throw new java.io.IOException("Could not decode screenshot");
                    Bitmap result=ArrowDetector.debugColorConnectivity(raw);raw.recycle();
                    main.post(()->{image.setImageBitmap(result);previewStatus.setText("V10.9: color-connected fragments are NOT verified arrows. No automatic taps.");});
                }catch(Exception e){main.post(()->previewStatus.setText("V10.9 audit failed: "+e.getMessage()));}
            }).start();
        });
        Button componentsPreview=new Button(this);
        componentsPreview.setText("V10.1 SHOW LOCAL TERMINAL EVIDENCE");
        root.addView(componentsPreview);
        componentsPreview.setOnClickListener(v->{
            previewStatus.setText("Analyzing saved screenshot...");
            new Thread(()->{
                try {
                    java.io.File file=new java.io.File(getFilesDir(),"v88-raw.png");
                    if(!file.isFile())throw new java.io.IOException("No saved screenshot; scan game first");
                    Bitmap raw=BitmapFactory.decodeFile(file.getAbsolutePath());
                    if(raw==null)throw new java.io.IOException("Could not decode screenshot");
                    Bitmap result=ArrowDetector.debugNativeComponents(raw);
                    raw.recycle();
                    main.post(()->{
                        image.setImageBitmap(result);
                        previewStatus.setText("V10.1 terminal clues are NOT verified arrows. No automatic taps.");
                    });
                } catch(Exception e) {
                    main.post(()->previewStatus.setText("V10.1 analysis failed: "+e.getMessage()));
                }
            }).start();
        });
        Button corridorPreview=new Button(this);
        corridorPreview.setText("V10.2 SHOW HEAD / CORRIDOR EVIDENCE");
        root.addView(corridorPreview);
        corridorPreview.setOnClickListener(v->{
            previewStatus.setText("Analyzing head candidates and forward rays...");
            new Thread(()->{
                try {
                    java.io.File file=new java.io.File(getFilesDir(),"v88-raw.png");
                    if(!file.isFile())throw new java.io.IOException("Scan game first");
                    Bitmap raw=BitmapFactory.decodeFile(file.getAbsolutePath());
                    if(raw==null)throw new java.io.IOException("Screenshot decode failed");
                    Bitmap result=ArrowDetector.debugHeadCorridors(raw);
                    raw.recycle();
                    main.post(()->{
                        image.setImageBitmap(result);
                        previewStatus.setText("V10.2: green marks only clear HEAD rays, not complete arrow paths. No automatic taps.");
                        image.post(()->{android.graphics.Rect rect=new android.graphics.Rect();image.getDrawingRect(rect);image.requestRectangleOnScreen(rect,true);});
                    });
                }catch(Exception e){main.post(()->previewStatus.setText("V10.2 preview failed: "+e.getMessage()));}
            }).start();
        });
        Button continuityPreview=new Button(this);
        continuityPreview.setText("V10.3 SHOW BACKWARD STROKE CONTINUITY");root.addView(continuityPreview);
        continuityPreview.setOnClickListener(v->{
            previewStatus.setText("Testing backward straight-stroke continuity...");
            new Thread(()->{
                try{
                    java.io.File file=new java.io.File(getFilesDir(),"v88-raw.png");
                    if(!file.isFile())throw new java.io.IOException("Scan game first");
                    Bitmap raw=BitmapFactory.decodeFile(file.getAbsolutePath());
                    if(raw==null)throw new java.io.IOException("Screenshot decode failed");
                    Bitmap result=ArrowDetector.debugContinuity(raw);raw.recycle();
                    main.post(()->{image.setImageBitmap(result);previewStatus.setText("V10.3: straight continuity is only preliminary evidence. Bent arrow bodies and collisions remain unverified. No taps.");});
                }catch(Exception e){main.post(()->previewStatus.setText("V10.3 preview failed: "+e.getMessage()));}
            }).start();
        });
        Button bentPreview=new Button(this);
        bentPreview.setText("V10.4 SHOW BENT-STROKE PROBES");root.addView(bentPreview);
        bentPreview.setOnClickListener(v->{
            previewStatus.setText("Tracing bent stroke hypotheses...");
            new Thread(()->{
                try{
                    java.io.File file=new java.io.File(getFilesDir(),"v88-raw.png");
                    if(!file.isFile())throw new java.io.IOException("Scan game first");
                    Bitmap raw=BitmapFactory.decodeFile(file.getAbsolutePath());
                    if(raw==null)throw new java.io.IOException("Screenshot decode failed");
                    Bitmap result=ArrowDetector.debugBentContinuity(raw);raw.recycle();
                    main.post(()->{image.setImageBitmap(result);previewStatus.setText("V10.4: blue lines are exploratory traces only. No verified full arrows or automatic taps.");});
                }catch(Exception e){main.post(()->previewStatus.setText("V10.4 preview failed: "+e.getMessage()));}
            }).start();
        });
        Button coveragePreview=new Button(this);
        coveragePreview.setText("V10.7 SHOW BOARD COVERAGE CHECK");root.addView(coveragePreview);
        coveragePreview.setOnClickListener(v->{
            previewStatus.setText("Checking captured board coverage...");
            new Thread(()->{
                try{
                    java.io.File file=new java.io.File(getFilesDir(),"v88-raw.png");
                    if(!file.isFile())throw new java.io.IOException("Scan game first");
                    Bitmap raw=BitmapFactory.decodeFile(file.getAbsolutePath());
                    if(raw==null)throw new java.io.IOException("Screenshot decode failed");
                    Bitmap result=ArrowDetector.debugBoardCoverage(raw);raw.recycle();
                    main.post(()->{image.setImageBitmap(result);previewStatus.setText("V10.7: green rectangle estimates detected stroke coverage. If it misses the board, capture/color filtering needs correction. No taps.");});
                }catch(Exception e){main.post(()->previewStatus.setText("V10.7 coverage check failed: "+e.getMessage()));}
            }).start();
        });
        Button pathPreview=new Button(this);
        pathPreview.setText("V10.8 SHOW PATH EVIDENCE");root.addView(pathPreview);
        pathPreview.setOnClickListener(v->{
            previewStatus.setText("Comparing bent-stroke hypotheses and forward clearance...");
            new Thread(()->{
                try{
                    java.io.File file=new java.io.File(getFilesDir(),"v88-raw.png");
                    if(!file.isFile())throw new java.io.IOException("Scan game first");
                    Bitmap raw=BitmapFactory.decodeFile(file.getAbsolutePath());
                    if(raw==null)throw new java.io.IOException("Screenshot decode failed");
                    Bitmap result=ArrowDetector.debugPathEvidence(raw);raw.recycle();
                    main.post(()->{image.setImageBitmap(result);previewStatus.setText("V10.8: bent traces and clear head rays are preliminary only. Full rigid-body collision is NOT verified. No taps.");});
                }catch(Exception e){main.post(()->previewStatus.setText("V10.8 path evidence failed: "+e.getMessage()));}
            }).start();
        });
        root.addView(previewStatus);
        rawPreview.setOnClickListener(v->showPreview("v88-raw.png", "RAW SCREENSHOT", image, previewStatus));
        preview.setOnClickListener(v->showPreview("v88-mask.png", "GEOMETRY MASK", image, previewStatus));
        nativePreview.setOnClickListener(v->showPreview("v95-native-mask.png", "FULL-RESOLUTION STROKE MASK", image, previewStatus));
        ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);update();}
    private void showPreview(String filename, String label, ImageView image, TextView previewStatus) {
        java.io.File file = new java.io.File(getFilesDir(), filename);
        if (!file.isFile() || file.length() == 0) {
            previewStatus.setText(label + " unavailable: " + filename + " not saved yet. Keep the game visible until a scan completes, then return here.");
            Toast.makeText(this, "No saved " + label.toLowerCase() + " yet", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            if (bitmap == null) throw new java.io.IOException("Image decoder returned null");
            image.setImageBitmap(bitmap);
            previewStatus.setText(label + " DISPLAYED: " + bitmap.getWidth() + " x " + bitmap.getHeight() + " pixels; " + file.length() + " bytes. Scroll down to inspect.");
            image.post(() -> {
                android.graphics.Rect rect = new android.graphics.Rect();
                image.getDrawingRect(rect);
                image.requestRectangleOnScreen(rect, true);
            });
        } catch (Exception e) {
            previewStatus.setText(label + " could not be opened: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
    @Override protected void onResume(){super.onResume();main.removeCallbacks(refresh);main.post(refresh);}
    @Override protected void onPause(){main.removeCallbacks(refresh);super.onPause();}
    private void update(){boolean on=prefs.getBoolean("enabled",false);toggle.setText(on?"BOT ON":"BOT OFF");status.setText(on?"Scanning enabled; automatic taps disabled.":"Bot is off.");diagnostic.setText("LAST RESULT:\n"+prefs.getString("diagnostic","No result yet.")+"\n\nLIVE STATUS:\n"+prefs.getString("heartbeat","Waiting for service...")+"\n\nSCAN PROGRESS:\n"+prefs.getString("scan_progress","Waiting for scan..."));}
}
