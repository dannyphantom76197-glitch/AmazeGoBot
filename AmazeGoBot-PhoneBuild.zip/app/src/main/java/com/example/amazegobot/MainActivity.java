package com.example.amazegobot;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences prefs; private TextView status,diagnostic; private Button toggle;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Runnable refresh=new Runnable(){@Override public void run(){update();main.postDelayed(this,500);}};
    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("bot",MODE_PRIVATE);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(48,64,48,48);
        TextView title=new TextView(this);title.setText("Amaze GO Bot — V5.7 Recovered Detector");title.setTextSize(26);root.addView(title);
        TextView info=new TextView(this);info.setText("\nV5.7 capture test. Uses one screenshot request at a time with the callback on Android’s main executor. It shows the exact failure code if Android rejects a capture. After a successful capture it may make ONE clear move, then waits before rescanning.\n\nTest on a level where losing a heart is okay. Turn BOT OFF immediately if it makes a wrong move.");info.setTextSize(16);root.addView(info);
        Button accessibility=new Button(this);accessibility.setText("Open Accessibility Settings");accessibility.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));root.addView(accessibility);
        toggle=new Button(this);root.addView(toggle);toggle.setOnClickListener(v->{boolean on=!prefs.getBoolean("enabled",false);prefs.edit().putBoolean("enabled",on).apply();update();});
        status=new TextView(this);status.setTextSize(15);status.setPadding(0,20,0,0);root.addView(status);
        diagnostic=new TextView(this);diagnostic.setTextSize(16);diagnostic.setPadding(0,30,0,0);root.addView(diagnostic);
        setContentView(root);update();}
    @Override protected void onResume(){super.onResume();main.removeCallbacks(refresh);main.post(refresh);}
    @Override protected void onPause(){main.removeCallbacks(refresh);super.onPause();}
    private void update(){boolean on=prefs.getBoolean("enabled",false);toggle.setText(on?"BOT ON":"BOT OFF");status.setText(on?"Controlled bot is armed: one tap, wait, rescan.":"Bot is off.");diagnostic.setText("LAST RESULT:\n"+prefs.getString("diagnostic","No result yet."));}
}
