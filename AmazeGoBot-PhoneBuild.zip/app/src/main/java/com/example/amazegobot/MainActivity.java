package com.example.amazegobot;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("bot", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 64, 48, 48);

        TextView title = new TextView(this);
        title.setText("Amaze GO Bot");
        title.setTextSize(28);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("\nThis bot analyzes the Amaze GO board, finds arrows with a clear path to the edge, and taps them automatically.\n\n1. Enable the accessibility service.\n2. Return to Amaze GO.\n3. Turn the bot on below.\n\nStart with a level where losing a heart is acceptable while testing.");
        info.setTextSize(16);
        root.addView(info);

        Button accessibility = new Button(this);
        accessibility.setText("Open Accessibility Settings");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility);

        Button toggle = new Button(this);
        root.addView(toggle);
        View.OnClickListener listener = v -> {
            boolean on = !prefs.getBoolean("enabled", false);
            prefs.edit().putBoolean("enabled", on).apply();
            update(toggle);
        };
        toggle.setOnClickListener(listener);
        update(toggle);

        status = new TextView(this);
        status.setTextSize(14);
        status.setPadding(0, 24, 0, 0);
        root.addView(status);
        setContentView(root);
    }

    private void update(Button b) {
        boolean on = prefs.getBoolean("enabled", false);
        b.setText(on ? "BOT ON" : "BOT OFF");
        status.setText(on ? "Bot is armed. Open Amaze GO and leave the puzzle visible." :
                "Bot is off.");
    }
}
