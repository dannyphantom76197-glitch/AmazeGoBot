package com.example.amazegobot;

import android.graphics.Bitmap;
import android.graphics.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class ArrowDetector {
    public interface Progress { void onProgress(String s); }
    public static final class Tap { public final float x,y; Tap(float x,float y){this.x=x;this.y=y;} }
    public static final class Detection {
        public final Tap tap; public final boolean finished;
        public final int rawCandidates, keptCandidates, clearCandidates, bestScore;
        Detection(Tap t, boolean f, int raw, int kept, int clear, int score){tap=t;finished=f;rawCandidates=raw;keptCandidates=kept;clearCandidates=clear;bestScore=score;}
        public String summary(){return "raw="+rawCandidates+", arrows="+keptCandidates+", clear="+clearCandidates+", best="+bestScore;}
    }
    private static final int BROWN_R=135,BROWN_G=115,BROWN_B=90;
    private static boolean dark(int c){int r=Color.red(c),g=Color.green(c),b=Color.blue(c);return r<BROWN_R&&g<BROWN_G&&b<BROWN_B&&r>g&&g>=b;}
    private static boolean yellow(int c){int r=Color.red(c),g=Color.green(c),b=Color.blue(c);return r>180&&g>120&&b<130&&r>g;}
    private static boolean ink(int c){return dark(c)||yellow(c);}
    private static int score(Bitmap b,int x,int y,int dir){
        int w=b.getWidth(),h=b.getHeight(),vx=(dir==1?1:dir==3?-1:0),vy=(dir==2?1:dir==0?-1:0),px=-vy,py=vx,hit=0,total=0;
        for(int t=0;t<=8;t+=2){int hw=1+(t*3)/4,cx=x-vx*t,cy=y-vy*t;for(int q=-hw;q<=hw;q+=2){int xx=cx+px*q,yy=cy+py*q;if(xx>=0&&xx<w&&yy>=0&&yy<h){total++;if(ink(b.getPixel(xx,yy)))hit++;}}}
        for(int t=10;t<=16;t+=2){int cx=x-vx*t,cy=y-vy*t;for(int q=-2;q<=2;q+=2){int xx=cx+px*q,yy=cy+py*q;if(xx>=0&&xx<w&&yy>=0&&yy<h){total++;if(ink(b.getPixel(xx,yy)))hit++;}}}
        return total==0?0:(1000*hit)/total;
    }
    private static boolean clearRay(Bitmap b,int x,int y,int dir){
        int w=b.getWidth(),h=b.getHeight(),vx=(dir==1?1:dir==3?-1:0),vy=(dir==2?1:dir==0?-1:0);
        for(int t=8;t<900;t+=2){int xx=x+vx*t,yy=y+vy*t;if(xx<2||yy<2||xx>=w-2||yy>=h-2)return true;int hits=0;for(int q=-2;q<=2;q+=2){int px=xx+(-vy)*q,py=yy+vx*q;if(px>=0&&py>=0&&px<w&&py<h&&ink(b.getPixel(px,py)))hits++;}if(hits>=2)return false;}
        return true;
    }
    public static Detection detect(Bitmap b, Progress progress){
        int w=b.getWidth(),h=b.getHeight(),top=Math.max(240,(int)(h*.18)),bottom=Math.min(h-180,(int)(h*.84)),left=25,right=w-25;
        List<Candidate> candidates=new ArrayList<>();
        // Coarse scan: V5.5 checked every 2 pixels and could take too long on a 1080x2408 frame.
        // Step 6 cuts work dramatically, then we refine locally around strong coarse hits.
        for(int y=top;y<bottom;y+=3){
            for(int x=left;x<right;x+=3){int best=0,dir=-1;for(int d=0;d<4;d++){int s=score(b,x,y,d);if(s>best){best=s;dir=d;}}if(best>=430)candidates.add(new Candidate(x,y,best,dir));}
            if(progress!=null && ((y-top)%240)<3) progress.onProgress("coarse y="+y+" candidates="+candidates.size());
        }
        int raw=candidates.size();
        candidates.sort(Comparator.comparingInt((Candidate c)->c.score).reversed());
        List<Candidate> refined=new ArrayList<>();
        int limit=Math.min(1800,candidates.size());
        for(int i=0;i<limit;i++){
            Candidate c=candidates.get(i); Candidate bestC=c;
            for(int yy=c.y-4;yy<=c.y+4;yy+=2)for(int xx=c.x-4;xx<=c.x+4;xx+=2)for(int d=0;d<4;d++){int s=score(b,xx,yy,d);if(s>bestC.score)bestC=new Candidate(xx,yy,s,d);}
            if(bestC.score>=500)refined.add(bestC);
        }
        refined.sort(Comparator.comparingInt((Candidate c)->c.score).reversed());
        List<Candidate> kept=new ArrayList<>();
        for(Candidate c:refined){boolean near=false;for(Candidate k:kept){int dx=c.x-k.x,dy=c.y-k.y;if(dx*dx+dy*dy<14*14){near=true;break;}}if(!near)kept.add(c);if(kept.size()>=120)break;}
        if(progress!=null)progress.onProgress("raw="+raw+" refined arrows="+kept.size());
        if(kept.isEmpty())return new Detection(null,true,raw,0,0,0);
        Candidate best=null;int clear=0;for(Candidate c:kept)if(clearRay(b,c.x,c.y,c.dir)){clear++;if(best==null||c.score>best.score)best=c;}
        if(best==null)return new Detection(null,false,raw,kept.size(),0,kept.get(0).score);
        int vx=(best.dir==1?1:best.dir==3?-1:0),vy=(best.dir==2?1:best.dir==0?-1:0);
        return new Detection(new Tap(best.x-vx*5,best.y-vy*5),false,raw,kept.size(),clear,best.score);
    }
    private static final class Candidate{final int x,y,score,dir;Candidate(int x,int y,int score,int dir){this.x=x;this.y=y;this.score=score;this.dir=dir;}}
}
