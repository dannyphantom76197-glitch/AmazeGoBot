package com.example.amazegobot;

import android.graphics.Bitmap;
import android.graphics.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class ArrowDetector {
    public interface Progress { void onProgress(String s); }
    public static final class Tap { public final float x,y; public final int dir; Tap(float x,float y){this(x,y,-1);} Tap(float x,float y,int dir){this.x=x;this.y=y;this.dir=dir;} }
    public static final class Detection {
        public final Tap tap; public final boolean finished;
        public final int rawCandidates, keptCandidates, clearCandidates, bestScore;
        Detection(Tap t, boolean f, int raw, int kept, int clear, int score){tap=t;finished=f;rawCandidates=raw;keptCandidates=kept;clearCandidates=clear;bestScore=score;}
        public String summary(){return "raw="+rawCandidates+", arrowhead candidates="+keptCandidates+", head-ray clear="+clearCandidates+", best="+bestScore+"; FULL PATH NOT VERIFIED";}
    }
    private static final int BROWN_R=135,BROWN_G=115,BROWN_B=90;
    private static boolean dark(int c){int r=Color.red(c),g=Color.green(c),b=Color.blue(c);return r<BROWN_R&&g<BROWN_G&&b<BROWN_B&&r>g&&g>=b;}
    private static boolean yellow(int c){int r=Color.red(c),g=Color.green(c),b=Color.blue(c);return r>180&&g>120&&b<130&&r>g;}
    private static boolean ink(int c){return dark(c)||yellow(c);}
    private static int score(Bitmap b,int x,int y,int dir){
        int w=b.getWidth(),h=b.getHeight(),vx=(dir==1?1:dir==3?-1:0),vy=(dir==2?1:dir==0?-1:0),px=-vy,py=vx,hit=0,total=0;
        for(int t=0;t<=8;t+=2){int hw=1+(t*3)/4,cx=x-vx*t,cy=y-vy*t;for(int q=-hw;q<=hw;q+=2){int xx=cx+px*q,yy=cy+py*q;if(xx>=0&&xx<w&&yy>=0&&yy<h){total++;if(ink(b.getPixel(xx,yy)))hit++;}}}
        for(int t=10;t<=16;t+=2){int cx=x-vx*t,cy=y-vy*t;for(int q=-2;q<=2;q+=2){int xx=cx+px*q,yy=cy+py*q;if(xx>=0&&xx<w&&yy>=0&&yy<h){total++;if(ink(b.getPixel(xx,yy)))hit++;}}}
        return total==0?0:(1000*hit)/total;
    }
    // Conservative V6.3 safety check.  A move is accepted only when a wider corridor
    // in front of the arrow is clean all the way to the screen edge.  We skip the
    // arrowhead itself, then sample five parallel pixels at every step.  Any persistent
    // ink in that corridor is treated as an obstacle.  This intentionally prefers
    // "no move" over a questionable move that could cost a life.
    private static boolean clearRay(Bitmap b,int x,int y,int dir){
        int w=b.getWidth(),h=b.getHeight();
        int vx=(dir==1?1:dir==3?-1:0),vy=(dir==2?1:dir==0?-1:0);
        int px=-vy,py=vx;
        int suspiciousRun=0;
        for(int t=20;t<1200;t+=2){
            int xx=x+vx*t,yy=y+vy*t;
            if(xx<4||yy<4||xx>=w-4||yy>=h-4)return true;
            int hits=0;
            for(int q=-4;q<=4;q+=2){
                int sx=xx+px*q,sy=yy+py*q;
                if(sx>=0&&sy>=0&&sx<w&&sy<h&&ink(b.getPixel(sx,sy)))hits++;
            }
            // One isolated dark pixel can be antialiasing/noise. Two consecutive
            // suspicious samples, or a dense single sample, rejects the move.
            if(hits>=2)suspiciousRun++; else suspiciousRun=0;
            if(hits>=4||suspiciousRun>=2)return false;
        }
        return true;
    }
    public static Detection detect(Bitmap b, Progress progress){
        int w=b.getWidth(),h=b.getHeight(),top=Math.max(240,(int)(h*.18)),bottom=Math.min(h-180,(int)(h*.84)),left=25,right=w-25;
        List<Candidate> candidates=new ArrayList<>();
        // Coarse scan: V5.5 checked every 2 pixels and could take too long on a 1080x2408 frame.
        // Step 6 cuts work dramatically, then we refine locally around strong coarse hits.
        for(int y=top;y<bottom;y+=7){
            for(int x=left;x<right;x+=7){int best=0,dir=-1;for(int d=0;d<4;d++){int s=score(b,x,y,d);if(s>best){best=s;dir=d;}}if(best>=430)candidates.add(new Candidate(x,y,best,dir));}
            if(progress!=null && ((y-top)%240)<3) progress.onProgress("coarse y="+y+" candidates="+candidates.size());
        }
        int raw=candidates.size();
        candidates.sort(Comparator.comparingInt((Candidate c)->c.score).reversed());
        List<Candidate> refined=new ArrayList<>();
        int limit=Math.min(90,candidates.size());
        for(int i=0;i<limit;i++){
            Candidate c=candidates.get(i); Candidate bestC=c;
            for(int yy=c.y-4;yy<=c.y+4;yy+=2)for(int xx=c.x-4;xx<=c.x+4;xx+=2)for(int d=0;d<4;d++){int s=score(b,xx,yy,d);if(s>bestC.score)bestC=new Candidate(xx,yy,s,d);}
            if(bestC.score>=500)refined.add(bestC);
        }
        refined.sort(Comparator.comparingInt((Candidate c)->c.score).reversed());
        List<Candidate> kept=new ArrayList<>();
        for(Candidate c:refined){boolean near=false;for(Candidate k:kept){int dx=c.x-k.x,dy=c.y-k.y;if(dx*dx+dy*dy<14*14){near=true;break;}}if(!near)kept.add(c);if(kept.size()>=35)break;}
        if(progress!=null)progress.onProgress("raw="+raw+" refined arrows="+kept.size());
        if(kept.isEmpty())return new Detection(null,false,raw,0,0,0);
        Candidate best=null;int clear=0;
        for(Candidate c:kept){
            // Extra confidence gate: borderline arrow-shape matches are never tapped.
            if(c.score<620)continue;
            if(clearRay(b,c.x,c.y,c.dir)){clear++;if(best==null||c.score>best.score)best=c;}
        }
        if(best==null)return new Detection(null,false,raw,kept.size(),0,kept.get(0).score);
        int vx=(best.dir==1?1:best.dir==3?-1:0),vy=(best.dir==2?1:best.dir==0?-1:0);
        return new Detection(null,false,raw,kept.size(),clear,best.score);
    }
    private static final class Candidate{final int x,y,score,dir;Candidate(int x,int y,int score,int dir){this.x=x;this.y=y;this.score=score;this.dir=dir;}}
}
