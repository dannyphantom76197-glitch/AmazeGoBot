package com.example.amazegobot;

import android.graphics.Bitmap;
import android.graphics.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * First-pass, dependency-free vision solver for Amaze GO.
 *
 * It detects the dark-brown arrow graphics, scores four triangular arrowhead
 * templates, then chooses a head whose ray to the board edge contains no
 * other brown pixels. This is deliberately conservative: if confidence is
 * low it makes no tap rather than intentionally spending a heart.
 */
public final class ArrowDetector {
    public static final class Tap {
        public final float x, y;
        Tap(float x, float y) { this.x=x; this.y=y; }
    }
    public static final class Detection {
        public final Tap tap;
        public final boolean finished;
        Detection(Tap t, boolean f) { tap=t; finished=f; }
    }
    private static final int BROWN_R=135, BROWN_G=115, BROWN_B=90;

    private static boolean dark(int c) {
        int r=Color.red(c), g=Color.green(c), b=Color.blue(c);
        return r < BROWN_R && g < BROWN_G && b < BROWN_B && r > g && g >= b;
    }
    private static boolean yellow(int c) {
        int r=Color.red(c), g=Color.green(c), b=Color.blue(c);
        return r > 180 && g > 120 && b < 130 && r > g;
    }
    private static boolean ink(int c) { return dark(c) || yellow(c); }

    private static int score(Bitmap b, int x, int y, int dir) {
        // dir: 0 up, 1 right, 2 down, 3 left.
        int w=b.getWidth(), h=b.getHeight();
        int vx = (dir==1 ? 1 : dir==3 ? -1 : 0);
        int vy = (dir==2 ? 1 : dir==0 ? -1 : 0);
        int px = -vy, py = vx;
        int hit=0, total=0, outside=0;
        for (int t=0;t<=8;t++) {
            int hw=1+(t*3)/4;
            int cx=x-vx*t, cy=y-vy*t;
            for (int q=-hw;q<=hw;q++) {
                int xx=cx+px*q, yy=cy+py*q;
                if(xx>=0&&xx<w&&yy>=0&&yy<h) {
                    total++;
                    if(ink(b.getPixel(xx,yy))) hit++;
                }
            }
        }
        for (int t=9;t<=17;t++) {
            int cx=x-vx*t, cy=y-vy*t;
            for (int q=-2;q<=2;q++) {
                int xx=cx+px*q, yy=cy+py*q;
                if(xx>=0&&xx<w&&yy>=0&&yy<h) {
                    if(ink(b.getPixel(xx,yy))) hit++;
                    total++;
                }
            }
        }
        if(total==0) return 0;
        return (1000*hit)/total;
    }

    private static boolean clearRay(Bitmap b, int x, int y, int dir) {
        int w=b.getWidth(), h=b.getHeight();
        int vx=(dir==1?1:dir==3?-1:0), vy=(dir==2?1:dir==0?-1:0);
        int misses=0;
        // Start beyond the arrowhead tip. A few misses tolerate antialiasing.
        for(int t=7;t<900;t++) {
            int xx=x+vx*t, yy=y+vy*t;
            if(xx<2||yy<2||xx>=w-2||yy>=h-2) return true;
            int hits=0;
            for(int q=-2;q<=2;q++) {
                int px=xx + (-vy)*q, py=yy + vx*q;
                if(px>=0&&py>=0&&px<w&&py<h && ink(b.getPixel(px,py))) hits++;
            }
            if(hits>=2) return false;
        }
        return true;
    }

    public static Detection detect(Bitmap b) {
        int w=b.getWidth(), h=b.getHeight();
        // Restrict to the puzzle region. This also avoids status/header arrows.
        int top=Math.max(300, h/4);
        int bottom=Math.min(h-250, (int)(h*0.80));
        int left=25, right=w-25;

        List<Candidate> candidates=new ArrayList<>();
        // Scan at 2-pixel spacing; the arrow graphics are much larger than this.
        for(int y=top;y<bottom;y+=2) {
            for(int x=left;x<right;x+=2) {
                int best=0, bestDir=-1;
                for(int d=0;d<4;d++) {
                    int s=score(b,x,y,d);
                    if(s>best){best=s;bestDir=d;}
                }
                if(best>=760) candidates.add(new Candidate(x,y,best,bestDir));
            }
        }
        // Non-max suppression.
        candidates.sort(Comparator.comparingInt((Candidate c)->c.score).reversed());
        List<Candidate> kept=new ArrayList<>();
        for(Candidate c:candidates) {
            boolean near=false;
            for(Candidate k:kept) {
                int dx=c.x-k.x, dy=c.y-k.y;
                if(dx*dx+dy*dy<18*18) {near=true;break;}
            }
            if(!near) kept.add(c);
            if(kept.size()>=120) break;
        }
        if(kept.isEmpty()) return new Detection(null,true);

        // Prefer a candidate whose outward lane is actually clear.
        Candidate best=null;
        for(Candidate c:kept) {
            if(clearRay(b,c.x,c.y,c.dir)) {
                if(best==null || c.score>best.score) best=c;
            }
        }
        if(best==null) return new Detection(null,false);

        // Tap slightly behind the tip, where the arrow body is guaranteed to exist.
        int vx=(best.dir==1?1:best.dir==3?-1:0);
        int vy=(best.dir==2?1:best.dir==0?-1:0);
        return new Detection(new Tap(best.x-vx*5, best.y-vy*5),false);
    }

    private static final class Candidate {
        final int x,y,score,dir;
        Candidate(int x,int y,int score,int dir){this.x=x;this.y=y;this.score=score;this.dir=dir;}
    }
}
