package com.example.amazegobot;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class ArrowDetector {
    public interface Progress { void onProgress(String s); }
    public static final class Tap { public final float x,y; public final int dir; Tap(float x,float y){this(x,y,-1);} Tap(float x,float y,int dir){this.x=x;this.y=y;this.dir=dir;} }
    public static final class Detection {
        public final Tap tap; public final boolean finished;
        public final int rawCandidates, keptCandidates, clearCandidates, bestScore;
        public final int colorSamples, pathComponents;
        public final int[] componentsByColor;
        Detection(Tap t, boolean f, int raw, int kept, int clear, int score, int colors,int components,int[] byColor){componentsByColor=byColor;tap=t;finished=f;rawCandidates=raw;keptCandidates=kept;clearCandidates=clear;bestScore=score;colorSamples=colors;pathComponents=components;}
        public String summary(){return "geometry scan (chromatic-stroke and topology diagnostic); mask connected fragments="+pathComponents+" (not individual arrows)"+"; complete paths=0; verified safe moves=0, color samples="+colorSamples+", raw="+rawCandidates+", arrowhead candidates="+keptCandidates+", head-ray clear="+clearCandidates+", best="+bestScore+"; FULL PATH NOT VERIFIED";}
    }
    private static final int BROWN_R=135,BROWN_G=115,BROWN_B=90;
    private static boolean dark(int c){int r=Color.red(c),g=Color.green(c),b=Color.blue(c);return r<BROWN_R&&g<BROWN_G&&b<BROWN_B&&r>g&&g>=b;}
    private static boolean yellow(int c){int r=Color.red(c),g=Color.green(c),b=Color.blue(c);return r>180&&g>120&&b<130&&r>g;}
    private static boolean ink(int c){return dark(c)||yellow(c);}
    private static int score(Bitmap b,int x,int y,int dir){
        int w=b.getWidth(),h=b.getHeight(),vx=(dir==1?1:dir==3?-1:0),vy=(dir==2?1:dir==0?-1:0),px=-vy,py=vx,hit=0,total=0;
        for(int t=0;t<=8;t+=2){int hw=1+(t*3)/4,cx=x-vx*t,cy=y-vy*t;for(int q=-hw;q<=hw;q+=2){int xx=cx+px*q,yy=cy+py*q;if(xx>=0&&xx<w&&yy>=0&&yy<h){total++;if(pathPixel(b.getPixel(xx,yy)))hit++;}}}
        for(int t=10;t<=16;t+=2){int cx=x-vx*t,cy=y-vy*t;for(int q=-2;q<=2;q+=2){int xx=cx+px*q,yy=cy+py*q;if(xx>=0&&xx<w&&yy>=0&&yy<h){total++;if(pathPixel(b.getPixel(xx,yy)))hit++;}}}
        return total==0?0:(1000*hit)/total;
    }
    // Conservative V6.3 safety check.  A move is accepted only when a wider corridor
    // in front of the arrow is clean all the way to the screen edge.  We skip the
    // arrowhead itself, then sample five parallel pixels at every step.  Any persistent
    // ink in that corridor is treated as an obstacle.  This intentionally prefers
    // "no move" over a questionable move that could cost a life.
    private static boolean clearRay(Bitmap b,int x,int y,int dir){
        int w=b.getWidth(),h=b.getHeight();
        int vx=(dir==1?1:dir==3?-1:0),vy=(dir==2?1:dir==0?-1:0);
        int px=-vy,py=vx;
        int suspiciousRun=0;
        for(int t=20;t<1200;t+=2){
            int xx=x+vx*t,yy=y+vy*t;
            if(xx<4||yy<4||xx>=w-4||yy>=h-4)return true;
            int hits=0;
            for(int q=-4;q<=4;q+=2){
                int sx=xx+px*q,sy=yy+py*q;
                if(sx>=0&&sy>=0&&sx<w&&sy<h&&ink(b.getPixel(sx,sy)))hits++;
            }
            // One isolated dark pixel can be antialiasing/noise. Two consecutive
            // suspicious samples, or a dense single sample, rejects the move.
            if(hits>=2)suspiciousRun++; else suspiciousRun=0;
            if(hits>=4||suspiciousRun>=2)return false;
        }
        return true;
    }
    // Experimental color connected-components scan. Counts isolated strokes; it does
    // not establish that one component equals one movable arrow.
    public static int colorLabel(int c){
        int r=Color.red(c),g=Color.green(c),bl=Color.blue(c);
        int hi=Math.max(r,Math.max(g,bl)),lo=Math.min(r,Math.min(g,bl));
        if(hi-lo<45||hi<100||lo>=225)return 0;
        // Test orange before red; previous ordering counted orange strokes as red.
        if(r>bl*1.3&&g>bl*1.2&&g>=r*.48&&g<=r*.94)return 2;
        if(r>g*1.22&&r>bl*1.2)return 1;
        if(g>r*1.16&&g>bl*1.05)return 3;
        if(bl>r*1.16&&bl>g*1.05)return 4;
        return 5;
    }
    // V8.1: color-neutral geometry preview. Hue is never used to prioritize moves.
    // Saturation distinguishes drawn paths from the near-white background.
    // V8.7: brightness/contrast-first stroke test. No hue or color-name gate.
    // Bright game backgrounds are nearly white; thin pastel lines still have
    // measurable chroma or luminance contrast. This is diagnostic segmentation,
    // NOT complete-arrow reconstruction.
    // V9.2 diagnostic-only chromatic stroke filter. Do not include dark/gray
    // pixels: the white board, shadows and app chrome are not arrow geometry.
    // Pink/magenta surrounding UI is also explicitly excluded.
    private static boolean pathPixel(int c){
        int r=Color.red(c),g=Color.green(c),bl=Color.blue(c);
        int hi=Math.max(r,Math.max(g,bl)),lo=Math.min(r,Math.min(g,bl));
        if(hi<95 || hi-lo<24 || lo>235)return false;
        if(r>g+32 && bl>g+28)return false; // magenta wallpaper/UI
        boolean red=r>g+25 && r>bl+20 && g>=bl-18;
        boolean green=g>r+15 && g>bl+8;
        boolean blue=bl>r+17 && bl>g+7;
        boolean yellow=r>bl+38 && g>bl+25 && r>=g-20;
        return red||green||blue||yellow;
    }
    public static Bitmap debugMask(Bitmap b){
        int w=b.getWidth(),h=b.getHeight();
        int ow=Math.max(1,w/3),oh=Math.max(1,h/3);
        Bitmap out=Bitmap.createBitmap(ow,oh,Bitmap.Config.ARGB_8888);
        int top=Math.max(240,(int)(h*.18)),bottom=Math.min(h-180,(int)(h*.84));
        // Use a thin centerline-preserving sample, not an any-of-nine dilation.
        // The old 3x3 OR joined neighboring parallel arrows and filled dense areas.
        for(int y=0;y<oh;y++)for(int x=0;x<ow;x++){
            int sx=Math.min(w-1,x*3+1),sy=Math.min(h-1,y*3+1);
            boolean on=false;
            if(sy>=top&&sy<bottom&&sx>=25&&sx<w-25){
                int hits=0;
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
                    int xx=sx+dx,yy=sy+dy;
                    if(xx>=0&&yy>=0&&xx<w&&yy<h&&pathPixel(b.getPixel(xx,yy)))hits++;
                }
                on=pathPixel(b.getPixel(sx,sy)) || hits>=4;
            }
            out.setPixel(x,y,on?Color.WHITE:Color.BLACK);
        }
        return out;
    }
    // V8.7: label pixels of connected regions, without misleading overlapping boxes.
    // These are still image fragments; connectedness alone does not prove arrow identity.
    public static Bitmap debugComponents(Bitmap source){
        Bitmap mask=debugMask(source);
        int w=mask.getWidth(),h=mask.getHeight(),n=w*h;
        boolean[] seen=new boolean[n];int[] queue=new int[n];
        List<int[]> regions=new ArrayList<>();
        for(int start=0;start<n;start++){
            if(seen[start]||mask.getPixel(start%w,start/w)!=Color.WHITE)continue;
            int head=0,tail=0;long sumX=0,sumY=0;
            queue[tail++]=start;seen[start]=true;
            while(head<tail){
                int pos=queue[head++],x=pos%w,y=pos/w;
                sumX+=x;sumY+=y;
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
                    if(dx==0&&dy==0)continue;
                    int xx=x+dx,yy=y+dy;
                    if(xx<0||yy<0||xx>=w||yy>=h)continue;
                    int next=yy*w+xx;
                    if(!seen[next]&&mask.getPixel(xx,yy)==Color.WHITE){seen[next]=true;queue[tail++]=next;}
                }
            }
            if(tail>=7)regions.add(new int[]{(int)(sumX/tail),(int)(sumY/tail),tail});
        }
        regions.sort((a,b)->Integer.compare(b[2],a[2]));
        Bitmap overlay=mask.copy(Bitmap.Config.ARGB_8888,true);
        int[] topologyCounts=topology(mask,overlay);mask.recycle();
        Canvas canvas=new Canvas(overlay);Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.rgb(255,180,0));paint.setStyle(Paint.Style.FILL);paint.setTextSize(9f);
        for(int i=0;i<Math.min(60,regions.size());i++){
            int[] r=regions.get(i);
            canvas.drawText(String.valueOf(i+1),r[0]+2,r[1]-2,paint);
        }
        // Draw a compact legend inside the mask: region labels are NOT arrow IDs.
        int longRegions=0;
        for(int[] r:regions)if(r[2]>=20)longRegions++;
        paint.setColor(Color.rgb(255,215,70));paint.setTextSize(10f);
        canvas.drawText("V9.2 FRAGMENTS "+regions.size()+" LONG "+longRegions,8,Math.max(12,h/5),paint);
        canvas.drawText("CYAN endpoints "+topologyCounts[0]+"  PINK junctions "+topologyCounts[1],8,Math.max(25,h/5+13),paint);
        canvas.drawText("UNVERIFIED GRAPH - NO TAPS",8,Math.max(38,h/5+26),paint);
        return overlay;
    }
    // V9.2 diagnostic: graph topology on the downsampled stroke mask.
    // Endpoint/branch counts are *not* verified arrows; crossings and sampling
    // artifacts can create extra nodes. Never authorize a tap from these counts.
    private static int[] topology(Bitmap mask, Bitmap overlay){
        int w=mask.getWidth(),h=mask.getHeight(),ends=0,junctions=0;
        Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);
        Canvas canvas=overlay==null?null:new Canvas(overlay);
        for(int y=2;y<h-2;y++)for(int x=2;x<w-2;x++){
            if(mask.getPixel(x,y)!=Color.WHITE)continue;
            boolean[] ring=new boolean[8];
            int[] dx={0,1,1,1,0,-1,-1,-1};
            int[] dy={-1,-1,0,1,1,1,0,-1};
            int neighbors=0,transitions=0;
            for(int i=0;i<8;i++){
                ring[i]=mask.getPixel(x+dx[i],y+dy[i])==Color.WHITE;
                if(ring[i])neighbors++;
            }
            for(int i=0;i<8;i++)if(!ring[i]&&ring[(i+1)%8])transitions++;
            // Count only centerline-like pixels with a locally thin neighborhood.
            if(neighbors<=2&&transitions==1){
                ends++;if(canvas!=null){pen.setColor(Color.CYAN);canvas.drawCircle(x,y,2.3f,pen);}
            }else if(transitions>=3){
                junctions++;if(canvas!=null){pen.setColor(Color.MAGENTA);canvas.drawCircle(x,y,2.0f,pen);}
            }
        }
        return new int[]{ends,junctions};
    }
    public static int[] countTopology(Bitmap source){
        Bitmap mask=debugMask(source);
        int[] counts=topology(mask,null);mask.recycle();return counts;
    }
    public static int countMaskFragments(Bitmap source){
        Bitmap mask=debugMask(source);
        int w=mask.getWidth(),h=mask.getHeight(),n=w*h,count=0;
        boolean[] seen=new boolean[n];int[] queue=new int[n];
        for(int start=0;start<n;start++){
            if(seen[start]||mask.getPixel(start%w,start/w)!=Color.WHITE)continue;
            int head=0,tail=0;queue[tail++]=start;seen[start]=true;
            while(head<tail){
                int pos=queue[head++],x=pos%w,y=pos/w;
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
                    int xx=x+dx,yy=y+dy;
                    if(xx<0||yy<0||xx>=w||yy>=h)continue;
                    int next=yy*w+xx;
                    if(!seen[next]&&mask.getPixel(xx,yy)==Color.WHITE){seen[next]=true;queue[tail++]=next;}
                }
            }
            if(tail>=7)count++;
        }
        mask.recycle();return count;
    }
    private static int[] countComponents(Bitmap b,int left,int top,int right,int bottom){
        final int step=3,gw=(right-left+step-1)/step,gh=(bottom-top+step-1)/step;
        if(gw<=0||gh<=0)return new int[6];
        byte[] mask=new byte[gw*gh];
        for(int y=0;y<gh;y++)for(int x=0;x<gw;x++){
            int sx=Math.min(right-1,left+x*step),sy=Math.min(bottom-1,top+y*step);
            mask[y*gw+x]=(byte)(pathPixel(b.getPixel(sx,sy))?1:0);
        }
        int[] queue=new int[gw*gh];int[] components=new int[6];
        for(int i=0;i<mask.length;i++){
            int label=mask[i];if(label==0)continue;
            int head=0,tail=0;queue[tail++]=i;mask[i]=0;
            while(head<tail){
                int v=queue[head++],x=v%gw,y=v/gw;
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
                    if(dx==0&&dy==0)continue;
                    int xx=x+dx,yy=y+dy;
                    if(xx<0||yy<0||xx>=gw||yy>=gh)continue;
                    int ni=yy*gw+xx;
                    if(mask[ni]==label){mask[ni]=0;queue[tail++]=ni;}
                }
            }
            if(tail>=7)components[label]++;
        }
        return components;
    }
    public static Detection detect(Bitmap b, Progress progress){
        int w=b.getWidth(),h=b.getHeight(),top=Math.max(240,(int)(h*.18)),bottom=Math.min(h-180,(int)(h*.84)),left=25,right=w-25;
        int colorSamples=0;
        for(int cy=top;cy<bottom;cy+=5)for(int cx=left;cx<right;cx+=5){
            int pixel=b.getPixel(cx,cy),r=Color.red(pixel),g=Color.green(pixel),bl=Color.blue(pixel);
            int hi=Math.max(r,Math.max(g,bl)),lo=Math.min(r,Math.min(g,bl));
            if(hi-lo>=42 && hi>=95 && lo<220)colorSamples++;
        }
        int[] byColor=countComponents(b,left,top,right,bottom);
        int components=countMaskFragments(b);
        int[] graph=countTopology(b);
        if(progress!=null)progress.onProgress("V9.2 fragments="+components+" endpoints="+graph[0]+" junctions="+graph[1]+" (unverified)");
        List<Candidate> candidates=new ArrayList<>();
        // Coarse scan: V5.5 checked every 2 pixels and could take too long on a 1080x2408 frame.
        // Step 6 cuts work dramatically, then we refine locally around strong coarse hits.
        for(int y=top;y<bottom;y+=7){
            for(int x=left;x<right;x+=7){int best=0,dir=-1;for(int d=0;d<4;d++){int s=score(b,x,y,d);if(s>best){best=s;dir=d;}}if(best>=430)candidates.add(new Candidate(x,y,best,dir));}
            if(progress!=null && ((y-top)%240)<3) progress.onProgress("coarse y="+y+" candidates="+candidates.size());
        }
        int raw=candidates.size();
        candidates.sort(Comparator.comparingInt((Candidate c)->c.score).reversed());
        List<Candidate> refined=new ArrayList<>();
        int limit=Math.min(90,candidates.size());
        for(int i=0;i<limit;i++){
            Candidate c=candidates.get(i); Candidate bestC=c;
            for(int yy=c.y-4;yy<=c.y+4;yy+=2)for(int xx=c.x-4;xx<=c.x+4;xx+=2)for(int d=0;d<4;d++){int s=score(b,xx,yy,d);if(s>bestC.score)bestC=new Candidate(xx,yy,s,d);}
            if(bestC.score>=500)refined.add(bestC);
        }
        refined.sort(Comparator.comparingInt((Candidate c)->c.score).reversed());
        List<Candidate> kept=new ArrayList<>();
        for(Candidate c:refined){boolean near=false;for(Candidate k:kept){int dx=c.x-k.x,dy=c.y-k.y;if(dx*dx+dy*dy<14*14){near=true;break;}}if(!near)kept.add(c);if(kept.size()>=35)break;}
        if(progress!=null)progress.onProgress("raw="+raw+" refined arrows="+kept.size());
        if(kept.isEmpty())return new Detection(null,false,raw,0,0,0,colorSamples,components,byColor);
        Candidate best=null;int clear=0;
        for(Candidate c:kept){
            // Extra confidence gate: borderline arrow-shape matches are never tapped.
            if(c.score<620)continue;
            if(clearRay(b,c.x,c.y,c.dir)){clear++;if(best==null||c.score>best.score)best=c;}
        }
        if(best==null)return new Detection(null,false,raw,kept.size(),0,kept.get(0).score,colorSamples,components,byColor);
        int vx=(best.dir==1?1:best.dir==3?-1:0),vy=(best.dir==2?1:best.dir==0?-1:0);
        return new Detection(null,false,raw,kept.size(),clear,best.score,colorSamples,components,byColor);
    }
    private static final class Candidate{final int x,y,score,dir;Candidate(int x,int y,int score,int dir){this.x=x;this.y=y;this.score=score;this.dir=dir;}}
}
