package com.example.amazegobot;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class ArrowDetector {
    public interface Progress { void onProgress(String s); }
    public static final class Tap { public final float x,y; public final int dir; Tap(float x,float y){this(x,y,-1);} Tap(float x,float y,int dir){this.x=x;this.y=y;this.dir=dir;} }
    public static final class Detection {
        public final Tap tap; public final boolean finished;
        public final int rawCandidates, keptCandidates, clearCandidates, bestScore;
        public final int colorSamples, pathComponents;
        public final int[] componentsByColor;
        Detection(Tap t, boolean f, int raw, int kept, int clear, int score, int colors,int components,int[] byColor){componentsByColor=byColor;tap=t;finished=f;rawCandidates=raw;keptCandidates=kept;clearCandidates=clear;bestScore=score;colorSamples=colors;pathComponents=components;}
        public String summary(){return "geometry scan (chromatic-stroke and topology diagnostic); mask connected fragments="+pathComponents+" (not individual arrows)"+"; complete paths=0; verified safe moves=0, color samples="+colorSamples+", raw="+rawCandidates+", arrowhead candidates="+keptCandidates+", head-ray clear="+clearCandidates+", best="+bestScore+"; FULL PATH NOT VERIFIED";}
    }
    private static final int BROWN_R=135,BROWN_G=115,BROWN_B=90;
    private static boolean dark(int c){int r=Color.red(c),g=Color.green(c),b=Color.blue(c);return r<BROWN_R&&g<BROWN_G&&b<BROWN_B&&r>g&&g>=b;}
    private static boolean yellow(int c){int r=Color.red(c),g=Color.green(c),b=Color.blue(c);return r>180&&g>120&&b<130&&r>g;}
    private static boolean ink(int c){return dark(c)||yellow(c);}
    private static int score(Bitmap b,int x,int y,int dir){
        int w=b.getWidth(),h=b.getHeight(),vx=(dir==1?1:dir==3?-1:0),vy=(dir==2?1:dir==0?-1:0),px=-vy,py=vx,hit=0,total=0;
        for(int t=0;t<=8;t+=2){int hw=1+(t*3)/4,cx=x-vx*t,cy=y-vy*t;for(int q=-hw;q<=hw;q+=2){int xx=cx+px*q,yy=cy+py*q;if(xx>=0&&xx<w&&yy>=0&&yy<h){total++;if(pathPixel(b.getPixel(xx,yy)))hit++;}}}
        for(int t=10;t<=16;t+=2){int cx=x-vx*t,cy=y-vy*t;for(int q=-2;q<=2;q+=2){int xx=cx+px*q,yy=cy+py*q;if(xx>=0&&xx<w&&yy>=0&&yy<h){total++;if(pathPixel(b.getPixel(xx,yy)))hit++;}}}
        return total==0?0:(1000*hit)/total;
    }
    // Conservative V6.3 safety check.  A move is accepted only when a wider corridor
    // in front of the arrow is clean all the way to the screen edge.  We skip the
    // arrowhead itself, then sample five parallel pixels at every step.  Any persistent
    // ink in that corridor is treated as an obstacle.  This intentionally prefers
    // "no move" over a questionable move that could cost a life.
    private static boolean clearRay(Bitmap b,int x,int y,int dir){
        int w=b.getWidth(),h=b.getHeight();
        int vx=(dir==1?1:dir==3?-1:0),vy=(dir==2?1:dir==0?-1:0);
        int px=-vy,py=vx;
        int suspiciousRun=0;
        for(int t=20;t<1200;t+=2){
            int xx=x+vx*t,yy=y+vy*t;
            if(xx<4||yy<4||xx>=w-4||yy>=h-4)return true;
            int hits=0;
            for(int q=-4;q<=4;q+=2){
                int sx=xx+px*q,sy=yy+py*q;
                if(sx>=0&&sy>=0&&sx<w&&sy<h&&ink(b.getPixel(sx,sy)))hits++;
            }
            // One isolated dark pixel can be antialiasing/noise. Two consecutive
            // suspicious samples, or a dense single sample, rejects the move.
            if(hits>=2)suspiciousRun++; else suspiciousRun=0;
            if(hits>=4||suspiciousRun>=2)return false;
        }
        return true;
    }
    // Experimental color connected-components scan. Counts isolated strokes; it does
    // not establish that one component equals one movable arrow.
    public static int colorLabel(int c){
        int r=Color.red(c),g=Color.green(c),bl=Color.blue(c);
        int hi=Math.max(r,Math.max(g,bl)),lo=Math.min(r,Math.min(g,bl));
        if(hi-lo<45||hi<100||lo>=225)return 0;
        // Test orange before red; previous ordering counted orange strokes as red.
        if(r>bl*1.3&&g>bl*1.2&&g>=r*.48&&g<=r*.94)return 2;
        if(r>g*1.22&&r>bl*1.2)return 1;
        if(g>r*1.16&&g>bl*1.05)return 3;
        if(bl>r*1.16&&bl>g*1.05)return 4;
        return 5;
    }
    // V8.1: color-neutral geometry preview. Hue is never used to prioritize moves.
    // Saturation distinguishes drawn paths from the near-white background.
    // V8.7: brightness/contrast-first stroke test. No hue or color-name gate.
    // Bright game backgrounds are nearly white; thin pastel lines still have
    // measurable chroma or luminance contrast. This is diagnostic segmentation,
    // NOT complete-arrow reconstruction.
    // V9.2 diagnostic-only chromatic stroke filter. Do not include dark/gray
    // pixels: the white board, shadows and app chrome are not arrow geometry.
    // Pink/magenta surrounding UI is also explicitly excluded.
    private static boolean pathPixel(int c){
        int r=Color.red(c),g=Color.green(c),bl=Color.blue(c);
        int hi=Math.max(r,Math.max(g,bl)),lo=Math.min(r,Math.min(g,bl));
        if(hi<95 || hi-lo<24 || lo>235)return false;
        // Pink/magenta is the primary arrow ink on Level 452. Exclude UI by board ROI, not hue.
        boolean red=r>g+25 && r>bl+20 && g>=bl-18;
        boolean magenta=r>g+30 && bl>g+25 && Math.abs(r-bl)<115;
        boolean green=g>r+15 && g>bl+8;
        boolean blue=bl>r+17 && bl>g+7;
        boolean yellow=r>bl+38 && g>bl+25 && r>=g-20;
        return red||magenta||green||blue||yellow;
    }
    // V10.6: locate puzzle ink by row/column occupancy, excluding screen-edge UI.
    // Return {left,top,right,bottom}; bounds are diagnostic, not a collision proof.
    private static int[] boardRoi(Bitmap b){
        int w=b.getWidth(),h=b.getHeight();
        int leftLimit=Math.max(20,w/10),rightLimit=w-leftLimit;
        int topLimit=Math.max(100,h/12),bottomLimit=Math.min(h-70,h*9/10);
        int[] rows=new int[h],cols=new int[w];
        for(int y=topLimit;y<bottomLimit;y+=2)for(int x=leftLimit;x<rightLimit;x+=2){
            int c=b.getPixel(x,y);
            int r=Color.red(c),g=Color.green(c),bl=Color.blue(c);
            if(r>g+30&&bl>g+25&&Math.abs(r-bl)<115&&r>105){rows[y]++;cols[x]++;}
        }
        int firstY=-1,lastY=-1,firstX=-1,lastX=-1;
        for(int y=topLimit;y<bottomLimit;y+=2)if(rows[y]>=4){if(firstY<0)firstY=y;lastY=y;}
        for(int x=leftLimit;x<rightLimit;x+=2)if(cols[x]>=4){if(firstX<0)firstX=x;lastX=x;}
        if(firstY<0||firstX<0||lastY-firstY<80||lastX-firstX<80)
            return new int[]{leftLimit,topLimit,rightLimit,bottomLimit};
        return new int[]{Math.max(leftLimit,firstX-14),Math.max(topLimit,firstY-14),
                Math.min(rightLimit,lastX+16),Math.min(bottomLimit,lastY+16)};
    }
    // V9.5: native-resolution color-neutral stroke preview. No downsampling,
    // so closely spaced lines remain visible for manual topology validation.
    // This is NOT a solved arrow graph and must not authorize gestures.
    public static Bitmap debugNativeMask(Bitmap b){
        int w=b.getWidth(),h=b.getHeight();
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        int[] roi=boardRoi(b);int top=roi[1],bottom=roi[3];
        int[] pixels=new int[w];
        for(int y=0;y<h;y++){
            b.getPixels(pixels,0,w,0,y,w,1);
            for(int x=0;x<w;x++){
                boolean on=y>=top&&y<bottom&&x>=roi[0]&&x<roi[2]&&pathPixel(pixels[x]);
                pixels[x]=on?Color.BLACK:Color.WHITE;
            }
            out.setPixels(pixels,0,w,0,y,w,1);
        }
        return out;
    }
    // V9.9: candidate reconstruction and directional tip hypotheses overlay, intentionally diagnostic only.
    // Each same-hue connected stroke is a candidate, NOT a proven game arrow.
    public static Bitmap debugNativeComponents(Bitmap source) {
        int w=source.getWidth(),h=source.getHeight(),n=w*h;
        int[] pixels=new int[n];source.getPixels(pixels,0,w,0,0,w,h);
        int x0=w/12,x1=w-w/12;
        // Locate all dense puzzle rows; pad enough to retain edge-pointing heads.
        int[] rows=new int[h];
        for(int y=h/4;y<h*4/5;y+=2)for(int x=x0;x<x1;x+=2)
            if(pathPixel(pixels[y*w+x]))rows[y]++;
        int first=-1,last=-1;
        for(int y=h/4;y<h*4/5;y+=2)if(rows[y]>=6){
            if(first<0)first=y;last=y;
        }
        int top=first<0?h/3:Math.max(h/5,first-35);
        int bottom=last<0?h*3/4:Math.min(h*4/5,last+37);
        byte[] labels=new byte[n];
        for(int y=top;y<bottom;y++)for(int x=x0;x<x1;x++)
            if(pathPixel(pixels[y*w+x]))labels[y*w+x]=(byte)colorLabel(pixels[y*w+x]);
        Bitmap output=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        output.eraseColor(Color.WHITE);
        Canvas canvas=new Canvas(output);Paint pen=new Paint(3);
        pen.setColor(Color.rgb(0,130,80));pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(3);
        canvas.drawRect(x0,top,x1,bottom,pen);
        int[] queue=new int[n];int count=0,large=0,edge=0,tipHypotheses=0,ambiguous=0;
        int localTips=0, multiTips=0;
        int[] palette={Color.rgb(25,100,210),Color.rgb(210,50,150),
                       Color.rgb(0,135,110),Color.rgb(160,85,15)};
        for(int y=top;y<bottom;y++)for(int x=x0;x<x1;x++){
            int start=y*w+x,label=labels[start]&255;if(label==0)continue;
            int head=0,tail=0,minX=x,maxX=x,minY=y,maxY=y;
            queue[tail++]=start;labels[start]=0;
            while(head<tail){
                int i=queue[head++],cx=i%w,cy=i/w;
                minX=Math.min(minX,cx);maxX=Math.max(maxX,cx);
                minY=Math.min(minY,cy);maxY=Math.max(maxY,cy);
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
                    if(dx==0&&dy==0)continue;
                    int xx=cx+dx,yy=cy+dy;
                    if(xx<x0||xx>=x1||yy<top||yy>=bottom)continue;
                    int next=yy*w+xx;
                    if((labels[next]&255)==label){labels[next]=0;queue[tail++]=next;}
                }
            }
            if(tail<45)continue;
            count++;if(tail>=100)large++;
            boolean boundary=minX<=x0+2||maxX>=x1-3||minY<=top+2||maxY>=bottom-3;
            if(boundary)edge++;
            pen.setColor(palette[(count-1)%palette.length]);pen.setStrokeWidth(2);
            pen.setStyle(Paint.Style.STROKE);
            // Highlight the actual connected pixels, not just its bounding box.
            for(int k=0;k<tail;k++){
                int i=queue[k];canvas.drawPoint(i%w,i/w,pen);
            }
            // V10.0: test all four extremes with local cross-sections, rather than
            // demanding exactly one plausible extreme for the whole component.
            // This is only a tip likelihood: a component may include multiple arrows.
            int[] near=new int[4],shoulder=new int[4],center=new int[4];
            long[] tipX=new long[4],tipY=new long[4];
            for(int k=0;k<tail;k++){
                int pos=queue[k],cx=pos%w,cy=pos/w;
                int[] distance={cy-minY,maxX-cx,maxY-cy,cx-minX};
                for(int d=0;d<4;d++){
                    int dist=distance[d];
                    if(dist<=3){near[d]++;tipX[d]+=cx;tipY[d]+=cy;}
                    if(dist>=5&&dist<=11)shoulder[d]++;
                    if(dist>=13&&dist<=21)center[d]++;
                }
            }
            int chosen=-1,bestEvidence=0,plausible=0;
            for(int d=0;d<4;d++){
                // Narrow terminal with a wider shoulder is consistent with a tip.
                // Require support farther inward to reject isolated noisy pixels.
                int evidence=shoulder[d]*10/Math.max(1,near[d]);
                if(near[d]>=1&&near[d]<=35&&shoulder[d]>=6
                        &&center[d]>=6&&evidence>=13){
                    plausible++;
                    if(evidence>bestEvidence){bestEvidence=evidence;chosen=d;}
                }
            }
            if(chosen>=0){
                tipHypotheses++;
                int tx=(int)(tipX[chosen]/Math.max(1,near[chosen]));
                int ty=(int)(tipY[chosen]/Math.max(1,near[chosen]));
                pen.setColor(plausible==1?Color.rgb(20,130,30):Color.rgb(230,125,0));
                pen.setStyle(Paint.Style.FILL);canvas.drawCircle(tx,ty,6,pen);
                pen.setTextSize(15);
                canvas.drawText(new String[]{"UP?","RIGHT?","DOWN?","LEFT?"}[chosen]
                        +" "+bestEvidence+(plausible>1?" MULTI":""),tx+7,ty-7,pen);
            }
            if(plausible!=1)ambiguous++;
            // V10.1: count local terminal neighborhoods, not just four GLOBAL
            // bounding-box extremes. These are shape clues, never verified arrows.
            // A component can contain multiple adjacent game arrows.
            int terminals=0;
            boolean[] member=new boolean[n];
            for(int k=0;k<tail;k++)member[queue[k]]=true;
            java.util.ArrayList<Integer> terminalCenters=new java.util.ArrayList<>();
            for(int k=0;k<tail;k+=2){
                int pos=queue[k],cx=pos%w,cy=pos/w;
                int neighbors=0;
                for(int dy=-3;dy<=3;dy++)for(int dx=-3;dx<=3;dx++){
                    if(dx==0&&dy==0||dx*dx+dy*dy>9)continue;
                    int xx=cx+dx,yy=cy+dy;
                    if(xx>=0&&xx<w&&yy>=0&&yy<h&&member[yy*w+xx])neighbors++;
                }
                if(neighbors>=1&&neighbors<=5){
                    // Cluster nearby terminal pixels into a single clue.
                    boolean separated=true;
                    for(int other:terminalCenters){
                        int dx=other%w-cx,dy=other/w-cy;
                        if(dx*dx+dy*dy<=100){separated=false;break;}
                    }
                    if(separated){terminals++;terminalCenters.add(pos);}
                }
            }
            localTips+=terminals;
            if(terminals>2)multiTips++;
            pen.setColor(palette[(count-1)%palette.length]);
            pen.setStyle(Paint.Style.STROKE);
            pen.setStrokeWidth(2);canvas.drawRect(minX-2,minY-2,maxX+2,maxY+2,pen);
            pen.setStyle(Paint.Style.FILL);pen.setTextSize(19);
            canvas.drawText("C"+count+(boundary?"*":""),minX,Math.max(top+20,minY-4),pen);
        }
        pen.setStyle(Paint.Style.FILL);pen.setColor(Color.rgb(0,65,160));pen.setTextSize(29);
        canvas.drawText("V10.0 STROKE CANDIDATES: "+count,25,85,pen);
        canvas.drawText("LARGE: "+large+" EDGE RETAINED: "+edge,25,125,pen);
        canvas.drawText("TIP GUESSES (NOT VERIFIED): "+tipHypotheses+" AMBIGUOUS: "+ambiguous,25,165,pen);
        canvas.drawText("LOCAL TERMINAL CLUES: "+localTips+" MULTI: "+multiTips,25,205,pen);
        canvas.drawText("NO VERIFIED ARROWS / NO TAPS",25,245,pen);
        return output;
    }
    // V10.2 visual comparison of head-shape candidates and forward corridors.
    // A clear HEAD corridor does not prove that a bent arrow's entire body can exit.
    public static Bitmap debugHeadCorridors(Bitmap source) {
        int w=source.getWidth(), h=source.getHeight();
        Bitmap out=source.copy(Bitmap.Config.ARGB_8888,true);
        Canvas canvas=new Canvas(out);
        Paint pen=new Paint(3);
        int[] roi=boardRoi(b);int top=roi[1],bottom=roi[3];
        List<Candidate> coarse=new ArrayList<>();
        for(int y=top;y<bottom;y+=10)for(int x=25;x<w-25;x+=10){
            int best=0,dir=-1;
            for(int d=0;d<4;d++){int v=score(source,x,y,d);if(v>best){best=v;dir=d;}}
            if(best>=620)coarse.add(new Candidate(x,y,best,dir));
        }
        coarse.sort(Comparator.comparingInt((Candidate c)->c.score).reversed());
        List<Candidate> selected=new ArrayList<>();
        for(Candidate c:coarse){
            boolean nearby=false;
            for(Candidate k:selected){int dx=k.x-c.x,dy=k.y-c.y;
                if(dx*dx+dy*dy<22*22){nearby=true;break;}}
            if(!nearby)selected.add(c);
            if(selected.size()>=45)break;
        }
        int clear=0;
        pen.setTextSize(19);pen.setStrokeWidth(3);
        for(Candidate c:selected){
            boolean ray=clearRay(source,c.x,c.y,c.dir);
            if(ray)clear++;
            pen.setColor(ray?Color.rgb(0,155,65):Color.rgb(235,60,55));
            pen.setStyle(Paint.Style.STROKE);
            canvas.drawCircle(c.x,c.y,10,pen);
            int vx=c.dir==1?1:c.dir==3?-1:0;
            int vy=c.dir==2?1:c.dir==0?-1:0;
            // Short guide shows tested heading, not a reconstructed arrow body.
            canvas.drawLine(c.x+vx*13,c.y+vy*13,c.x+vx*35,c.y+vy*35,pen);
        }
        pen.setStyle(Paint.Style.FILL);
        pen.setColor(Color.rgb(25,25,25));
        canvas.drawRect(0,0,w,185,pen);
        pen.setColor(Color.WHITE);pen.setTextSize(25);
        canvas.drawText("V10.2 HEAD / RAY EVIDENCE",20,45,pen);
        pen.setTextSize(21);
        canvas.drawText("Head hypotheses: "+selected.size()+"  clear rays: "+clear,20,83,pen);
        canvas.drawText("GREEN=clear head ray  RED=blocked",20,119,pen);
        canvas.drawText("NOT complete paths. NO AUTO TAPS.",20,155,pen);
        return out;
    }
    // V10.3: diagnostic-only backward stroke continuity probe. This does not
    // reconstruct bent bodies and must NEVER authorize a tap.
    private static int backwardContinuity(Bitmap b,int x,int y,int dir){
        int vx=dir==1?1:dir==3?-1:0,vy=dir==2?1:dir==0?-1:0;
        int px=-vy,py=vx,run=0,best=0;
        for(int t=12;t<=112;t+=3){
            int cx=x-vx*t,cy=y-vy*t;
            if(cx<6||cy<6||cx>=b.getWidth()-6||cy>=b.getHeight()-6)break;
            boolean present=false;
            for(int q=-2;q<=2;q+=2){
                int xx=cx+px*q,yy=cy+py*q;
                if(pathPixel(b.getPixel(xx,yy))){present=true;break;}
            }
            if(present){run++;best=Math.max(best,run);}else run=0;
        }
        return best*3;
    }
    public static Bitmap debugContinuity(Bitmap source){
        Bitmap out=source.copy(Bitmap.Config.ARGB_8888,true);
        Canvas canvas=new Canvas(out);Paint pen=new Paint(3);
        int w=source.getWidth(),h=source.getHeight();
        int top=Math.max(240,(int)(h*.18)),bottom=Math.min(h-180,(int)(h*.84));
        List<Candidate> coarse=new ArrayList<>();
        for(int y=top;y<bottom;y+=10)for(int x=25;x<w-25;x+=10){
            int best=0,dir=-1;
            for(int d=0;d<4;d++){int v=score(source,x,y,d);if(v>best){best=v;dir=d;}}
            if(best>=620)coarse.add(new Candidate(x,y,best,dir));
        }
        coarse.sort(Comparator.comparingInt((Candidate c)->c.score).reversed());
        List<Candidate> selected=new ArrayList<>();
        for(Candidate c:coarse){
            boolean near=false;
            for(Candidate k:selected){int dx=k.x-c.x,dy=k.y-c.y;if(dx*dx+dy*dy<22*22){near=true;break;}}
            if(!near)selected.add(c);
            if(selected.size()>=45)break;
        }
        int rayClear=0,continuity=0,both=0;
        pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(3);
        for(Candidate c:selected){
            boolean clear=clearRay(source,c.x,c.y,c.dir);
            int length=backwardContinuity(source,c.x,c.y,c.dir);
            boolean straight=length>=24;
            if(clear)rayClear++;if(straight)continuity++;if(clear&&straight)both++;
            pen.setColor(clear&&straight?Color.rgb(0,170,70):straight?Color.rgb(255,155,0):Color.rgb(220,50,60));
            canvas.drawCircle(c.x,c.y,10,pen);
            int vx=c.dir==1?1:c.dir==3?-1:0,vy=c.dir==2?1:c.dir==0?-1:0;
            if(straight)canvas.drawLine(c.x-vx*12,c.y-vy*12,c.x-vx*Math.min(length,100),c.y-vy*Math.min(length,100),pen);
        }
        pen.setStyle(Paint.Style.FILL);pen.setColor(Color.rgb(25,25,25));canvas.drawRect(0,0,w,205,pen);
        pen.setColor(Color.WHITE);pen.setTextSize(24);
        canvas.drawText("V10.3 CONTINUITY PROBES",20,42,pen);
        pen.setTextSize(19);
        canvas.drawText("Heads: "+selected.size()+"  head rays clear: "+rayClear,20,80,pen);
        canvas.drawText("Straight continuity: "+continuity+"  both: "+both,20,112,pen);
        canvas.drawText("GREEN=both  ORANGE=stroke only",20,144,pen);
        canvas.drawText("No bent paths verified. NO TAPS.",20,176,pen);
        return out;
    }
    // V10.4 diagnostic: locally follow an ink stroke backward from a head hypothesis.
    // Ambiguous forks are rejected rather than arbitrarily choosing a neighboring arrow.
    private static int[] traceBentStroke(Bitmap b, int x, int y, int dir, Canvas canvas, Paint pen) {
        int w=b.getWidth(),h=b.getHeight();
        int vx=dir==1?1:dir==3?-1:0,vy=dir==2?1:dir==0?-1:0;
        int cx=x-vx*12,cy=y-vy*12,dx=-vx,dy=-vy;
        int traveled=0,turns=0,ambiguous=0,missing=0;
        java.util.HashSet<Long> visited=new java.util.HashSet<>();
        pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(3);
        for(int step=0;step<180;step++){
            int bestX=0,bestY=0,bestScore=-999,second=-999;
            // Advance 3 pixels at a time; permit 90-degree bends, but never reverse.
            int[][] directions={{dx,dy},{-dy,dx},{dy,-dx}};
            for(int[] d:directions){
                int nx=cx+d[0]*3,ny=cy+d[1]*3;
                if(nx<8||ny<8||nx>=w-8||ny>=h-8)continue;
                long key=((long)ny<<32)|(nx&0xffffffffL);
                if(visited.contains(key))continue;
                int hits=0;
                for(int yy=-2;yy<=2;yy++)for(int xx=-2;xx<=2;xx++)
                    if(pathPixel(b.getPixel(nx+xx,ny+yy)))hits++;
                int score=hits-(d[0]!=dx||d[1]!=dy?3:0);
                if(score>bestScore){second=bestScore;bestScore=score;bestX=d[0];bestY=d[1];}
                else if(score>second)second=score;
            }
            if(bestScore<2){if(++missing>=2)break;cx+=dx*3;cy+=dy*3;continue;}
            missing=0;
            if(second>=bestScore-2 && second>=3){ambiguous++;break;}
            if(bestX!=dx||bestY!=dy)turns++;
            int nx=cx+bestX*3,ny=cy+bestY*3;
            pen.setColor(Color.rgb(0,120,220));canvas.drawLine(cx,cy,nx,ny,pen);
            cx=nx;cy=ny;dx=bestX;dy=bestY;traveled+=3;
            visited.add(((long)cy<<32)|(cx&0xffffffffL));
        }
        return new int[]{traveled,turns,ambiguous};
    }
    public static Bitmap debugBentContinuity(Bitmap source){
        Bitmap out=source.copy(Bitmap.Config.ARGB_8888,true);
        Canvas canvas=new Canvas(out);Paint pen=new Paint(3);
        int w=source.getWidth(),h=source.getHeight();
        int top=Math.max(240,(int)(h*.18)),bottom=Math.min(h-180,(int)(h*.84));
        List<Candidate> coarse=new ArrayList<>();
        for(int y=top;y<bottom;y+=10)for(int x=25;x<w-25;x+=10){
            int best=0,dir=-1;
            for(int d=0;d<4;d++){int v=score(source,x,y,d);if(v>best){best=v;dir=d;}}
            if(best>=620)coarse.add(new Candidate(x,y,best,dir));
        }
        coarse.sort(Comparator.comparingInt((Candidate c)->c.score).reversed());
        List<Candidate> selected=new ArrayList<>();
        for(Candidate c:coarse){
            boolean near=false;
            for(Candidate k:selected){int dx=k.x-c.x,dy=k.y-c.y;if(dx*dx+dy*dy<22*22){near=true;break;}}
            if(!near)selected.add(c);
            if(selected.size()>=45)break;
        }
        int longTraces=0,bentTraces=0,forks=0;
        for(Candidate c:selected){
            int[] result=traceBentStroke(source,c.x,c.y,c.dir,canvas,pen);
            if(result[0]>=45)longTraces++;
            if(result[1]>0)bentTraces++;
            forks+=result[2];
            pen.setStyle(Paint.Style.STROKE);
            pen.setColor(result[2]>0?Color.RED:Color.rgb(0,150,80));
            canvas.drawCircle(c.x,c.y,8,pen);
        }
        pen.setStyle(Paint.Style.FILL);pen.setColor(Color.rgb(20,20,20));canvas.drawRect(0,0,w,190,pen);
        pen.setColor(Color.WHITE);pen.setTextSize(21);
        canvas.drawText("V10.4 BENT-STROKE PROBES",16,38,pen);
        pen.setTextSize(17);
        canvas.drawText("Heads="+selected.size()+" long="+longTraces+" bent="+bentTraces,16,75,pen);
        canvas.drawText("Ambiguous forks="+forks,16,105,pen);
        canvas.drawText("BLUE=heuristic trace RED=ambiguous",16,138,pen);
        canvas.drawText("NOT full arrows. NO AUTO TAPS.",16,170,pen);
        return out;
    }
    // V10.5: inspect the actual captured board before attempting path reconstruction.
    // This is deliberately diagnostic: a stroke component is NOT a verified arrow.
    public static Bitmap debugBoardCoverage(Bitmap source) {
        Bitmap out=source.copy(Bitmap.Config.ARGB_8888,true);
        Canvas c=new Canvas(out);Paint p=new Paint(3);
        int[] roi=boardRoi(source);
        p.setColor(Color.rgb(0,160,70));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);
        c.drawRect(roi[0],roi[1],roi[2],roi[3],p);
        p.setStyle(Paint.Style.FILL);p.setColor(Color.BLACK);c.drawRect(0,0,source.getWidth(),175,p);
        p.setColor(Color.WHITE);p.setTextSize(20);
        c.drawText("V10.6 FULL-BOARD COVERAGE",12,35,p);
        p.setTextSize(16);
        c.drawText("X:"+roi[0]+".."+roi[2]+" Y:"+roi[1]+".."+roi[3],12,68,p);
        c.drawText("PINK INCLUDED; GREEN=estimated ROI",12,97,p);
        c.drawText("Check ALL arrow tips inside rectangle",12,127,p);
        c.drawText("No complete paths verified. NO TAPS.",12,154,p);
        return out;
    }
    public static Bitmap debugMask(Bitmap b){
        int w=b.getWidth(),h=b.getHeight();
        int ow=Math.max(1,w/3),oh=Math.max(1,h/3);
        Bitmap out=Bitmap.createBitmap(ow,oh,Bitmap.Config.ARGB_8888);
        int top=Math.max(240,(int)(h*.18)),bottom=Math.min(h-180,(int)(h*.84));
        // Use a thin centerline-preserving sample, not an any-of-nine dilation.
        // The old 3x3 OR joined neighboring parallel arrows and filled dense areas.
        for(int y=0;y<oh;y++)for(int x=0;x<ow;x++){
            int sx=Math.min(w-1,x*3+1),sy=Math.min(h-1,y*3+1);
            boolean on=false;
            if(sy>=top&&sy<bottom&&sx>=roi[0]&&sx<roi[2]){
                int hits=0;
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
                    int xx=sx+dx,yy=sy+dy;
                    if(xx>=0&&yy>=0&&xx<w&&yy<h&&pathPixel(b.getPixel(xx,yy)))hits++;
                }
                on=pathPixel(b.getPixel(sx,sy)) || hits>=4;
            }
            out.setPixel(x,y,on?Color.WHITE:Color.BLACK);
        }
        return out;
    }
    // V8.7: label pixels of connected regions, without misleading overlapping boxes.
    // These are still image fragments; connectedness alone does not prove arrow identity.
    public static Bitmap debugComponents(Bitmap source){
        Bitmap mask=debugMask(source);
        int w=mask.getWidth(),h=mask.getHeight(),n=w*h;
        boolean[] seen=new boolean[n];int[] queue=new int[n];
        List<int[]> regions=new ArrayList<>();
        for(int start=0;start<n;start++){
            if(seen[start]||mask.getPixel(start%w,start/w)!=Color.WHITE)continue;
            int head=0,tail=0;long sumX=0,sumY=0;
            queue[tail++]=start;seen[start]=true;
            while(head<tail){
                int pos=queue[head++],x=pos%w,y=pos/w;
                sumX+=x;sumY+=y;
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
                    if(dx==0&&dy==0)continue;
                    int xx=x+dx,yy=y+dy;
                    if(xx<0||yy<0||xx>=w||yy>=h)continue;
                    int next=yy*w+xx;
                    if(!seen[next]&&mask.getPixel(xx,yy)==Color.WHITE){seen[next]=true;queue[tail++]=next;}
                }
            }
            if(tail>=7)regions.add(new int[]{(int)(sumX/tail),(int)(sumY/tail),tail});
        }
        regions.sort((a,b)->Integer.compare(b[2],a[2]));
        Bitmap overlay=mask.copy(Bitmap.Config.ARGB_8888,true);
        int[] topologyCounts=topology(mask,overlay);mask.recycle();
        int[] traces=traceStrokeComponents(source,overlay);
        Canvas canvas=new Canvas(overlay);Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.rgb(255,180,0));paint.setStyle(Paint.Style.FILL);paint.setTextSize(9f);
        for(int i=0;i<Math.min(60,regions.size());i++){
            int[] r=regions.get(i);
            canvas.drawText(String.valueOf(i+1),r[0]+2,r[1]-2,paint);
        }
        // Draw a compact legend inside the mask: region labels are NOT arrow IDs.
        int longRegions=0;
        for(int[] r:regions)if(r[2]>=20)longRegions++;
        paint.setColor(Color.rgb(255,215,70));paint.setTextSize(10f);
        canvas.drawText("V9.4 FRAGMENTS "+regions.size()+" LONG "+longRegions,8,Math.max(12,h/5),paint);
        canvas.drawText("CYAN endpoints "+topologyCounts[0]+"  PINK junctions "+topologyCounts[1],8,Math.max(25,h/5+13),paint);
        canvas.drawText("V9.4 COMPONENTS "+traces[0]+" LONG "+traces[1],8,Math.max(38,h/5+26),paint);
        canvas.drawText("BRANCHED "+traces[3]+" ENDPOINT PIXELS "+traces[2],8,Math.max(51,h/5+39),paint);
        canvas.drawText("FRAGMENTS ONLY - NO TAPS",8,Math.max(64,h/5+52),paint);
        return overlay;
    }
    // V9.4: trace components without bridging gaps. Component IDs are hypotheses,
    // not arrow IDs. A color boundary is used only for segmentation, never rules.
    private static int[] traceStrokeComponents(Bitmap source, Bitmap overlay){
        Bitmap mask=debugMask(source);
        int w=mask.getWidth(),h=mask.getHeight(),n=w*h;
        boolean[] seen=new boolean[n];int[] queue=new int[n];
        int components=0,longComponents=0,isolatedEndpoints=0,branchComponents=0;
        Canvas canvas=new Canvas(overlay);Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);
        pen.setTextSize(9f);pen.setColor(Color.rgb(255,210,0));
        for(int start=0;start<n;start++){
            if(seen[start]||mask.getPixel(start%w,start/w)!=Color.WHITE)continue;
            int head=0,tail=0;queue[tail++]=start;seen[start]=true;
            long sx=0,sy=0;int endpointCount=0,branches=0;
            while(head<tail){
                int pos=queue[head++],x=pos%w,y=pos/w;sx+=x;sy+=y;
                int[] dx={0,1,1,1,0,-1,-1,-1};
                int[] dy={-1,-1,0,1,1,1,0,-1};
                boolean[] ring=new boolean[8];int transitions=0;
                for(int k=0;k<8;k++){
                    int xx=x+dx[k],yy=y+dy[k];
                    ring[k]=xx>=0&&yy>=0&&xx<w&&yy<h&&mask.getPixel(xx,yy)==Color.WHITE;
                    if(ring[k]){int next=yy*w+xx;if(!seen[next]){seen[next]=true;queue[tail++]=next;}}
                }
                for(int k=0;k<8;k++)if(!ring[k]&&ring[(k+1)%8])transitions++;
                if(transitions==1)endpointCount++;
                if(transitions>=3)branches++;
            }
            if(tail<7)continue;
            components++;
            if(tail>=20){
                longComponents++;isolatedEndpoints+=endpointCount;
                if(branches>0)branchComponents++;
                // Label each sizable component at its center; do not infer an arrow.
                pen.setColor(branches>0?Color.MAGENTA:Color.rgb(255,210,0));
                // Label components by topology class. An apparent two-ended component
                // is only a candidate stroke, NOT a validated complete arrow.
                String kind = branches>0 ? "BR" : (endpointCount==2 ? "2E" : "FR");
                canvas.drawText("C"+components+":"+kind,(float)sx/tail,(float)sy/tail,pen);
            }
        }
        mask.recycle();return new int[]{components,longComponents,isolatedEndpoints,branchComponents};
    }
    // V9.2 diagnostic: graph topology on the downsampled stroke mask.
    // Endpoint/branch counts are *not* verified arrows; crossings and sampling
    // artifacts can create extra nodes. Never authorize a tap from these counts.
    private static int[] topology(Bitmap mask, Bitmap overlay){
        int w=mask.getWidth(),h=mask.getHeight(),ends=0,junctions=0;
        Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);
        Canvas canvas=overlay==null?null:new Canvas(overlay);
        for(int y=2;y<h-2;y++)for(int x=2;x<w-2;x++){
            if(mask.getPixel(x,y)!=Color.WHITE)continue;
            boolean[] ring=new boolean[8];
            int[] dx={0,1,1,1,0,-1,-1,-1};
            int[] dy={-1,-1,0,1,1,1,0,-1};
            int neighbors=0,transitions=0;
            for(int i=0;i<8;i++){
                ring[i]=mask.getPixel(x+dx[i],y+dy[i])==Color.WHITE;
                if(ring[i])neighbors++;
            }
            for(int i=0;i<8;i++)if(!ring[i]&&ring[(i+1)%8])transitions++;
            // Count only centerline-like pixels with a locally thin neighborhood.
            if(neighbors<=2&&transitions==1){
                ends++;if(canvas!=null){pen.setColor(Color.CYAN);canvas.drawCircle(x,y,2.3f,pen);}
            }else if(transitions>=3){
                junctions++;if(canvas!=null){pen.setColor(Color.MAGENTA);canvas.drawCircle(x,y,2.0f,pen);}
            }
        }
        return new int[]{ends,junctions};
    }
    public static int[] countTopology(Bitmap source){
        Bitmap mask=debugMask(source);
        int[] counts=topology(mask,null);mask.recycle();return counts;
    }
    public static int countMaskFragments(Bitmap source){
        Bitmap mask=debugMask(source);
        int w=mask.getWidth(),h=mask.getHeight(),n=w*h,count=0;
        boolean[] seen=new boolean[n];int[] queue=new int[n];
        for(int start=0;start<n;start++){
            if(seen[start]||mask.getPixel(start%w,start/w)!=Color.WHITE)continue;
            int head=0,tail=0;queue[tail++]=start;seen[start]=true;
            while(head<tail){
                int pos=queue[head++],x=pos%w,y=pos/w;
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
                    int xx=x+dx,yy=y+dy;
                    if(xx<0||yy<0||xx>=w||yy>=h)continue;
                    int next=yy*w+xx;
                    if(!seen[next]&&mask.getPixel(xx,yy)==Color.WHITE){seen[next]=true;queue[tail++]=next;}
                }
            }
            if(tail>=7)count++;
        }
        mask.recycle();return count;
    }
    private static int[] countComponents(Bitmap b,int left,int top,int right,int bottom){
        final int step=3,gw=(right-left+step-1)/step,gh=(bottom-top+step-1)/step;
        if(gw<=0||gh<=0)return new int[6];
        byte[] mask=new byte[gw*gh];
        for(int y=0;y<gh;y++)for(int x=0;x<gw;x++){
            int sx=Math.min(right-1,left+x*step),sy=Math.min(bottom-1,top+y*step);
            mask[y*gw+x]=(byte)(pathPixel(b.getPixel(sx,sy))?1:0);
        }
        int[] queue=new int[gw*gh];int[] components=new int[6];
        for(int i=0;i<mask.length;i++){
            int label=mask[i];if(label==0)continue;
            int head=0,tail=0;queue[tail++]=i;mask[i]=0;
            while(head<tail){
                int v=queue[head++],x=v%gw,y=v/gw;
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
                    if(dx==0&&dy==0)continue;
                    int xx=x+dx,yy=y+dy;
                    if(xx<0||yy<0||xx>=gw||yy>=gh)continue;
                    int ni=yy*gw+xx;
                    if(mask[ni]==label){mask[ni]=0;queue[tail++]=ni;}
                }
            }
            if(tail>=7)components[label]++;
        }
        return components;
    }
    public static Detection detect(Bitmap b, Progress progress){
        int w=b.getWidth(),h=b.getHeight(),top=Math.max(240,(int)(h*.18)),bottom=Math.min(h-180,(int)(h*.84)),left=25,right=w-25;
        int colorSamples=0;
        for(int cy=top;cy<bottom;cy+=5)for(int cx=left;cx<right;cx+=5){
            int pixel=b.getPixel(cx,cy),r=Color.red(pixel),g=Color.green(pixel),bl=Color.blue(pixel);
            int hi=Math.max(r,Math.max(g,bl)),lo=Math.min(r,Math.min(g,bl));
            if(hi-lo>=42 && hi>=95 && lo<220)colorSamples++;
        }
        int[] byColor=countComponents(b,left,top,right,bottom);
        int components=countMaskFragments(b);
        int[] graph=countTopology(b);
        if(progress!=null)progress.onProgress("V9.4 fragments="+components+" endpoints="+graph[0]+" junctions="+graph[1]+" (unverified)");
        List<Candidate> candidates=new ArrayList<>();
        // Coarse scan: V5.5 checked every 2 pixels and could take too long on a 1080x2408 frame.
        // Step 6 cuts work dramatically, then we refine locally around strong coarse hits.
        for(int y=top;y<bottom;y+=7){
            for(int x=left;x<right;x+=7){int best=0,dir=-1;for(int d=0;d<4;d++){int s=score(b,x,y,d);if(s>best){best=s;dir=d;}}if(best>=430)candidates.add(new Candidate(x,y,best,dir));}
            if(progress!=null && ((y-top)%240)<3) progress.onProgress("coarse y="+y+" candidates="+candidates.size());
        }
        int raw=candidates.size();
        candidates.sort(Comparator.comparingInt((Candidate c)->c.score).reversed());
        List<Candidate> refined=new ArrayList<>();
        int limit=Math.min(90,candidates.size());
        for(int i=0;i<limit;i++){
            Candidate c=candidates.get(i); Candidate bestC=c;
            for(int yy=c.y-4;yy<=c.y+4;yy+=2)for(int xx=c.x-4;xx<=c.x+4;xx+=2)for(int d=0;d<4;d++){int s=score(b,xx,yy,d);if(s>bestC.score)bestC=new Candidate(xx,yy,s,d);}
            if(bestC.score>=500)refined.add(bestC);
        }
        refined.sort(Comparator.comparingInt((Candidate c)->c.score).reversed());
        List<Candidate> kept=new ArrayList<>();
        for(Candidate c:refined){boolean near=false;for(Candidate k:kept){int dx=c.x-k.x,dy=c.y-k.y;if(dx*dx+dy*dy<14*14){near=true;break;}}if(!near)kept.add(c);if(kept.size()>=35)break;}
        if(progress!=null)progress.onProgress("raw="+raw+" refined arrows="+kept.size());
        if(kept.isEmpty())return new Detection(null,false,raw,0,0,0,colorSamples,components,byColor);
        Candidate best=null;int clear=0;
        for(Candidate c:kept){
            // Extra confidence gate: borderline arrow-shape matches are never tapped.
            if(c.score<620)continue;
            if(clearRay(b,c.x,c.y,c.dir)){clear++;if(best==null||c.score>best.score)best=c;}
        }
        if(best==null)return new Detection(null,false,raw,kept.size(),0,kept.get(0).score,colorSamples,components,byColor);
        int vx=(best.dir==1?1:best.dir==3?-1:0),vy=(best.dir==2?1:best.dir==0?-1:0);
        return new Detection(null,false,raw,kept.size(),clear,best.score,colorSamples,components,byColor);
    }
    private static final class Candidate{final int x,y,score,dir;Candidate(int x,int y,int score,int dir){this.x=x;this.y=y;this.score=score;this.dir=dir;}}
}
