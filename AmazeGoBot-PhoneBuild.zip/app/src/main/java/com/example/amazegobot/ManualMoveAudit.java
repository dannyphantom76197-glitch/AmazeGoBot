package com.example.amazegobot;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

/** V11.4 one-manual-move ink-delta overlay. Never generates gameplay gestures. */
public final class ManualMoveAudit {
    private ManualMoveAudit() {}
    public static final class Display {
        public final Bitmap image;
        public final String summary;
        Display(Bitmap image,String summary){this.image=image;this.summary=summary;}
    }
    public static Display render(Bitmap before,Bitmap after){
        if(before.getWidth()!=after.getWidth()||before.getHeight()!=after.getHeight())
            throw new IllegalArgumentException("Before/after dimensions differ. Keep screen orientation unchanged.");
        int w=before.getWidth(),h=before.getHeight(),n=w*h;
        int[] a=new int[n],b=new int[n];
        before.getPixels(a,0,w,0,0,w,h);
        after.getPixels(b,0,w,0,0,w,h);
        int[] roiA=ArrowDetector.boardRoi(before),roiB=ArrowDetector.boardRoi(after);
        // Use a stable union ROI: the removed outer arrow must not disappear
        // from our analysis merely because the AFTER-derived bounds shrank.
        int[] roi={Math.min(roiA[0],roiB[0]),Math.min(roiA[1],roiB[1]),
            Math.max(roiA[2],roiB[2]),Math.max(roiA[3],roiB[3])};
        ManualMoveCore.Result diff=ManualMoveCore.compare(a,b,w,h,roi);
        for(int y=roi[1];y<roi[3];y++)for(int x=roi[0];x<roi[2];x++){
            int i=y*w+x;
            if(diff.labels[i]==ManualMoveCore.REMOVED)b[i]=Color.rgb(219,17,187); // magenta
            else if(diff.labels[i]==ManualMoveCore.ADDED)b[i]=Color.rgb(255,128,16); // orange
            else if(diff.labels[i]==ManualMoveCore.RETAINED)b[i]=Color.rgb(18,145,78); // green
            else if(diff.labels[i]==ManualMoveCore.REPLACED)b[i]=Color.rgb(155,72,220); // purple: changed colors
        }
        // Bitmap.createBitmap(int[] colors, ...) may return an IMMUTABLE bitmap.
        // A Canvas can only draw on a mutable bitmap, so allocate an empty
        // writable ARGB_8888 destination and load the recolored pixels into it.
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        out.setPixels(b,0,w,0,0,w,h);
        Canvas canvas=new Canvas(out);Paint p=new Paint(3);
        if(diff.largestBounds!=null){
            p.setStyle(Paint.Style.STROKE);p.setColor(Color.rgb(182,10,174));p.setStrokeWidth(3);
            int[] bb=diff.largestBounds;
            canvas.drawRect(bb[0],bb[1],bb[2],bb[3],p);
        }
        p.setStyle(Paint.Style.FILL);p.setColor(Color.BLACK);
        canvas.drawRect(0,0,w,254,p);
        p.setColor(Color.WHITE);p.setTextSize(21);
        canvas.drawText("V11.4 OBSERVED MANUAL-MOVE DIFFERENCE",12,31,p);
        p.setTextSize(18);
        canvas.drawText("Ink pixels: BEFORE="+diff.beforeInk+" AFTER="+diff.afterInk,12,67,p);
        canvas.drawText("REMOVED="+diff.removed+" ADDED="+diff.added+" RETAINED="+diff.retained,12,97,p);
        canvas.drawText("Removed parts="+diff.removalGroups+" largest="+diff.largestGroup,12,127,p);
        canvas.drawText("Retained ink inside largest erased box="+diff.retainedInsideLargest,12,155,p);
        canvas.drawText("PINK=gone ORANGE=new GREEN=still PURPLE=changed",12,184,p);
        canvas.drawText(diff.plausibleSingleRemoval()?"Pattern consistent with ink removal (NOT verified gameplay)"
            :"No clear single-removal pattern; check BEFORE and AFTER",12,215,p);
        canvas.drawText("NO AUTOMATIC TAPS; image alignment / hitboxes unverified",12,242,p);
        return new Display(out,diff.summary()+"; " +(diff.plausibleSingleRemoval()
            ?"ink removal pattern detected":"single-removal pattern NOT established")+
            ". Color mask/one-pixel tolerance only; this does not prove arrow identity, collision physics, or safe auto-tapping.");
    }
}
