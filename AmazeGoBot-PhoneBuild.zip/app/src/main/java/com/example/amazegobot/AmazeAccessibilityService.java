package com.example.amazegobot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class AmazeAccessibilityService extends AccessibilityService {
    private static final String TARGET="com.oakever.arrows";
    private static final long SCAN_INTERVAL_MS=650;
    private static final long AFTER_TAP_DELAY_MS=220;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Executor worker=Executors.newSingleThreadExecutor();
    private volatile boolean busy=false,targetVisible=false;
    private volatile boolean detectionRunning=false;
    private long previousBoardSignature=0;
    private int stableFrames=0;
    private long busySinceMs=0;
    private int captures=0,taps=0,failures=0;
    private int requestId=0;
    private ArrowDetector.Detection pending=null;
    private static final float VERIFY_POS_PX=12f;
    private int verificationMismatches=0;
    private long lastCaptureMs=0,lastCopyMs=0,lastDetectMs=0;
    private long cycleStartNs=0,captureRequestNs=0,callbackNs=0,copyDoneNs=0,detectDoneNs=0,gestureSentNs=0;

    private final Runnable scanLoop=new Runnable(){@Override public void run(){
        if(busy && android.os.SystemClock.uptimeMillis()-busySinceMs>15000){
            requestId++; busy=false; pending=null;
            report("V7.7 WATCHDOG: scan exceeded 15s; recovering. captures="+captures+" taps="+taps);
        }
        if(enabled()&&targetVisible&&!busy&&!detectionRunning)scan();
        main.postDelayed(this,SCAN_INTERVAL_MS);
    }};
    private boolean enabled(){return getSharedPreferences("bot",MODE_PRIVATE).getBoolean("enabled",false);}
    private void report(String s){getSharedPreferences("bot",MODE_PRIVATE).edit().putString("diagnostic",s).apply();}
    private void reportProgress(String s){getSharedPreferences("bot",MODE_PRIVATE).edit().putString("scan_progress",s).apply();}
    @Override public void onServiceConnected(){super.onServiceConnected();report("Service connected. Waiting for Amaze GO...");main.removeCallbacks(scanLoop);main.post(scanLoop);}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){CharSequence p=event.getPackageName();if(p!=null){if(event.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED){
            targetVisible=TARGET.contentEquals(p);
        }else if(TARGET.contentEquals(p)){targetVisible=true;}
        if(targetVisible&&enabled()&&!busy)main.postDelayed(this::scan,100);}}
    @Override public void onInterrupt(){report("Accessibility service interrupted.");}
    @Override public void onDestroy(){main.removeCallbacks(scanLoop);super.onDestroy();}

    private void scan(){
        if(busy||detectionRunning||!enabled()||!targetVisible)return;
        busy=true;
        busySinceMs=android.os.SystemClock.uptimeMillis();
        cycleStartNs=System.nanoTime();
        captureRequestNs=cycleStartNs;
        final int myRequest=++requestId;
        reportProgress("V7.7 REQUEST #"+myRequest+" waiting for screenshot...");
        try{
            // V5.4 deliberately uses the service/main executor for takeScreenshot callbacks.
            // Only one request may be in flight; there is no timeout that can overlap a late callback.
            takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
                @Override public void onSuccess(ScreenshotResult result){
                    if(myRequest!=requestId){closeBuffer(result);return;}
                    callbackNs=System.nanoTime();
                    reportProgress("V7.7 CALLBACK #"+myRequest+" capture="+ms(captureRequestNs,callbackNs)+"ms. Copying...");
                    // Do ALL HardwareBuffer -> Bitmap work off the accessibility/main thread.
                    // This keeps Android's screenshot callback free and also tells us exactly
                    // which conversion stage succeeds on this phone.
                    worker.execute(()->{
                        HardwareBuffer hb=null;
                        Bitmap frame=null;
                        try{
                            reportProgress("V7.7 COPY #"+myRequest+" stage 1/3: getting HardwareBuffer...");
                            hb=result.getHardwareBuffer();
                            if(hb==null)throw new IllegalStateException("HardwareBuffer was null");
                            reportProgress("V7.7 COPY #"+myRequest+" stage 2/3: wrapping buffer...");
                            Bitmap wrapped=Bitmap.wrapHardwareBuffer(hb,result.getColorSpace());
                            if(wrapped==null)throw new IllegalStateException("wrapHardwareBuffer returned null");
                            reportProgress("V7.7 COPY #"+myRequest+" stage 3/3: making software bitmap...");
                            frame=wrapped.copy(Bitmap.Config.ARGB_8888,false);
                            if(frame==null)throw new IllegalStateException("Bitmap.copy returned null");
                            final int w=frame.getWidth(),h=frame.getHeight();
                            captures++;
                            copyDoneNs=System.nanoTime();
                            final long copyMs=ms(callbackNs,copyDoneNs);
                            lastCaptureMs=ms(captureRequestNs,callbackNs); lastCopyMs=copyMs;
                            reportProgress("V7.7 FRAME #"+captures+" "+w+"x"+h+" capture="+ms(captureRequestNs,callbackNs)+"ms copy="+copyMs+"ms. Detecting...");
                            final long boardSignature=boardSignature(frame);
                            final long detectStart=System.nanoTime();
                            detectionRunning=true;
                            ArrowDetector.Detection d;
                            try { d=ArrowDetector.detect(frame, p -> reportProgress("V7.7 DETECTOR #"+captures+" "+p)); }
                            finally { detectionRunning=false; }
                            detectDoneNs=System.nanoTime();
                            lastDetectMs=ms(detectStart,detectDoneNs);
                            frame.recycle();
                            frame=null;
                            main.post(()->{if(myRequest==requestId)handleDetection(d,w,h,boardSignature);});
                        }catch(Throwable t){
                            detectionRunning=false;
                            if(frame!=null)try{frame.recycle();}catch(Throwable ignored){}
                            final String msg="V7.7 COPY ERROR #"+myRequest+": "+t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage());
                            main.post(()->{
                                if(myRequest!=requestId)return;
                                report(msg);
                                busy=false;
                                main.postDelayed(()->{if(enabled()&&targetVisible&&!busy&&!detectionRunning)scan();},3000);
                            });
                        }finally{
                            if(hb!=null)try{hb.close();}catch(Throwable ignored){}
                        }
                    });
                }
                @Override public void onFailure(int errorCode){
                    if(myRequest!=requestId)return;
                    failures++;
                    report("V7.7 SCREENSHOT FAILURE code="+errorCode+" request="+myRequest+" failures="+failures+". Waiting before next request...");
                    busy=false;
                    main.postDelayed(()->{if(enabled()&&targetVisible&&!busy&&!detectionRunning)scan();},3000);
                }
            });
        }catch(Throwable t){
            if(myRequest==requestId){
                failures++;
                report("V7.7 REQUEST ERROR #"+myRequest+": "+t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage()));
                busy=false;
                main.postDelayed(()->{if(enabled()&&targetVisible&&!busy&&!detectionRunning)scan();},3000);
            }
        }
    }

    private void closeBuffer(ScreenshotResult result){
        try{HardwareBuffer hb=result.getHardwareBuffer();if(hb!=null)hb.close();}catch(Throwable ignored){}
    }

    private static long ms(long a,long b){return Math.max(0L,(b-a)/1000000L);}
    private String timings(){return "Capture="+lastCaptureMs+"ms Copy="+lastCopyMs+"ms Detect+clear="+lastDetectMs+"ms Mismatches="+verificationMismatches;}

    // Only dispatch after matching candidates from two independent frames.
    private static long boardSignature(Bitmap b){
        // FNV-like perceptual signature on quantized colors in the likely board region.
        // Diagnostic only: does not establish that arrow locations are stable.
        long hash=1469598103934665603L;
        int top=Math.max(240,(int)(b.getHeight()*.18)),bottom=Math.min(b.getHeight()-180,(int)(b.getHeight()*.84));
        for(int y=top;y<bottom;y+=16)for(int x=25;x<b.getWidth()-25;x+=16){
            int c=b.getPixel(x,y);
            int r=(android.graphics.Color.red(c)/32),g=(android.graphics.Color.green(c)/32),bl=(android.graphics.Color.blue(c)/32);
            hash^=(r<<6)|(g<<3)|bl;hash*=1099511628211L;
        }
        return hash;
    }
    private void handleDetection(ArrowDetector.Detection d,int w,int h,long signature){
        if(!enabled()||!targetVisible){pending=null;busy=false;return;}
        if(signature==previousBoardSignature)stableFrames++;else stableFrames=1;
        previousBoardSignature=signature;
        String stats="\n"+d.summary()+"\nFrame signature="+Long.toHexString(signature)+" identical consecutive frames="+stableFrames+"\n"+timings();
        if(true){ // V7.7 diagnostic safety lock: no gesture dispatch
            pending=null;
            report("V7.7 SAFE HOLD: full path collision is unverified; no tap. captures="+captures+" taps="+taps+stats);
            busy=false;
        }else if(pending==null){
            pending=d;
            reportProgress("V7.7 FRAME 1/2: candidate found, verifying."+stats);
            busy=false;
            main.postDelayed(()->{if(enabled()&&targetVisible&&!busy&&!detectionRunning)scan();},250);
        }else{
            float dx=d.tap.x-pending.tap.x,dy=d.tap.y-pending.tap.y;
            boolean position=(dx*dx+dy*dy)<=VERIFY_POS_PX*VERIFY_POS_PX;
            boolean direction=d.tap.dir==pending.tap.dir;
            if(position&&direction){
                pending=null;
                if(!enabled()||!targetVisible){busy=false;return;}
                Path path=new Path();path.moveTo(d.tap.x,d.tap.y);
                GestureDescription gesture=new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path,0,65)).build();
                try{
                    boolean accepted=dispatchGesture(gesture,new GestureResultCallback(){
                        @Override public void onCompleted(GestureDescription g){
                            taps++;report("V7.7 TAP COMPLETED #"+taps+" at ("+(int)d.tap.x+","+(int)d.tap.y+")."+stats);
                            busy=false;
                            main.postDelayed(()->{if(enabled()&&targetVisible&&!busy&&!detectionRunning)scan();},AFTER_TAP_DELAY_MS);
                        }
                        @Override public void onCancelled(GestureDescription g){
                            report("V7.7 TAP CANCELLED."+stats);busy=false;
                        }
                    },main);
                    if(!accepted){report("V7.7 DISPATCH REJECTED."+stats);busy=false;}
                    else report("V7.7 VERIFIED 2/2; tap dispatched."+stats);
                }catch(Throwable t){report("V7.7 GESTURE ERROR: "+t.getMessage());busy=false;}
            }else{
                verificationMismatches++;
                pending=d;
                report("V7.7 MISMATCH #"+verificationMismatches+"; waiting for agreement. position="+position+" direction="+direction+stats);
                busy=false;
            }
        }
    }
}
