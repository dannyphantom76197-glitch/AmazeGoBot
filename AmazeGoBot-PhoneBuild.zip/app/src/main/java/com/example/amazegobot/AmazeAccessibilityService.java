package com.example.amazegobot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class AmazeAccessibilityService extends AccessibilityService {
    private static final String TARGET="com.oakever.arrows";
    private static final long SCAN_INTERVAL_MS=1400;
    private static final long AFTER_TAP_DELAY_MS=1100;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Executor executor=Executors.newSingleThreadExecutor();
    private boolean busy=false,targetVisible=false;
    private int captures=0,taps=0,failures=0;
    private int requestId=0;

    private final Runnable scanLoop=new Runnable(){@Override public void run(){
        if(enabled()&&targetVisible&&!busy)scan();
        main.postDelayed(this,SCAN_INTERVAL_MS);
    }};
    private boolean enabled(){return getSharedPreferences("bot",MODE_PRIVATE).getBoolean("enabled",false);}
    private void report(String s){getSharedPreferences("bot",MODE_PRIVATE).edit().putString("diagnostic",s).apply();}
    @Override public void onServiceConnected(){super.onServiceConnected();report("Service connected. Waiting for Amaze GO...");main.removeCallbacks(scanLoop);main.post(scanLoop);}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){CharSequence p=event.getPackageName();if(p!=null){targetVisible=TARGET.contentEquals(p);if(targetVisible&&enabled()&&!busy)main.postDelayed(this::scan,220);}}
    @Override public void onInterrupt(){report("Accessibility service interrupted.");}
    @Override public void onDestroy(){main.removeCallbacks(scanLoop);super.onDestroy();}

    private void scan(){
        if(busy||!enabled()||!targetVisible)return;
        busy=true; final int myRequest=++requestId; report("Amaze GO detected. Capturing board...");
        // Deliver the screenshot callback on Android's main executor. Some phones can
        // leave a custom worker-executor callback pending indefinitely.
        main.postDelayed(()->{if(busy && myRequest==requestId){failures++;busy=false;report("Screenshot timed out. Retrying...");}},5000);
        try{takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
            @Override public void onSuccess(ScreenshotResult result){if(myRequest!=requestId)return; Bitmap bmp=null;try{
                HardwareBuffer hb=result.getHardwareBuffer();bmp=Bitmap.wrapHardwareBuffer(hb,result.getColorSpace());if(bmp!=null)bmp=bmp.copy(Bitmap.Config.ARGB_8888,false);if(hb!=null)hb.close();final Bitmap image=bmp;
                if(image==null){report("Screenshot returned no bitmap.");busy=false;return;}
                captures++;final int w=image.getWidth(),h=image.getHeight();executor.execute(()->{
                    ArrowDetector.Detection d=ArrowDetector.detect(image);image.recycle();main.post(()->handleDetection(d,w,h));
                });
            }catch(Throwable t){report("Screenshot processing error: "+t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage()));busy=false;}}
            @Override public void onFailure(int errorCode){if(myRequest!=requestId)return; failures++;report("SCREENSHOT FAILED code="+errorCode+" failures="+failures+". Retrying...");busy=false;}
        });}catch(Throwable t){if(myRequest==requestId){report("Screenshot request error: "+t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage()));busy=false;}}
    }

    private void handleDetection(ArrowDetector.Detection d,int w,int h){
        if(!enabled()||!targetVisible){busy=false;return;}
        if(d.tap==null){
            report("CAPTURE OK #"+captures+"  "+w+"x"+h+"\n"+d.summary()+"\nNo clear move found. Waiting to rescan.");
            busy=false; return;
        }
        final float x=d.tap.x,y=d.tap.y;
        report("CAPTURE OK #"+captures+"  "+w+"x"+h+"\n"+d.summary()+"\nSending ONE tap at "+Math.round(x)+","+Math.round(y)+"...");
        Path path=new Path();path.moveTo(x,y);
        GestureDescription gesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,70)).build();
        boolean accepted=dispatchGesture(gesture,new GestureResultCallback(){
            @Override public void onCompleted(GestureDescription g){taps++;report("Tap #"+taps+" completed at "+Math.round(x)+","+Math.round(y)+". Waiting for board change...");main.postDelayed(()->{busy=false;if(enabled()&&targetVisible)scan();},AFTER_TAP_DELAY_MS);}
            @Override public void onCancelled(GestureDescription g){report("Tap was cancelled. Waiting to rescan.");main.postDelayed(()->busy=false,AFTER_TAP_DELAY_MS);}
        },main);
        if(!accepted){report("Android rejected the tap gesture. Waiting to rescan.");main.postDelayed(()->busy=false,AFTER_TAP_DELAY_MS);}
    }
}
