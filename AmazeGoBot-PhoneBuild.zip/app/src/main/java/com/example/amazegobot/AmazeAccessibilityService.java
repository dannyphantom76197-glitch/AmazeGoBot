package com.example.amazegobot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class AmazeAccessibilityService extends AccessibilityService {
    private static final String TARGET="com.oakever.arrows";
    private static final long SCAN_INTERVAL_MS=900;
    private static final long AFTER_TAP_DELAY_MS=220;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Executor worker=Executors.newSingleThreadExecutor();
    private boolean busy=false,targetVisible=false;
    private int captures=0,taps=0,failures=0;
    private int requestId=0;
    private ArrowDetector.Detection pending=null;
    private static final float VERIFY_POS_PX=12f;
    private long cycleStartNs=0,captureRequestNs=0,callbackNs=0,copyDoneNs=0,detectDoneNs=0,gestureSentNs=0;

    private final Runnable scanLoop=new Runnable(){@Override public void run(){
        if(enabled()&&targetVisible&&!busy)scan();
        main.postDelayed(this,SCAN_INTERVAL_MS);
    }};
    private boolean enabled(){return getSharedPreferences("bot",MODE_PRIVATE).getBoolean("enabled",false);}
    private void report(String s){getSharedPreferences("bot",MODE_PRIVATE).edit().putString("diagnostic",s).apply();}
    @Override public void onServiceConnected(){super.onServiceConnected();report("Service connected. Waiting for Amaze GO...");main.removeCallbacks(scanLoop);main.post(scanLoop);}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){CharSequence p=event.getPackageName();if(p!=null){targetVisible=TARGET.contentEquals(p);if(targetVisible&&enabled()&&!busy)main.postDelayed(this::scan,100);}}
    @Override public void onInterrupt(){report("Accessibility service interrupted.");}
    @Override public void onDestroy(){main.removeCallbacks(scanLoop);super.onDestroy();}

    private void scan(){
        if(busy||!enabled()||!targetVisible)return;
        busy=true;
        cycleStartNs=System.nanoTime();
        captureRequestNs=cycleStartNs;
        final int myRequest=++requestId;
        report("V5.8 REQUEST #"+myRequest+" sent. Waiting for Android screenshot callback...");
        try{
            // V5.4 deliberately uses the service/main executor for takeScreenshot callbacks.
            // Only one request may be in flight; there is no timeout that can overlap a late callback.
            takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
                @Override public void onSuccess(ScreenshotResult result){
                    if(myRequest!=requestId){closeBuffer(result);return;}
                    callbackNs=System.nanoTime();
                    report("V6.4 CALLBACK #"+myRequest+" capture="+ms(captureRequestNs,callbackNs)+"ms. Copying...");
                    // Do ALL HardwareBuffer -> Bitmap work off the accessibility/main thread.
                    // This keeps Android's screenshot callback free and also tells us exactly
                    // which conversion stage succeeds on this phone.
                    worker.execute(()->{
                        HardwareBuffer hb=null;
                        Bitmap frame=null;
                        try{
                            report("V5.8 COPY #"+myRequest+" stage 1/3: getting HardwareBuffer...");
                            hb=result.getHardwareBuffer();
                            if(hb==null)throw new IllegalStateException("HardwareBuffer was null");
                            report("V5.8 COPY #"+myRequest+" stage 2/3: wrapping buffer...");
                            Bitmap wrapped=Bitmap.wrapHardwareBuffer(hb,result.getColorSpace());
                            if(wrapped==null)throw new IllegalStateException("wrapHardwareBuffer returned null");
                            report("V5.8 COPY #"+myRequest+" stage 3/3: making software bitmap...");
                            frame=wrapped.copy(Bitmap.Config.ARGB_8888,false);
                            if(frame==null)throw new IllegalStateException("Bitmap.copy returned null");
                            final int w=frame.getWidth(),h=frame.getHeight();
                            captures++;
                            copyDoneNs=System.nanoTime();
                            final long copyMs=ms(callbackNs,copyDoneNs);
                            report("V6.4 FRAME #"+captures+" "+w+"x"+h+" capture="+ms(captureRequestNs,callbackNs)+"ms copy="+copyMs+"ms. Detecting...");
                            final long detectStart=System.nanoTime();
                            ArrowDetector.Detection d=ArrowDetector.detect(frame, p -> report("V6.4 DETECTOR #"+captures+" "+p));
                            detectDoneNs=System.nanoTime();
                            frame.recycle();
                            frame=null;
                            main.post(()->handleDetection(d,w,h));
                        }catch(Throwable t){
                            if(frame!=null)try{frame.recycle();}catch(Throwable ignored){}
                            final String msg="V5.8 COPY ERROR #"+myRequest+": "+t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage());
                            main.post(()->{
                                report(msg);
                                busy=false;
                                main.postDelayed(()->{if(enabled()&&targetVisible&&!busy)scan();},3000);
                            });
                        }finally{
                            if(hb!=null)try{hb.close();}catch(Throwable ignored){}
                        }
                    });
                }
                @Override public void onFailure(int errorCode){
                    if(myRequest!=requestId)return;
                    failures++;
                    report("V5.8 SCREENSHOT FAILURE code="+errorCode+" request="+myRequest+" failures="+failures+". Waiting before next request...");
                    busy=false;
                    main.postDelayed(()->{if(enabled()&&targetVisible&&!busy)scan();},3000);
                }
            });
        }catch(Throwable t){
            if(myRequest==requestId){
                failures++;
                report("V5.8 REQUEST ERROR #"+myRequest+": "+t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage()));
                busy=false;
                main.postDelayed(()->{if(enabled()&&targetVisible&&!busy)scan();},3000);
            }
        }
    }

    private void closeBuffer(ScreenshotResult result){
        try{HardwareBuffer hb=result.getHardwareBuffer();if(hb!=null)hb.close();}catch(Throwable ignored){}
    }

    private static long ms(long a,long b){return Math.max(0L,(b-a)/1000000L);}

    private void handleDetection(ArrowDetector.Detection d,int w,int h){
        if(!enabled()||!targetVisible){pending=null;busy=false;return;}
        if(d.tap==null){pending=null;report("V6.4 VERIFY\n"+d.summary()+"\nNo clear move found. Waiting for a fresh board.");busy=false;return;}
        if(pending==null){
            pending=d;
            report("V6.4 VERIFY 1/2\n"+d.summary()+"\nCandidate saved. Taking a second fresh screenshot before tapping...");
            busy=false;
            main.postDelayed(()->{if(enabled()&&targetVisible&&!busy)scan();},120);
            return;
        }
        float dx=d.tap.x-pending.tap.x,dy=d.tap.y-pending.tap.y;
        boolean agree=(dx*dx+dy*dy)<=VERIFY_POS_PX*VERIFY_POS_PX && d.tap.dir==pending.tap.dir;
        if(!agree){
            pending=d;
            report("V6.4 VERIFY MISMATCH\nTwo fresh frames disagreed on center/direction. NO TAP. Rechecking...\n"+d.summary());
            busy=false;
            main.postDelayed(()->{if(enabled()&&targetVisible&&!busy)scan();},140);
            return;
        }
        pending=null;
        final float x=d.tap.x,y=d.tap.y;
        gestureSentNs=System.nanoTime();
        report("V6.4 VERIFIED 2/2\n"+d.summary()+"\nCenter + direction + clear path agreed. Sending ONE tap...");
        Path path=new Path();path.moveTo(x,y);
        GestureDescription gesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,70)).build();
        boolean accepted=dispatchGesture(gesture,new GestureResultCallback(){
            @Override public void onCompleted(GestureDescription g){taps++;report("V6.4 VERIFIED TAP #"+taps+"\n"+d.summary()+"\nTwo-frame agreement passed.");main.postDelayed(()->{busy=false;requestId++;if(enabled()&&targetVisible)main.postDelayed(()->{if(!busy)scan();},100);},AFTER_TAP_DELAY_MS);}
            @Override public void onCancelled(GestureDescription g){report("V6.4 tap cancelled. No retry until fresh verification.");main.postDelayed(()->busy=false,AFTER_TAP_DELAY_MS);}
        },main);
        if(!accepted){report("V6.4 Android rejected tap. Fresh verification required.");main.postDelayed(()->busy=false,AFTER_TAP_DELAY_MS);}
    }

}
