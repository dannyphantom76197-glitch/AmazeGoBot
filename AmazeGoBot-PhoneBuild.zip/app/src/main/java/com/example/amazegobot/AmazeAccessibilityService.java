package com.example.amazegobot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.HardwareBuffer;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class AmazeAccessibilityService extends AccessibilityService {
    private static final String TARGET = "com.oakever.arrows";
    private static final long STEP_DELAY_MS = 500;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Executor executor = Executors.newSingleThreadExecutor();
    private boolean busy = false;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (busy) return;
        if (!getSharedPreferences("bot", MODE_PRIVATE).getBoolean("enabled", false)) return;
        CharSequence p = event.getPackageName();
        if (p != null && TARGET.contentEquals(p)) {
            main.postDelayed(this::scan, 250);
        }
    }

    @Override public void onInterrupt() {}

    private void scan() {
        if (busy) return;
        if (!getSharedPreferences("bot", MODE_PRIVATE).getBoolean("enabled", false)) return;
        busy = true;
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, executor, new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult result) {
                    Bitmap bmp = null;
                    try {
                        HardwareBuffer hb = result.getHardwareBuffer();
                        bmp = Bitmap.wrapHardwareBuffer(hb, result.getColorSpace());
                        if (bmp != null) bmp = bmp.copy(Bitmap.Config.ARGB_8888, false);
                        if (hb != null) hb.close();
                        final Bitmap image = bmp;
                        if (image != null) {
                            executor.execute(() -> {
                                ArrowDetector.Detection d = ArrowDetector.detect(image);
                                main.post(() -> {
                                    if (d.finished || d.tap == null) {
                                        busy = false;
                                    } else {
                                        tap(d.tap.x, d.tap.y);
                                    }
                                });
                            });
                        } else busy = false;
                    } catch (Throwable t) {
                        busy = false;
                    }
                }
                @Override public void onFailure(int errorCode) {
                    busy = false;
                }
            });
        } catch (Throwable t) {
            busy = false;
        }
    }

    private void tap(float x, float y) {
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 55);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(stroke).build();
        dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                main.postDelayed(() -> { busy = false; scan(); }, STEP_DELAY_MS);
            }
            @Override public void onCancelled(GestureDescription g) {
                busy = false;
            }
        }, main);
    }
}
