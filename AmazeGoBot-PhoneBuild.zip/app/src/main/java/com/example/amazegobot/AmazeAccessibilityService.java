package com.example.amazegobot;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class AmazeAccessibilityService extends AccessibilityService {
    private static final String TARGET="com.oakever.arrows";
    private static final long SCAN_INTERVAL_MS=1200;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Executor executor=Executors.newSingleThreadExecutor();
    private boolean busy=false,targetVisible=false;
    private int captures=0, failures=0;

    private final Runnable scanLoop=new Runnable(){@Override public void run(){
        if(enabled()&&targetVisible&&!busy)scan();
        main.postDelayed(this,SCAN_INTERVAL_MS);
    }};
    private boolean enabled(){return getSharedPreferences("bot",MODE_PRIVATE).getBoolean("enabled",false);}
    private void diag(String s){getSharedPreferences("bot",MODE_PRIVATE).edit().putString("diagnostic",s).apply();}
    @Override public void onServiceConnected(){super.onServiceConnected();diag("Service connected. Waiting for Amaze GO...");main.removeCallbacks(scanLoop);main.post(scanLoop);}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){CharSequence p=event.getPackageName();if(p!=null){targetVisible=TARGET.contentEquals(p);if(targetVisible){diag("Amaze GO detected. Waiting for screenshot...");if(enabled()&&!busy)main.postDelayed(this::scan,180);}}}
    @Override public void onInterrupt(){diag("Accessibility service interrupted.");}
    @Override public void onDestroy(){main.removeCallbacks(scanLoop);super.onDestroy();}
    private void scan(){
        if(busy||!enabled()||!targetVisible)return; busy=true;
        diag("Amaze GO detected. Requesting screenshot...");
        try{takeScreenshot(Display.DEFAULT_DISPLAY,executor,new TakeScreenshotCallback(){
            @Override public void onSuccess(ScreenshotResult result){Bitmap bmp=null;try{
                HardwareBuffer hb=result.getHardwareBuffer();bmp=Bitmap.wrapHardwareBuffer(hb,result.getColorSpace());if(bmp!=null)bmp=bmp.copy(Bitmap.Config.ARGB_8888,false);if(hb!=null)hb.close();final Bitmap image=bmp;
                if(image!=null){captures++;final int w=image.getWidth(),h=image.getHeight();executor.execute(()->{ArrowDetector.Detection d=ArrowDetector.detect(image);image.recycle();main.post(()->{diag("CAPTURE OK #"+captures+"  "+w+"x"+h+"\n"+d.summary()+"\nDIAGNOSTIC MODE: no taps are sent.");busy=false;});});}
                else{diag("Screenshot returned no bitmap.");busy=false;}
            }catch(Throwable t){diag("Screenshot processing error: "+t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage()));busy=false;}}
            @Override public void onFailure(int errorCode){failures++;diag("SCREENSHOT FAILED code="+errorCode+" failures="+failures);busy=false;}
        });}catch(Throwable t){diag("Screenshot request error: "+t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage()));busy=false;}
    }
}
