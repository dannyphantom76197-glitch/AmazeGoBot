package com.example.amazegobot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class AmazeAccessibilityService extends AccessibilityService {
    private static final String TARGET="com.oakever.arrows";
    private static final long SCAN_INTERVAL_MS=500;
    private static final long AFTER_TAP_DELAY_MS=140;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Executor worker=Executors.newSingleThreadExecutor();
    private boolean busy=false,targetVisible=false;
    private int captures=0,taps=0,failures=0;
    private int requestId=0;

    private final Runnable scanLoop=new Runnable(){@Override public void run(){
        if(enabled()&&targetVisible&&!busy)scan();
        main.postDelayed(this,SCAN_INTERVAL_MS);
    }};
    private boolean enabled(){return getSharedPreferences("bot",MODE_PRIVATE).getBoolean("enabled",false);}
    private void report(String s){getSharedPreferences("bot",MODE_PRIVATE).edit().putString("diagnostic",s).apply();}
    @Override public void onServiceConnected(){super.onServiceConnected();report("Service connected. Waiting for Amaze GO...");main.removeCallbacks(scanLoop);main.post(scanLoop);}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){CharSequence p=event.getPackageName();if(p!=null){targetVisible=TARGET.contentEquals(p);if(targetVisible&&enabled()&&!busy)main.postDelayed(this::scan,100);}}
    @Override public void onInterrupt(){report("Accessibility service interrupted.");}
    @Override public void onDestroy(){main.removeCallbacks(scanLoop);super.onDestroy();}

    private void scan(){
        if(busy||!enabled()||!targetVisible)return;
        busy=true;
        final int myRequest=++requestId;
        report("V6.0 REQUEST #"+myRequest+" sent. Waiting for Android screenshot callback...");
        try{
            // V5.4 deliberately uses the service/main executor for takeScreenshot callbacks.
            // Only one request may be in flight; there is no timeout that can overlap a late callback.
            takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
                @Override public void onSuccess(ScreenshotResult result){
                    if(myRequest!=requestId){closeBuffer(result);return;}
                    report("V6.0 CALLBACK OK #"+myRequest+". Sending frame to worker...");
                    // Do ALL HardwareBuffer -> Bitmap work off the accessibility/main thread.
                    // This keeps Android's screenshot callback free and also tells us exactly
                    // which conversion stage succeeds on this phone.
                    worker.execute(()->{
                        HardwareBuffer hb=null;
                        Bitmap frame=null;
                        try{
                            report("V6.0 COPY #"+myRequest+" stage 1/3: getting HardwareBuffer...");
                            hb=result.getHardwareBuffer();
                            if(hb==null)throw new IllegalStateException("HardwareBuffer was null");
                            report("V6.0 COPY #"+myRequest+" stage 2/3: wrapping buffer...");
                            Bitmap wrapped=Bitmap.wrapHardwareBuffer(hb,result.getColorSpace());
                            if(wrapped==null)throw new IllegalStateException("wrapHardwareBuffer returned null");
                            report("V6.0 COPY #"+myRequest+" stage 3/3: making software bitmap...");
                            frame=wrapped.copy(Bitmap.Config.ARGB_8888,false);
                            if(frame==null)throw new IllegalStateException("Bitmap.copy returned null");
                            final int w=frame.getWidth(),h=frame.getHeight();
                            captures++;
                            report("V6.0 FRAME READY #"+captures+" "+w+"x"+h+". Detecting arrows...");
                            ArrowDetector.Detection d=ArrowDetector.detect(frame, p -> report("V6.0 DETECTOR #"+captures+" "+p));
                            frame.recycle();
                            frame=null;
                            main.post(()->handleDetection(d,w,h));
                        }catch(Throwable t){
                            if(frame!=null)try{frame.recycle();}catch(Throwable ignored){}
                            final String msg="V6.0 COPY ERROR #"+myRequest+": "+t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage());
                            main.post(()->{
                                report(msg);
                                busy=false;
                                main.postDelayed(()->{if(enabled()&&targetVisible&&!busy)scan();},3000);
                            });
                        }finally{
                            if(hb!=null)try{hb.close();}catch(Throwable ignored){}
                        }
                    });
                }
                @Override public void onFailure(int errorCode){
                    if(myRequest!=requestId)return;
                    failures++;
                    report("V6.0 SCREENSHOT FAILURE code="+errorCode+" request="+myRequest+" failures="+failures+". Waiting before next request...");
                    busy=false;
                    main.postDelayed(()->{if(enabled()&&targetVisible&&!busy)scan();},3000);
                }
            });
        }catch(Throwable t){
            if(myRequest==requestId){
                failures++;
                report("V6.0 REQUEST ERROR #"+myRequest+": "+t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage()));
                busy=false;
                main.postDelayed(()->{if(enabled()&&targetVisible&&!busy)scan();},3000);
            }
        }
    }

    private void closeBuffer(ScreenshotResult result){
        try{HardwareBuffer hb=result.getHardwareBuffer();if(hb!=null)hb.close();}catch(Throwable ignored){}
    }

    private void handleDetection(ArrowDetector.Detection d,int w,int h){
        if(!enabled()||!targetVisible){busy=false;return;}
        if(d.tap==null || d.clearTaps==null || d.clearTaps.isEmpty()){
            report("CAPTURE OK #"+captures+"  "+w+"x"+h+"\n"+d.summary()+"\nNo clear move found. Waiting to rescan.");
            busy=false; return;
        }
        int count=Math.min(8,d.clearTaps.size());
        report("V6.0 BATCH READY: "+count+" taps from "+d.clearCandidates+" clear arrows. "+d.summary());
        tapBatch(d.clearTaps,0,count);
    }

    private void tapBatch(java.util.List<ArrowDetector.Tap> batch,int index,int count){
        if(!enabled()||!targetVisible){busy=false;return;}
        if(index>=count){
            report("V6.0 batch complete ("+count+" taps). Rescanning...");
            main.postDelayed(()->{busy=false;requestId++;if(enabled()&&targetVisible&&!busy)scan();},AFTER_TAP_DELAY_MS);
            return;
        }
        ArrowDetector.Tap tap=batch.get(index);
        final float x=tap.x,y=tap.y;
        Path path=new Path();path.moveTo(x,y);
        GestureDescription gesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,45)).build();
        boolean accepted=dispatchGesture(gesture,new GestureResultCallback(){
            @Override public void onCompleted(GestureDescription g){
                taps++;
                report("V6.0 turbo tap "+(index+1)+"/"+count+" at "+Math.round(x)+","+Math.round(y));
                main.postDelayed(()->tapBatch(batch,index+1,count),55);
            }
            @Override public void onCancelled(GestureDescription g){
                report("V6.0 turbo tap cancelled. Rescanning safely...");
                main.postDelayed(()->{busy=false;if(enabled()&&targetVisible)scan();},250);
            }
        },main);
        if(!accepted){
            report("V6.0 Android rejected turbo tap. Rescanning safely...");
            main.postDelayed(()->{busy=false;if(enabled()&&targetVisible)scan();},250);
        }
    }

}
