package com.example.amazegobot;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.accessibilityservice.GestureDescription;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class AmazeAccessibilityService extends AccessibilityService {
    private static final String TARGET="com.oakever.arrows";
    private static final long SCAN_INTERVAL_MS=850;
    private static final long AFTER_TAP_DELAY_MS=220;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Executor worker=Executors.newSingleThreadExecutor();
    private volatile boolean busy=false,targetVisible=false;
    private long lastAutoSignature=Long.MIN_VALUE;
    private int attemptOnBoard=0;
    private int knownLives=-1;
    private int autoMoves=0;
    private boolean waitForMovement=false;
    private volatile String activePackage="unknown";
    private volatile boolean detectionRunning=false;
    private long previousBoardSignature=0;
    private int stableFrames=0;
    private int lastSignatureDifference=100;
    private long busySinceMs=0;
    private int captures=0,taps=0,failures=0,requests=0;
    private long firstScanMs=0,lastCompletedMs=0;
    private int requestId=0;
    private ArrowDetector.Detection pending=null;
    private static final float VERIFY_POS_PX=12f;
    private int verificationMismatches=0;
    private long lastCaptureMs=0,lastCopyMs=0,lastDetectMs=0;
    private long cycleStartNs=0,captureRequestNs=0,callbackNs=0,copyDoneNs=0,detectDoneNs=0,gestureSentNs=0;

    private final Runnable scanLoop=new Runnable(){@Override public void run(){
        if(busy && android.os.SystemClock.uptimeMillis()-busySinceMs>15000){
            requestId++; busy=false; pending=null;
            report("V9.5 WATCHDOG: scan exceeded 15s; recovering. captures="+captures+" taps="+taps);
        }
        if(enabled()){
            refreshTargetVisibility();
            if(targetVisible&&!busy&&!detectionRunning)scan();
            reportHeartbeat();
        }
        main.postDelayed(this,SCAN_INTERVAL_MS);
    }};
    private void reportHeartbeat(){
        long now=android.os.SystemClock.uptimeMillis();
        String stage=busy?(detectionRunning?"detecting":"capture/copy pending"):"idle";
        String text="V9.5 LIVE: requests="+requests+" completed="+captures+" failures="+failures+
            " busy="+busy+" stage="+stage+" targetVisible="+targetVisible+" activePackage="+activePackage+
            " uptime="+(firstScanMs==0?0:(now-firstScanMs)/1000)+"s"+
            " lastCompleteAgo="+(lastCompletedMs==0?"never":((now-lastCompletedMs)/1000)+"s");
        getSharedPreferences("bot",MODE_PRIVATE).edit().putString("heartbeat",text).apply();
    }
    private boolean autoEnabled(){return getSharedPreferences("bot",MODE_PRIVATE).getBoolean("auto_mode",false);}
    private boolean enabled(){return getSharedPreferences("bot",MODE_PRIVATE).getBoolean("enabled",false);}
    private void report(String s){getSharedPreferences("bot",MODE_PRIVATE).edit().putString("diagnostic",s).apply();}
    private void reportProgress(String s){getSharedPreferences("bot",MODE_PRIVATE).edit().putString("scan_progress",s).apply();}
    @Override public void onServiceConnected(){super.onServiceConnected();report("Service connected. Waiting for Amaze GO...");main.removeCallbacks(scanLoop);main.post(scanLoop);}
    // Fail closed: a previous game event must never authorize a later screenshot.
    private boolean gameIsForeground(){
        android.view.accessibility.AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null){activePackage="root unavailable";targetVisible=false;return false;}
        try{
            CharSequence pkg=root.getPackageName();
            activePackage=pkg==null?"unknown":pkg.toString();
            targetVisible=TARGET.equals(activePackage);
            return targetVisible;
        }finally{root.recycle();}
    }
    private void refreshTargetVisibility(){gameIsForeground();}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        // Do not use stale window-content events to declare the game foreground.
        if(enabled()&&!busy&&!detectionRunning && gameIsForeground())
            main.postDelayed(()->{if(gameIsForeground())scan();},100);
    }
    @Override public void onInterrupt(){report("Accessibility service interrupted.");}
    @Override public void onDestroy(){main.removeCallbacks(scanLoop);super.onDestroy();}

    private void scan(){
        if(busy||detectionRunning||!enabled()||!gameIsForeground())return;
        busy=true;
        if(firstScanMs==0)firstScanMs=android.os.SystemClock.uptimeMillis();
        requests++;
        busySinceMs=android.os.SystemClock.uptimeMillis();
        cycleStartNs=System.nanoTime();
        captureRequestNs=cycleStartNs;
        final int myRequest=++requestId;
        final boolean foregroundAtRequest=gameIsForeground();
        if(!foregroundAtRequest){busy=false;return;}
        reportProgress("V9.5 REQUEST #"+myRequest+" waiting for screenshot...");
        try{
            // V5.4 deliberately uses the service/main executor for takeScreenshot callbacks.
            // Only one request may be in flight; there is no timeout that can overlap a late callback.
            takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
                @Override public void onSuccess(ScreenshotResult result){
                    if(myRequest!=requestId){closeBuffer(result);return;}
                    callbackNs=System.nanoTime();
                    if(!gameIsForeground()){
                        closeBuffer(result);
                        busy=false;
                        report("V9.5 CAPTURE REJECTED: foreground="+activePackage+"; no game screenshot saved.");
                        return;
                    }
                    reportProgress("V9.5 CALLBACK #"+myRequest+" capture="+ms(captureRequestNs,callbackNs)+"ms. Copying...");
                    // Do ALL HardwareBuffer -> Bitmap work off the accessibility/main thread.
                    // This keeps Android's screenshot callback free and also tells us exactly
                    // which conversion stage succeeds on this phone.
                    worker.execute(()->{
                        HardwareBuffer hb=null;
                        Bitmap frame=null;
                        try{
                            reportProgress("V9.5 COPY #"+myRequest+" stage 1/3: getting HardwareBuffer...");
                            hb=result.getHardwareBuffer();
                            if(hb==null)throw new IllegalStateException("HardwareBuffer was null");
                            reportProgress("V9.5 COPY #"+myRequest+" stage 2/3: wrapping buffer...");
                            Bitmap wrapped=Bitmap.wrapHardwareBuffer(hb,result.getColorSpace());
                            if(wrapped==null)throw new IllegalStateException("wrapHardwareBuffer returned null");
                            reportProgress("V9.5 COPY #"+myRequest+" stage 3/3: making software bitmap...");
                            frame=wrapped.copy(Bitmap.Config.ARGB_8888,false);
                            if(frame==null)throw new IllegalStateException("Bitmap.copy returned null");
                            final int w=frame.getWidth(),h=frame.getHeight();
                            // A screenshot of our own app is not a valid game frame.
                            // Validate the foreground again before overwriting previews.
                            if(!targetVisible){
                                report("V9.5 FRAME REJECTED: active="+activePackage+"; previews preserved.");
                                frame.recycle();frame=null;
                                main.post(()->busy=false);
                                return;
                            }
                            captures++;
                            copyDoneNs=System.nanoTime();
                            final long copyMs=ms(callbackNs,copyDoneNs);
                            lastCaptureMs=ms(captureRequestNs,callbackNs); lastCopyMs=copyMs;
                            reportProgress("V9.5 FRAME #"+captures+" "+w+"x"+h+" capture="+ms(captureRequestNs,callbackNs)+"ms copy="+copyMs+"ms. Detecting...");
                            final long boardSignature=boardSignature(frame);
                            // Save the exact raw frame before any processing, paired with its mask.
                            // Both previews are overwritten together on each completed scan.
                            try {
                                java.io.File rawFile=new java.io.File(getFilesDir(),"v88-raw.png");
                                try(java.io.FileOutputStream stream=new java.io.FileOutputStream(rawFile)){
                                    if(!frame.compress(Bitmap.CompressFormat.PNG,100,stream))
                                        throw new java.io.IOException("Raw PNG compression failed");
                                }
                            }catch(Exception ex){reportProgress("Raw save error: "+ex.getMessage());}
                            // Persist processed segmentation preview from the same source frame.
                            if(!autoEnabled())try {
                                Bitmap mask=ArrowDetector.debugComponents(frame);
                                java.io.File file=new java.io.File(getFilesDir(),"v88-mask.png");
                                try(java.io.FileOutputStream stream=new java.io.FileOutputStream(file)){
                                    mask.compress(Bitmap.CompressFormat.PNG,100,stream);
                                }
                                mask.recycle();
                            }catch(Exception ex){reportProgress("Mask save error: "+ex.getClass().getSimpleName()+": "+ex.getMessage());}
                            if(!autoEnabled())try {
                                Bitmap nativeMask=ArrowDetector.debugNativeMask(frame);
                                java.io.File file=new java.io.File(getFilesDir(),"v95-native-mask.png");
                                try(java.io.FileOutputStream stream=new java.io.FileOutputStream(file)){
                                    if(!nativeMask.compress(Bitmap.CompressFormat.PNG,100,stream))
                                        throw new java.io.IOException("Native mask PNG compression failed");
                                }
                                nativeMask.recycle();
                            }catch(Exception ex){reportProgress("Native mask save error: "+ex.getMessage());}
                            final long detectStart=System.nanoTime();
                            detectionRunning=true;
                            final boolean runAuto=autoEnabled();
                            ArrowDetector.Detection diagnosticDetection=null;
                            AutoMovePlanner.Plan autoPlan=null;
                            try {
                                if(runAuto) autoPlan=AutoMovePlanner.plan(frame);
                                else diagnosticDetection=ArrowDetector.detect(frame,
                                    p -> reportProgress("V9.5 DETECTOR #"+captures+" "+p));
                            } finally { detectionRunning=false; }
                            detectDoneNs=System.nanoTime();
                            lastDetectMs=ms(detectStart,detectDoneNs);
                            frame.recycle();
                            frame=null;
                            final ArrowDetector.Detection d=diagnosticDetection;
                            final AutoMovePlanner.Plan plan=autoPlan;
                            main.post(()->{
                                if(myRequest!=requestId)return;
                                if(runAuto&&plan!=null)handleAutoPlan(plan);
                                else if(d!=null)handleDetection(d,w,h,boardSignature);
                                else busy=false;
                            });
                        }catch(Throwable t){
                            detectionRunning=false;
                            if(frame!=null)try{frame.recycle();}catch(Throwable ignored){}
                            final String msg="V9.5 COPY ERROR #"+myRequest+": "+t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage());
                            main.post(()->{
                                if(myRequest!=requestId)return;
                                report(msg);
                                busy=false;
                                main.postDelayed(()->{if(enabled()&&targetVisible&&!busy&&!detectionRunning)scan();},3000);
                            });
                        }finally{
                            if(hb!=null)try{hb.close();}catch(Throwable ignored){}
                        }
                    });
                }
                @Override public void onFailure(int errorCode){
                    if(myRequest!=requestId)return;
                    failures++;
                    report("V9.5 SCREENSHOT FAILURE code="+errorCode+" request="+myRequest+" failures="+failures+". Waiting before next request...");
                    busy=false;
                    main.postDelayed(()->{if(enabled()&&targetVisible&&!busy&&!detectionRunning)scan();},3000);
                }
            });
        }catch(Throwable t){
            if(myRequest==requestId){
                failures++;
                report("V9.5 REQUEST ERROR #"+myRequest+": "+t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage()));
                busy=false;
                main.postDelayed(()->{if(enabled()&&targetVisible&&!busy&&!detectionRunning)scan();},3000);
            }
        }
    }

    private void closeBuffer(ScreenshotResult result){
        try{HardwareBuffer hb=result.getHardwareBuffer();if(hb!=null)hb.close();}catch(Throwable ignored){}
    }

    private static long ms(long a,long b){return Math.max(0L,(b-a)/1000000L);}
    private String timings(){return "Capture="+lastCaptureMs+"ms Copy="+lastCopyMs+"ms Detect+clear="+lastDetectMs+"ms Mismatches="+verificationMismatches;}

    // Only dispatch after matching candidates from two independent frames.
    private static long boardSignature(Bitmap b){
        // Region-normalized color occupancy: ignores the changing HUD and brightness
        // in the white background. A 16x24 grid captures coarse board structure.
        int w=b.getWidth(),h=b.getHeight();
        int top=Math.max(240,(int)(h*.18)),bottom=Math.min(h-180,(int)(h*.84));
        long hash=1469598103934665603L;
        for(int gy=0;gy<24;gy++)for(int gx=0;gx<16;gx++){
            int[] counts=new int[6];
            for(int yy=0;yy<4;yy++)for(int xx=0;xx<4;xx++){
                int x=25+(int)((w-50)*(gx+(xx+.5)/4.)/16.);
                int y=top+(int)((bottom-top)*(gy+(yy+.5)/4.)/24.);
                counts[ArrowDetector.colorLabel(b.getPixel(Math.min(w-1,x),Math.min(h-1,y)))]++;
            }
            int dominant=0;for(int k=1;k<6;k++)if(counts[k]>=4&&counts[k]>counts[dominant])dominant=k;
            hash^=dominant;hash*=1099511628211L;
        }
        return hash;
    }
    /** V12.0 opt-in experimental autoplay. Never gesture outside the foreground game. */
    private void handleAutoPlan(AutoMovePlanner.Plan plan){
        if(!enabled()||!autoEnabled()||!gameIsForeground()){
            busy=false;waitForMovement=false;return;
        }
        lastCompletedMs=android.os.SystemClock.uptimeMillis();
        // Compare the last observed life count with the new scan. Stop on a loss.
        if(knownLives>=0&&plan.lives>=0&&plan.lives<knownLives){
            getSharedPreferences("bot",MODE_PRIVATE).edit().putBoolean("auto_mode",false).apply();
            report("AUTO STOPPED: life counter decreased from "+knownLives+" to "+plan.lives+
                ". No further automatic taps. "+plan.summary());
            knownLives=plan.lives;busy=false;return;
        }
        if(plan.lives>=0)knownLives=plan.lives;
        if(plan.signature!=lastAutoSignature){
            lastAutoSignature=plan.signature;
            attemptOnBoard=0;
            waitForMovement=false;
        }else if(waitForMovement){
            // A tap didn't produce detectable board progress; don't repeat it.
            attemptOnBoard++;
            waitForMovement=false;
        }
        if(plan.moves.isEmpty()){
            report("AUTO HOLD: no arrow with both an identifiable head and clear head ray. "+
                plan.summary()+"; taps="+taps);
            busy=false;return;
        }
        if(attemptOnBoard>=Math.min(6,plan.moves.size())){
            // Stop on repeated no-op taps. Avoid wasting lives and endless loops.
            getSharedPreferences("bot",MODE_PRIVATE).edit().putBoolean("auto_mode",false).apply();
            report("AUTO STOPPED: no detected progress after "+attemptOnBoard+
                " different taps on one board. "+plan.summary());
            busy=false;return;
        }
        AutoMovePlanner.Move move=plan.moves.get(attemptOnBoard);
        if(!gameIsForeground()){busy=false;return;}
        Path path=new Path();path.moveTo(move.x,move.y);
        GestureDescription gesture=new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path,0,70)).build();
        boolean accepted;
        try{
            accepted=dispatchGesture(gesture,new GestureResultCallback(){
                @Override public void onCompleted(GestureDescription g){
                    taps++;autoMoves++;busy=false;
                    waitForMovement=true;
                    report("V12 AUTO TAP #"+autoMoves+" sent: "+move+
                        "\n"+plan.summary()+"\nWill check screenshot for progress or lost life.");
                }
                @Override public void onCancelled(GestureDescription g){
                    busy=false;report("AUTO gesture cancelled. Try reopening the game; "+move);
                }
            },main);
        }catch(Exception ex){accepted=false;report("AUTO gesture error: "+ex.getClass().getSimpleName()+" "+ex.getMessage());}
        if(!accepted){busy=false;report("AUTO gesture not accepted; confirm Accessibility and foreground game.");}
    }

    // V11.2 permanently disables gesture dispatch. This diagnostic build is
    // intentionally incapable of moving game pieces while direction identity,
    // exact pixel hitboxes, and swept-path collision remain unverified.
    private void handleDetection(ArrowDetector.Detection d,int w,int h,long signature){
        if(!enabled()||!gameIsForeground()){pending=null;busy=false;return;}
        if(signature==previousBoardSignature)stableFrames++;else stableFrames=1;
        previousBoardSignature=signature;
        lastCompletedMs=android.os.SystemClock.uptimeMillis();
        String stats="\n"+d.summary()+"\nFrame signature="+Long.toHexString(signature)+
            " identical consecutive frames="+stableFrames+
            " (exact coarse color-grid match)"+"\n"+timings();
        pending=null;
        report("V11.2 SAFE HOLD: preliminary arrowheads are not verified safe moves. "+
            "captures="+captures+" requests="+requests+" failures="+failures+" taps="+taps+stats);
        busy=false;
    }
}
