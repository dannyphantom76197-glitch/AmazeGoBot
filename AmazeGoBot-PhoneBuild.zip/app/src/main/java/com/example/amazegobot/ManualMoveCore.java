package com.example.amazegobot;


/**
 * V11.4: pure-Java, read-only comparison of two actual game frames.
 * Ink is compared by occupied foreground pixels, NOT filled bounding boxes:
 * foreground inside the outline of a disappearing hollow shape remains its own ink.
 * A changed image is an observation, not a verified physics / tap model.
 */
public final class ManualMoveCore {
    private ManualMoveCore() {}

    public static final byte UNCHANGED=0, REMOVED=1, ADDED=2, RETAINED=3, REPLACED=4;
    public static final class Result {
        public final int width,height;
        public final int[] roi;
        public final byte[] labels;
        public int beforeInk,afterInk,removed,added,retained;
        public int removalGroups,largestGroup,retainedInsideLargest;
        public int[] largestBounds;
        Result(int w,int h,int[] rect){width=w;height=h;roi=rect.clone();labels=new byte[w*h];}
        public String summary(){
            return "beforeInk="+beforeInk+" afterInk="+afterInk+
                " removed="+removed+" added="+added+" retained="+retained+
                " removedGroups="+removalGroups+" largestRemoved="+largestGroup+
                " retainedInsideRemovedBox="+retainedInsideLargest;
        }
        public boolean plausibleSingleRemoval(){
            // Heuristic only: cannot determine whether one *game* arrow moved.
            return removed>=50 && added<=Math.max(24,removed/8)
                && retained>=50
                && largestGroup>=30;
        }
    }
    /** Same high-chroma game-ink gate as the main detector, expressed without Android. */
    static int inkClass(int argb){
        int r=(argb>>>16)&255,g=(argb>>>8)&255,b=argb&255;
        int hi=Math.max(r,Math.max(g,b)),lo=Math.min(r,Math.min(g,b));
        if(hi<95||hi-lo<24||lo>235||(hi-lo)*100<32*hi)return 0;
        boolean magenta=r>g+30&&b>g+25&&Math.abs(r-b)<115;
        boolean green=g>r+15&&g>b+8;
        boolean blue=b>r+17&&b>g+7;
        boolean yellow=r>b+38&&g>b+25&&r>=g-20;
        boolean red=r>g+25&&r>b+20&&g>=b-18;
        if(magenta)return 1;
        if(green)return 2;
        if(blue)return 3;
        if(yellow)return 4;
        if(red)return 5;
        return 0;
    }
    /** Only 1px spatial tolerance for antialiasing/jitter, matched by color family. */
    private static boolean near(byte[] other,int w,int h,int x,int y,int c,int[] roi){
        for(int yy=Math.max(roi[1],y-1);yy<=Math.min(roi[3]-1,y+1);yy++)
            for(int xx=Math.max(roi[0],x-1);xx<=Math.min(roi[2]-1,x+1);xx++)
                if((other[yy*w+xx]&255)==c)return true;
        return false;
    }
    public static Result compare(int[] before,int[] after,int w,int h,int[] roi){
        if(w<=0||h<=0||before==null||after==null||before.length!=w*h||after.length!=w*h)
            throw new IllegalArgumentException("Captured frames must have the same dimensions");
        if(roi==null||roi.length!=4||roi[0]<0||roi[1]<0||roi[2]>w||roi[3]>h||
                roi[0]>=roi[2]||roi[1]>=roi[3])throw new IllegalArgumentException("Invalid board ROI");
        Result result=new Result(w,h,roi);
        byte[] a=new byte[w*h],b=new byte[w*h];
        for(int y=roi[1];y<roi[3];y++)for(int x=roi[0];x<roi[2];x++){
            int p=y*w+x;
            a[p]=(byte)inkClass(before[p]);b[p]=(byte)inkClass(after[p]);
            if(a[p]!=0)result.beforeInk++;
            if(b[p]!=0)result.afterInk++;
        }
        for(int y=roi[1];y<roi[3];y++)for(int x=roi[0];x<roi[2];x++){
            int p=y*w+x,bc=a[p]&255,ac=b[p]&255;
            boolean gone=bc>0&&!near(b,w,h,x,y,bc,roi);
            boolean newInk=ac>0&&!near(a,w,h,x,y,ac,roi);
            if(gone)result.removed++;
            if(newInk)result.added++;
            if(gone&&newInk)result.labels[p]=REPLACED;
            else if(gone)result.labels[p]=REMOVED;
            else if(newInk)result.labels[p]=ADDED;
            else if(ac>0){result.labels[p]=RETAINED;result.retained++;}
        }
        // Largest erased connected ink piece; may be one of several disconnected
        // parts of a longer arrow. Never use its bounds as the moving hitbox.
        boolean[] visited=new boolean[w*h];
        int[] queue=new int[(roi[2]-roi[0])*(roi[3]-roi[1])];
        for(int y=roi[1];y<roi[3];y++)for(int x=roi[0];x<roi[2];x++){
            int root=y*w+x;
            if(result.labels[root]!=REMOVED||visited[root])continue;
            result.removalGroups++;
            int front=0,back=0,minX=x,maxX=x,minY=y,maxY=y;
            queue[back++]=root;visited[root]=true;
            while(front<back){
                int p=queue[front++],px=p%w,py=p/w;
                minX=Math.min(px,minX);maxX=Math.max(px,maxX);
                minY=Math.min(py,minY);maxY=Math.max(py,maxY);
                for(int yy=Math.max(roi[1],py-1);yy<=Math.min(roi[3]-1,py+1);yy++)
                    for(int xx=Math.max(roi[0],px-1);xx<=Math.min(roi[2]-1,px+1);xx++){
                        int q=yy*w+xx;
                        if(result.labels[q]==REMOVED&&!visited[q]){visited[q]=true;queue[back++]=q;}
                    }
            }
            if(back>result.largestGroup){
                result.largestGroup=back;
                result.largestBounds=new int[]{minX,minY,maxX+1,maxY+1};
            }
        }
        if(result.largestBounds!=null){
            int[] q=result.largestBounds;
            for(int y=q[1];y<q[3];y++)for(int x=q[0];x<q[2];x++)
                if(result.labels[y*w+x]==RETAINED)result.retainedInsideLargest++;
        }
        return result;
    }
}
