# Level 517 ground truth and V11.4 validation

## Observed by user

The user reports one successful *manual* tap on the **blue outer arrow** on
Level 517. It disappeared without losing a life, and the orange arrows inside
were left in their original places. This is valuable motion ground truth,
not evidence the detector had correctly identified a safe move beforehand.

## What is currently available for verification

The uploaded Android source ZIP includes no matched **original**
`BEFORE.png` / `AFTER.png` pair from that manual move. Prior screenshots shown
in conversation do not supply an aligned original-bitmap pair in this source
archive. As a result V11.4 does **not** claim an empirically replayed Level 517
collision or a model learned from this one observation.

## Regression test done locally (synthetic only)

`tests/ManualMoveCoreTest.java` creates a hollow blue rectangular stroke
surrounding two separate stationary orange and green ink strokes. The AFTER
array deletes only the blue stroke. The comparison correctly detects:

- 1556 blue ink pixels removed
- 0 new ink pixels
- 228 previously present interior pixels retained
- 228 retained pixels inside the blue outline's former bounding rectangle
- 1 largest erased connected component

Additional tests confirm that unchanged boards do not count as moves,
new pixels do not count as removal, a blue-to-orange recolor is counted as
replacement (not a clean departure), an unrelated HUD edit is ignored, and
invalid crop bounds are rejected.

Run tests on a desktop JDK 17 (no Android SDK needed):

```sh
mkdir -p /tmp/amazego-testclasses
javac -d /tmp/amazego-testclasses \
  app/src/main/java/com/example/amazegobot/ManualMoveCore.java \
  tests/ManualMoveCoreTest.java
java -cp /tmp/amazego-testclasses ManualMoveCoreTest
```

The app itself still needs a real Android/GitHub APK build, and V11.4 needs a
user-supplied fresh BEFORE/AFTER manual-move comparison before further claims.
