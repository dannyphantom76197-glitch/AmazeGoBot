# Level 517 — exact raw-capture replay (2026-10-20)

Input: supplied original Amaze GO image `AmazeGoBot-Raw-1792496912849.png`.
Dimensions: **1080 × 2408 PNG**. For privacy/size, the original screenshot is not
embedded in the source ZIP: the audit reads captures saved by the installed bot.

The V11.1 calibrated color-neutral foreground extractor detected:

- Puzzle ROI, inclusive bounding approximate: `x=59..1013, y=839..1497`.
- **61 substantial 8-connected colored-ink regions** (>=45 foreground pixels).
- HUD droplets and the large beige/white background excluded.

The V11.2 arrowhead audit skeletonizes the regions, then looks at crosswise ink
width 0, 4, 8, 12 and 16 pixels *behind* each potential endpoint. A triangle
head should broaden and then narrow onto its shaft, unlike a flat tail.
- **44 regions** had a unique, plausible head and cardinal travel direction.
- **17 regions** had no unique matching endpoint or were ambiguous.
- **0 of 44** had a clear, 1px-guarded full-ink sweep through the entire ROI.
- **0 verified gameplay-safe moves; 0 automatic taps**.

The above counts came from running `ArrowheadAudit.render()` against the exact
1080x2408 PNG using equivalent desktop image/graphics stubs (headless replay).
`ArrowheadAudit.java` was also compiled by Java 17 in the stub harness. The
entire Android APK was **not** built or installed locally; GitHub Actions must
compile the Android project using the included workflow.

A second previously supplied raw Level 500 image (`1080x2408`) was replayed:
57 substantial foreground regions, 15 unique tentative tips, and no clear
full-ink sweeps in their inferred directions.

**Important:** The foreground mask is not a game hitbox. A connected region may
still combine multiple puzzle arrows, a tip can be misclassified, antialiasing
can create false joins/splits, and the software does not prove real game
collision rules. A clear ink sweep, even if observed, will NOT authorize a tap.
No `dispatchGesture()` calls are present in the V11.2 service.
