# Level 517 — V11.3 local replay

Supplied original game capture `AmazeGoBot-Raw-1792496912849.png` is **not**
embedded in this source package. Image dimensions: 1080 x 2408.
ROI estimate: x=59..1013, y=839..1497 (exclusive maxima).

The Android-compatible Java bitmap analysis was replayed with Java 17 and
minimal image/graphics stubs (full Android APK not built here).

| Metric | Level 517 original |
|---|---:|
| Foreground connected regions | 61 |
| Unique tentative tip directions | 44 |
| Ambiguous regions | 17 |
| Exact-ink clear corridors | 0 |
| 1px-guard clear corridors | 0 |
| First-hit distance median | 16 image pixels |
| First-hit distance <=5px | 0 |
| Opposite direction exact-ink clear | 0 |
| Crop-clipped regions among classified heads | 0 |
| Verified safe moves | 0 |
| Automatic taps | 0 |

The later V11.2 phone screenshot reported 42 tips and 19 ambiguous, consistent
with reclassification across frames. No game move is established by either.

A previous Level 500 raw image had 57 connected regions, 15 classified tips,
0 exact-ink clear corridors in guessed directions, 5 reverse corridors clear.

V11.3 collision code was independently checked with a synthetic case:
1. No neighboring foreign pixels -> exact-ink corridor clear.
2. Different region 11 pixels ahead, on same scanline -> exact hit at 11px.
3. Different region on adjacent scanline -> exact clear, guard-only hit at 11px.

These are **mask-level geometry diagnostics**, not validated in-game hitboxes.
