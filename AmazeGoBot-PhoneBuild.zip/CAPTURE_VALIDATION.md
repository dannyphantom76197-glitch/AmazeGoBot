# V11.1 original-capture replay: Level 500

Supplied source: an original 1080×2408 RGBA PNG captured inside Amaze GO, not a phone photograph.

Offline analysis of the level with eight-connected foreground components:

| Measurement | Previous path-pixel rule | Calibrated ink rule |
|---|---:|---:|
| Connected components (game-only area) | 437 | 57 |
| Components smaller than 45 pixels | 380 | 0 |
| Substantial components | 57 | 57 |
| Puzzle ROI (full 1080×2408 image) | x=108..972, y=236..1802 | x=85..997, y=637..1813 |

Test method: RGB saturation threshold equivalent to `(maxRGB-minRGB)*100 >= 32*maxRGB`, previous stroke color classification, and eight-neighbor connected components. New ROI ignores top 20% of image and pads pixel-ink extents 24–26 pixels. No fabricated or reconstructed game data has been used.

Observations:
- Blue life droplets located in upper game UI were included in the old ROI.
- Beige dotted background was incorrectly accepted as yellow ink with the old color predicate.
- Clean foreground components plausibly correspond to arrow strokes, but proof of arrowhead direction and complete independent arrow identity remains unfinished.
- This project deliberately does **not** dispatch automatic gestures. No safe move has been independently validated.

This report validates *segmentation on the supplied capture only*. It does not validate compilation, generalization to all levels, or gameplay success.
