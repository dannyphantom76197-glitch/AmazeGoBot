# Amaze GO Bot V9.5 — Full-resolution segmentation diagnostic

This is an incremental diagnostic build, **not an automatic solver**.

## Changes
- Added **SHOW FULL-RESOLUTION STROKE MASK** to inspect thin paths without 3x downsampling.
- Retained existing raw screenshot and labeled downsampled mask.
- Updated Android versionName to 9.5 and versionCode to 95.
- Kept the hard no-tap safety lock: arrows are not reconstructed into complete paths yet.

## Phone test
1. Upload this ZIP contents to the existing GitHub repository and run the Build APK workflow.
2. Install the resulting APK; enable accessibility and BOT ON.
3. Keep Level 413 visible until at least one capture completes.
4. Return to the bot and choose **SHOW FULL-RESOLUTION STROKE MASK**.
5. Share the displayed mask and diagnostic text to guide the next reconstruction step.

**Known limitations:** Color thresholding may miss faint stroke pixels or include interface colors. Connected fragments and candidate arrowheads are not proven movable arrows. No automatic taps are dispatched.
