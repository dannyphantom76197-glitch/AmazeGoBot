## V11.4.1 (Android immutable Bitmap crash fix)

Fixed the V11.4 COMPARE AFTER MY MANUAL MOVE crash:
`IllegalStateException: Immutable bitmap passed to Canvas constructor`.
`ManualMoveAudit.render` now allocates a mutable ARGB_8888 bitmap and copies
comparison pixels with `setPixels` before drawing the overlay. No gameplay
gestures were enabled. Reinstall this package using the existing GitHub Actions
APK build workflow, repeat a manual before/after capture, and inspect the overlay.

**Validation:** pure-Java `ManualMoveCoreTest` is run by the workflow. Android
UI/Canvas behavior still requires an installed APK test on the phone.

# Amaze GO Bot V11.4 — Observed Manual-Move Evidence

**This is Android source for GitHub Actions. It is NOT an APK.**
**NO AUTOMATIC TAPS** are enabled in this release. There is no gesture dispatch.

## What V11.4 adds

Previous releases inferred possible arrowheads and collisions from one screenshot. Their
whole-shape collision predictions did not agree with the user's observed Level 517
manual move: a long blue border arrow departed while the arrows it enclosed remained
in place and no life was lost.

V11.4 adds a controlled **BEFORE / AFTER** snapshot comparison for a *single manual*
game move. It does not pretend to know which tap is safe.

- Saves a frozen raw game screenshot as `v114-before.png` on the phone.
- Compares it with the new raw game screenshot automatically saved by the existing
  accessibility scanning service after the user makes a manual move. It freezes
  the AFTER image as `v114-after.png`, avoiding a later scan overwriting the pair.
- Uses actual ink pixels, not rectangular boxes, to detect disappearing geometry.
  Stationary ink inside a hollow frame can be counted as **retained**, not deleted.
- Uses a union of before/after board regions, so the board crop does not shrink
  around the missing outer arrow.
- Counts removed ink, newly drawn ink, retained ink, erased connected parts, and
  retained pixels inside the largest erased region's bounding rectangle.
- One-pixel spatial matching accommodates very slight antialias/jitter; foreground
  color families are compared so whole-board recoloring is NOT confused with removal.
- Renders a visible image: **pink** disappeared, **orange** new, **green** retained,
  **purple** recolored or replaced. Box only locates the largest erased part; it
  is **not** a filled hitbox.
- Includes **V11.4 EXPORT BEFORE / AFTER PNG PAIR** to save both original frames
  to `Pictures/AmazeGoBot` in Photos for sharing and visual verification.
- Preserves V11.3 first-blocker and previous inspection buttons.

### How to run the V11.4 manual experiment

1. Install V11.4 by building the source ZIP on GitHub (instructions below). Leave
   bot scanning enabled and allow its Accessibility permission.
2. Show ONE level in Amaze GO for 8–10 seconds with the whole board visible.
3. Return to the bot and press **V11.4 MARK LAST GAME SCREEN AS BEFORE**.
   It rejects missing or more-than-3-minute-old scans.
4. Return to the **same** game level and tap exactly **ONE** arrow **manually**.
   Observe whether it leaves without losing a life. Keep the changed board visible
   at least 8 seconds so the bot captures the AFTER frame.
5. Return to the bot, press **V11.4 COMPARE AFTER MY MANUAL MOVE**, and screenshot
   its report/annotated picture. Do not perform a second move before comparing.
6. Press **V11.4 EXPORT BEFORE / AFTER PNG PAIR** to save the two actual game
   images into Photos. Send both original PNGs when troubleshooting.
7. If frames show mismatched levels, screen orientation, dynamic overlays, or major
   board shifts, discard this comparison and repeat. A color/shape difference is
   not proof of collision rules or successful gameplay.

For actual Level 517 comparison, a new matched BEFORE screenshot and AFTER screenshot
must be captured. The earlier successful blue-border manual move is user-reported
and **no original matched before/after PNG pair is present in the uploaded ZIP**.

### What it does NOT do

- No tap recommendation, automatic tapping, or gameplay gesture delivery.
- Does not yet infer safe movement rules across all game levels.
- Does not distinguish touching/overlapping arrows reliably in every image.
- The color-mask evidence cannot establish exact collision hitboxes.
- It does not persist a learned model; it reports each manually controlled experiment.

## Phone-only APK build on GitHub

1. Unzip `AmazeGoBot-V11.4-PhoneBuild.zip` on your phone.
2. Upload **the files and folders inside** the ZIP to the **root** of your existing
   GitHub repository (replace older source files). Do NOT upload just the `.zip`
   archive as one repo file.
3. Open **Actions → Build Amaze GO Bot APK**, and run or wait for the triggered job.
4. Wait for a **green** success check. Open **Artifacts**, download
   `AmazeGoBot-debug`, unzip it, and install `app-debug.apk` on the phone.
5. If the job is red, send the FIRST red Java or Gradle error, not just `exit code 1`.

The source includes `.github/workflows/build-apk.yml` for the APK compilation.
A full Android SDK / Gradle build was **not available in this environment**.
The pure-Java V11.4 comparison engine was compiled and tested with Java 17.
