# Amaze GO Bot V8.8 — raw capture diagnostics

Build the Android APK using the included GitHub Actions workflow.

This version saves the exact captured screenshot as `v88-raw.png` and the geometry segmentation as `v88-mask.png` from the same scan. Open the app after a scan to view either image using the two preview buttons. The diagnostic screen itself may appear in a capture if the game is no longer foreground at the moment of capture.

Automatic tapping remains disabled until complete-path collision validation is implemented and tested. This update is for debugging screenshot source versus detector segmentation; it does not fix arrow-path tracing.
