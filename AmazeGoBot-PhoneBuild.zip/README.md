# Amaze GO Bot V9.2 — stroke graph diagnostic

Build on GitHub with the included Actions workflow. V9.2 preserves the V9.1 foreground capture and color-stroke segmentation, and adds topology markers to the processed mask: cyan = possible stroke endpoints; pink = possible junctions. These markers are diagnostic pixels, not identified arrows. The mask is downsampled and can introduce false branches or endpoints. This version **does not** reconstruct complete arrows, verify whole-body exit corridors, or perform taps. It intentionally retains the safe hold.

Test with Level 413 visible for 30 seconds, then inspect both raw and processed mask previews. Check whether endpoints/junctions align with the arrow drawing.
