# Amaze GO Bot V8.4 — Improved Shape Mask Diagnostics

This is a **diagnostic build**, not a working auto-solver. Automatic taps remain disabled.

## Changes
- Captures thin lines more reliably by checking all 9 source pixels in each 3×3 downsample cell instead of one pixel.
- Shows labels near connected-region centroids instead of overlapping orange bounding boxes.
- Reports the connected fragment count from the **same mask** shown in the preview.
- Arrowhead candidate scoring is retained as a separate heuristic.

## Still not solved
Connected regions are not necessarily individual arrows. Complete winding-arrow reconstruction, directional full-shape sweep collision testing, and verified safe moves are **not implemented**. Do not enable tapping based on these diagnostics.

## Phone GitHub build
Replace repository contents with the ZIP contents. Run GitHub Actions > Build Amaze GO Bot APK. Download the debug APK from the completed workflow artifact. With the game open, wait for scanning, then tap SHOW LABELED MASK FRAGMENTS and compare the preview with the game board.
