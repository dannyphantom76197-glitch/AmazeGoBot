# Amaze GO Bot V9.3 — Component Trace Diagnostics

Build with the included GitHub Actions workflow. V9.3 labels each connected stroke component with `C# e#` (component number and local endpoint-pixel count), highlights components with apparent branches in magenta, and reports component counts. These are **not** confirmed arrow identities. The current 3x-downsampled mask may break narrow strokes and connect adjacent ones.

**Automatic tapping remains disabled**. A valid complete-arrow reconstruction and swept-body collision check are not yet implemented. Never treat a clear arrowhead ray as proof of a safe move.

To test: enable Accessibility, open Level 413 for at least 30 seconds, then inspect both the raw capture and processed geometry mask. Check whether a single drawn arrow maps to one component or several.
