# Amaze GO Bot V12.0 — Experimental Automated Taps

**This ZIP contains Android source for GitHub Actions, not a precompiled APK.**
The existing GitHub workflow builds `app-debug.apk` in the `AmazeGoBot-debug` artifact.

## New auto-play functionality

- **START EXPERIMENTAL AUTO PLAY** at the top of the app: turns on scanning and
  opt-in gesture dispatch. Leave the bot and open the Amaze GO game.
- Finds the puzzle's ink strokes from the full-resolution screenshot; groups
  continuous strokes; uses thinned ink endpoints to estimate a single arrowhead
  direction; checks the forward head ray for foreign ink; chooses a tap on that
  detected stroke. Scores candidates based on head profile and border distance.
- Uses the Android Accessibility gesture interface for one tap at a time.
- Re-captures the game after each tap and refuses to repeat the same position
  on an unchanged board; after six attempts or candidate exhaustion without
  progress, auto-play stops. Tap **STOP AUTO PLAY NOW** whenever you want.
- Tries to count blue life icons; if the displayed life count decreases, auto
  mode turns itself OFF after that screenshot.
- Keeps the earlier diagnostic mode and the manual before/after investigation
  buttons. These are retained as debugging tools.
- Skips generating the heavy visual debug overlays during auto-play scans.

**IMPORTANT LIMITATIONS:** The algorithm is experimental. The game's rigid-body
collision rules and touch hitboxes have not been verified. Connected fragments
may combine unrelated strokes or split one arrow; a clear arrowhead ray is NOT
proof that the moving arrow's full body can depart. The game may deduct a life
before a screenshot can detect it. It may stop with no candidates. It cannot
promise winning every level, 10,000 levels, or an exact completion time. Do
not assume it is safe to leave unattended. Developer compiled/tested the pure
Java movement-comparison tests, and exercised the new offline arrow planner
on three existing captured images. **An actual Android APK build and an
on-device automatic-tap test have NOT been performed in this environment.**

## Build and use from Android phone

1. Extract this ZIP. In your existing GitHub `AmazeGoBot` repository, replace
   the existing source with the folders/files **inside** this archive. The ZIP
   itself, as a single uploaded file, will not be compiled.
2. Run **Actions → Build Amaze GO Bot APK** (or use the automatic push run).
3. A green run provides **Artifacts → AmazeGoBot-debug**. Download, unzip,
   install `app-debug.apk` and enable the app's Accessibility service.
4. Open the bot; press **START EXPERIMENTAL AUTO PLAY**; go back to Amaze GO.
5. Watch the first taps; stop immediately if they are incorrect. The bot stops
   itself if a detected life icon disappears or the board doesn't change.
6. If it stays in AUTO HOLD, that means no arrow satisfied the approximate
   head-and-ray filter. More screen data and a better game motion model will
   be needed; no guaranteed safe guess is possible from the current evidence.

## Source history

V11.4.1 includes the corrected mutable-bitmap manual before/after comparison,
and `tests/ManualMoveCoreTest.java` regression tests. These remain in the ZIP.
