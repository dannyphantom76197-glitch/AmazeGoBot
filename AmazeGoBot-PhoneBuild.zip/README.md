Amaze GO Bot V6.2 Timing Diagnostic

Based on V5.9 Safe Turbo. Detector, clear-path logic, gesture duration, scan interval and post-tap timing remain unchanged. Adds elapsed-time diagnostics for screenshot capture, HardwareBuffer copy, detection+clear-path analysis, gesture completion, and total pre-settle cycle time.
