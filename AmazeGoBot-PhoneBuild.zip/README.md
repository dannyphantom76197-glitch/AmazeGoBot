# Amaze GO Bot V9.4 — Topology Classification Diagnostics

This is a conservative diagnostic update from V9.3, not a functioning automatic solver.

- Classifies connected stroke fragments as `2E` (two detected endpoints), `BR` (branch-like), or `FR` (other fragments). These are **not** confirmed individual arrows.
- Preserves raw screenshot and processed geometry-mask previews.
- Keeps the hard safety lock: **no automatic taps**.
- Uses the included GitHub Actions workflow to compile an APK.

The downsampled segmentation may still split one arrow or merge adjacent arrows. The next major engineering step is validated full-resolution arrow extraction, directional swept-body collision checks, and replay verification. Do not enable taps from endpoint counts alone.

Test: open Level 413, allow scans, then view the processed geometry mask. Inspect the number of `2E`, `BR`, and `FR` labels.
