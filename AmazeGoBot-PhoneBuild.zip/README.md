V6.6 NO-TAP DIAGNOSTIC. This build never dispatches gestures. Use to inspect clear candidates, timing and verification agreement.
