# Amaze GO Bot V8.9 — screenshot preview repair

The raw preview button now loads `v88-raw.png`, and the geometry mask button now loads `v88-mask.png`. Both show explicit errors if the files are absent or cannot be decoded. The accessibility capture service and detector are otherwise unchanged from the uploaded V8.8 source.

Build on GitHub with the included Actions workflow (`Build Amaze GO Bot APK`). Download the `AmazeGoBot-debug` artifact and install the APK.

**Automatic taps remain disabled** pending full-path collision validation. After a scan, return to the app and press either preview button, then scroll down to view the image.
