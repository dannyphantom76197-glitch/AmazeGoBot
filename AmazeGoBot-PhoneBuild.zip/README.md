Amaze GO Bot V8.1 — Shape Mask Diagnostics

Color-neutral diagnostic preview: saturated path pixels are rendered as a single blue mask irrespective of hue. Connected-component count now reports shape fragments, not color groups or individual arrows. The existing candidate detection is experimental; full arrow tracing and complete swept-path collision verification are NOT implemented. Automatic tapping remains disabled. Build with the existing GitHub Actions workflow.
