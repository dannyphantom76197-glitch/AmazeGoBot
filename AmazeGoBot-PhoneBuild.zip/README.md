Amaze GO Bot V6.8: reduced detection workload, screenshot watchdog recovery, and improved scan diagnostics. Build with GitHub Actions. Conservative clear-path verification remains enabled.
