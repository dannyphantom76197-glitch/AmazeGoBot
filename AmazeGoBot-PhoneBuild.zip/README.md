# Amaze GO Bot V9.1 — colored-stroke mask diagnostic

The raw capture pipeline from V9.0 is retained. The geometry mask now selects colored red, yellow, green, and blue strokes rather than treating dark pixels and the white game background as geometry. Pink/magenta surrounding UI is excluded. The diagnostic overlay labels fragments, **not** verified individual arrows.

**Automatic taps are disabled**: complete arrow tracing and full-shape collision simulation have not been implemented or validated. The existing arrowhead and clear-ray counts are diagnostics only.

Build using GitHub Actions (`Build Amaze GO Bot APK`), install the generated debug APK, open the game for 30 seconds, then return to inspect the raw capture and processed geometry mask. If the mask includes large background areas or misses arrow strokes, share both previews.
