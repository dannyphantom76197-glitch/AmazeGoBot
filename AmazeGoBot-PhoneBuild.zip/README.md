# Amaze GO Bot V8.0 — Visible Color Mask Preview

- Fixes the preview button feedback: a persistent status message, explicit file/decode errors, and scroll-to-image behavior.
- The color mask is saved as `v80-mask.png` in private app storage on every successful screenshot.
- Connected color-component counts remain experimental fragments, **not** verified arrows.
- No automatic taps; complete-path collision verification is not implemented.
- Upload this ZIP as `AmazeGoBot-PhoneBuild.zip` to the GitHub repository and download the APK artifact from the successful Actions run.
- This source ZIP has not been compiled or tested on a device in this environment.
