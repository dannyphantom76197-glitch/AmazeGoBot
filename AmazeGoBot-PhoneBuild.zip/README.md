# Amaze GO Bot V10.8 - Path Evidence Diagnostics

This update adds a V10.8 path-evidence preview combining bent-stroke tracing, forward head-ray clearance, ambiguity flags and estimated board bounds. Open the game, scan, then tap **V10.8 SHOW PATH EVIDENCE**.

**Safety/accuracy limitation:** A clear head ray and heuristic bent stroke do NOT establish a complete rigid arrow path. Full-shape collision detection is not implemented or validated. Automatic taps remain disabled. This ZIP is source code for the existing phone-based GitHub Actions APK workflow, not a compiled APK.

All arrow colors follow the same straight-line rigid translation rule. No color-specific movement rule is assumed.
