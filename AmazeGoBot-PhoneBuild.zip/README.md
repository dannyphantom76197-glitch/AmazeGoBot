# Amaze GO Bot V11.3 — First-Blocker Collision Diagnostics

**Diagnostic only — NO AUTOMATIC TAPS.** This ZIP is Android source for building
with GitHub Actions on a phone. It is not an installable APK.

## What changed

- Keeps the raw capture, colored-stroke segmentation, head-tip hypotheses, and
  V11.1/V11.2 diagnostic screens from the previous project.
- Adds **V11.3 SHOW FIRST COLLISION / DIRECTION AUDIT**. In every tentative
  direction, the new audit identifies the first *other detected region* that
  would overlap a rigidly translated shape and estimates how many whole image
  pixels the shape would travel before that overlap.
- Separately measures *exact-foreground collision* (zero extra margin) from
  an additional **one-pixel perpendicular guard**.
- Makes its collision calculation start at a strictly **positive displacement**
  and reports possible clipped regions rather than indiscriminately rejecting
  edge-near objects as blocked.
- Reports reverse-direction *exact ink corridor* separately as a possible sign
  of misclassified head direction. This is **NOT** permission to move a shape
  backward; actual arrow direction remains essential.
- Marks tentative head locations with colored circles and the first other-ink
  pixel with a small purple dot. Label format is `#region:dir>other/gapPx`.
- Preserves the fail-safe: no gesture dispatch is present; neither green/blue
  marks nor numerical distances prove actual game-hitbox clearance.

## Verified local replays (diagnostic-only)

**Original, user-supplied Level 517 PNG** (1080 x 2408 pixels)

- 61 connected foreground regions.
- 44 uniquely classified *tentative* tip directions, 17 ambiguous. These
  counts differ slightly from a later Android screenshot (42/19) because that
  was a different captured frame.
- V11.3: 0 of 44 have an exact-ink clear rigid-sweep corridor in the guessed
  direction; 0 clear with the additional 1px guard.
- First other-ink hit: median 16 image pixels, none within 5 pixels.
- 0 reversed exact-ink clear corridors for those 44 guesses.
- 0 connected regions clipped at the crop edge.

**Previous original Level 500 PNG**: 57 foreground regions, 15 tentative
head directions, 0 exact-ink clear in their guessed directions; five reverse
ones clear (that does not establish proper arrow direction).

Unit-level synthetic geometry tests passed: an empty corridor, an exact other-
ink collision at 11 pixels, and an 11-pixel guard-only collision.
The new audit was Java-compiled and executed in a headless desktop Android-
graphics stub. **A complete Android APK was not built locally**; use GitHub
Actions for the full Android compile and install test.

## Build on Android phone with GitHub

1. Unzip `AmazeGoBot-V11.3-PhoneBuild.zip`.
2. In your existing GitHub repo, upload the **files and folders inside** the
   ZIP to the project root, replacing existing files of the same names.
   Do not upload just the ZIP as a repository asset.
3. Go to **Actions → Build Amaze GO Bot APK** and run the build or open the
   automatically triggered run. Wait for a green success check mark.
4. Under Artifacts, download `AmazeGoBot-debug`, unzip it, and install
   `app-debug.apk` on the phone (enable installing unknown apps if prompted).
5. In the bot, enable its accessibility service and scanning, show a game
   level long enough for the bot to capture it, return to the bot, and tap
   **V11.3 SHOW FIRST COLLISION / DIRECTION AUDIT**.
6. Send a clear screenshot of its black diagnostic header and annotated board.
   For future comparison, use **V11.3 SAVE ORIGINAL GAME CAPTURE TO PHOTOS**
   to share the original PNG directly.

## Current limit

The rigid whole-region sweep model may be incorrect for the game's motion rules,
or segmentation may incorrectly combine/split arrows. The next decisive test
would be one *known successful* manual move recorded before and after using
original screenshots. Do not enable blind tapping from these diagnostics.
