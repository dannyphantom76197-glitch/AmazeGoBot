Amaze GO Bot V6.7 / Build #58 source. Two-frame verified auto-tap. Build via GitHub Actions. Detection is heuristic; taps are not guaranteed safe.
