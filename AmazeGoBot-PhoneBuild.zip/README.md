# Amaze GO Bot V10.1 — Local Terminal Diagnostics

GitHub Actions Android build project. Upload all project contents to the repository and run the included build-apk workflow.

V10.1 adds local terminal-neighborhood evidence on each color-connected stroke candidate, in addition to V10.0 global extremity direction hypotheses. Local terminal clues and multi-terminal counts are diagnostic only: they do NOT establish individual arrow identity, correct direction, or collision-free exit paths.

**Safety:** Automatic taps remain disabled. The scanner does not yet reconstruct verified complete arrows or validate collision-free movement.

**Validation:** Source changes were inspected but APK compilation and runtime tests have not been performed here.


## V10.2 diagnostic update

A new **V10.2 SHOW HEAD / CORRIDOR EVIDENCE** button overlays potential arrowhead locations on the last raw screenshot. Green circles mean the forward *head-only* corridor looks clear; red means it looks blocked. Neither proves the complete bent arrow can move. This is a diagnostic, not a safe-move solver, and automatic taps remain disabled.

To use: enable scanning, open a game level until capture finishes, return to the bot, scroll to the V10.2 button, and open its preview. Build using the existing GitHub Actions workflow.


## V10.3 diagnostic update

Added **V10.3 SHOW BACKWARD STROKE CONTINUITY**. It probes short straight stroke runs behind head hypotheses, displays counts for head-ray clearance and backward continuity, and marks combined preliminary candidates green. This does **not** trace bends, identify complete arrows, or test full-body swept collisions. Automatic taps remain disabled. Build and test on the device; APK compilation was not performed in this environment.
