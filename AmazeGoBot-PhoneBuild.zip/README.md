# Amaze GO Bot V8.7 — Contrast Geometry Diagnostics

**Diagnostic only: no automatic taps.** The detector does not yet reconstruct complete arrows or verify collisions.

Changes:
- Replaces hue-specific detection gates with luminance/chroma contrast for thin pastel arrows on white backgrounds.
- Uses the same contrast predicate for mask preview and candidate scoring.
- Fixes preview button reading the wrong filename (`v83-mask.png`); both writer and viewer now use `v87-mask.png`.
- Updates displayed build version to V8.7.
- Retains conservative no-tap safety lock.

**Test:** Build using GitHub Actions, install APK, enable accessibility service, open a level, wait 30 seconds, then open the app and tap **SHOW V8.7 GEOMETRY MASK**. Check that the mask contains the arrows and that candidate counts are nonzero. The mask may contain merged or broken fragments; this version does not play the game.
