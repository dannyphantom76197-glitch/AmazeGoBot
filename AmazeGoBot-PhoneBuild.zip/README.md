# Amaze GO Bot V7.3 — Color Scan Diagnostics
This is a real source update, but NOT a full path solver and NOT hands-free gameplay.
- Samples colored game pixels across the board, groups them into six approximate color families, and reports these values during scanning.
- Retains arrowhead candidate statistics.
- Automatic taps remain disabled: winding-path reconstruction and swept-area collision tests are not yet implemented.
- Color groups are only approximate; colors alone cannot separate adjacent arrows of the same color.
- Next: collect actual in-game screenshot frames, segment individual strokes, identify arrowheads and validate safe paths offline before enabling taps.
Build using GitHub Actions workflow. Android APK compilation has not been validated here.
