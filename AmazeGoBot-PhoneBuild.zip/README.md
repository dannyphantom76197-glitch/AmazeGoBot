# Amaze GO Bot V11.0 — Whole-Region Swept-Path Diagnostics

This is a **diagnostic-only** Android project. **No automatic taps are enabled.**

## What the V10.9 screenshots showed
- Level 491's original strokes were captured, and 78 coarse fragments and 35 head hypotheses were reported.
- Even with 23 head rays passing the old check, ZERO full arrow shapes were verified. The detector deliberately returns a null tap.
- V10.9 same-hue connectivity does not prove those fragments are separate arrows; some segments may touch/merge or split at changes in hue.

## What changed
- Adds **V11.0 SHOW WHOLE-REGION SWEEP AUDIT**: enumerates same-hue connected ink regions at original screenshot resolution and tests the area swept if **every pixel** were translated rigidly in each of the four directions, stopping on other captured ink. A 1px perpendicular collision margin is applied.
- Cyan boxes are **possible clear sweeps** *only if* a region is one complete arrow and the indicated direction matches its actual head. Orange boxes are blocked/unknown; red boxes are clipped by the detected board rectangle. Oversize regions are skipped.
- This is a preliminary collision diagnostic; region identities, head direction, gaps, and moving whole shapes still require validation. None of these results authorize game gestures.
- Adds **V11.0 SAVE ORIGINAL GAME CAPTURE TO PHOTOS** so users can supply pixel-perfect `v88-raw.png` evidence rather than photographs of a screen.
- Keeps all earlier diagnostic screens.

## Test on phone
1. Upload the **unpacked contents** of this project to the root of your GitHub repository.
2. Let `.github/workflows/build-apk.yml` build the debug APK and install it from the workflow artifact.
3. Open a game level and leave it visible while scanning completes.
4. Return to the app and choose **V11.0 SHOW WHOLE-REGION SWEEP AUDIT**. Photograph the overlay if needed.
5. Press **V11.0 SAVE ORIGINAL GAME CAPTURE TO PHOTOS** and send the resulting *original PNG* from Photos / Pictures/AmazeGoBot for more reliable path reconstruction and testing.

## Important limitation
This version **does not yet detect verified arrow identities, valid head directions, or successful full-arrow exit paths**. Do not interpret a cyan label as an authorized safe move. Taps remain disabled.
