# Amaze GO Bot V7.5 — Connected Components Prototype
New: coarse color-labeled connected-component scan (8-connected flood fill, min 7 sampled pixels) on screenshots, plus prior arrowhead statistics.
The reported **colored components are NOT verified individual arrows**. Paths can be split by aliasing, and nearby same-colored lines can merge.
No full-path tracing, swept collision solver, or automatic tapping is implemented. No automatic taps will be sent.
Build from this ZIP named exactly `AmazeGoBot-PhoneBuild.zip` in the existing GitHub workflow.
Test: screenshot should display V7.5 and `colored components=` in LAST RESULT after scanning a game board.
Android compilation and gameplay have not been verified.
