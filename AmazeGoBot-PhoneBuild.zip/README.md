# Amaze GO Bot V10.6 — Pink-Stroke Coverage Diagnostics

This revision fixes the V10.5 magenta-ink exclusion and replaces fixed vertical cropping in native and downsampled masks with a detected puzzle region. Board coverage now displays the estimated region for visual confirmation.

**Safety:** Diagnostic only. No automatic taps. Complete-arrow path reconstruction and full swept-path collision verification are not implemented.

## Phone build
Upload the contents of this ZIP to your GitHub repository, replacing matching files. Open **Actions**, select the APK build workflow, and run it. Download the APK from the workflow artifacts when the build succeeds.

## Test
Open Level 452, keep it fully visible, run diagnostics, and inspect the V10.6 board coverage and full-resolution stroke mask. Verify all pink arrows appear in the mask and all arrowheads fall inside the green rectangle.
