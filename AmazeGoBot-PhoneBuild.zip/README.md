# Amaze GO Bot V10.9 — Color Connectivity Diagnostics

This Android Studio / GitHub Actions project remains **diagnostic-only**. Automatic taps are intentionally disabled.

## What changed
- Added **V10.9 SHOW COLOR CONNECTIVITY AUDIT** to examine the saved full-resolution screenshot.
- Groups same-hue pixels into 8-connected regions and outlines substantial connected regions.
- Displays component counts, tiny fragments, and edge-touching components.
- Preserves V10.8 path-evidence and earlier diagnostics.

**Important:** A connected color region is not necessarily a complete movable arrow. No full-path reconstruction or swept-body collision verification is implemented. Do not enable automatic taps on this evidence.

## Build
Upload the ZIP contents to a GitHub repository and run the included Actions workflow to build the APK.

## Test
1. Install the newly built APK and grant accessibility permission.
2. Open a game level, turn scanning on, and allow a screenshot to be captured.
3. Return to the app and select **V10.9 SHOW COLOR CONNECTIVITY AUDIT**.
4. Inspect whether boxes correspond to individual strokes or incorrectly merge adjacent arrows.
