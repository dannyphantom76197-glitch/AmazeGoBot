# V7.6 Persistent Path Diagnostics
- Persists completed scan summary separately from transient progress, so the result is not overwritten by subsequent scans.
- Displays colored connected-component count, color samples, arrowhead candidates, complete paths=0, verified safe moves=0.
- Connected components are NOT reconstructed winding arrows. Same-colored neighboring lines can merge; antialiasing can split lines.
- Diagnostic safety lock: automatic taps are disabled even if a detector later returns a candidate.
- This is not a full-path solver; collision simulation and automatic level progression are not implemented.
- Use ZIP filename `AmazeGoBot-PhoneBuild.zip` for the existing GitHub Actions workflow.
- Android compilation not verified locally.
