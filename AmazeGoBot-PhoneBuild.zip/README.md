Amaze GO Bot V8.3 — Numbered Shape Fragments Diagnostic

Shows white shape pixels on a black mask, with orange bounding boxes and numeric labels on up to 40 of the largest connected regions. Numbers identify image fragments, NOT complete arrows or verified safe moves. The scan is color-neutral for its shape preview.

The prior arrowhead heuristic and statistics are retained for comparison. Complete-path tracing and collision verification are NOT implemented. Automatic taps remain disabled.

Install: Replace repository files with the extracted ZIP contents, trigger GitHub Actions Build Amaze GO Bot APK, download app-debug.apk from the latest successful artifact, and test with the game open. Press SHOW NUMBERED FRAGMENTS and send a screenshot.
