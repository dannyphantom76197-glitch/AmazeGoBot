# Amaze GO Bot V11.2 — Arrow Tip & Full-Ink Sweep Diagnostics

**Diagnostic-only: this Android project intentionally cannot tap the game.**
It is a GitHub Actions phone-build Android source project, not an APK.

## What V11.2 changes

- Preserves the V11.1 clean saturated-ink extraction that rejects the game's
  pale guide dots and excludes the HUD from the board ROI.
- Thins each full-resolution connected region to find candidate endpoints.
- Compares crosswise ink widths *behind* the endpoints to identify tentative
  triangle arrowheads and their UP/RIGHT/DOWN/LEFT travel directions.
- Only labels a head when the region has **exactly one** plausible head/
  direction according to the current diagnostic threshold. Others stay unknown.
- Checks the **full connected ink component**, including bends, against all
  other foreground pixels along the hypothesized movement direction. The 1-pixel
  guard is conservative and does not claim game hitbox accuracy.
- Adds **V11.2 SHOW ARROW TIP / DIRECTION AUDIT** below the V11.1 audit button.
  Orange circles mean blocked/unknown swept ink; green circles mean the *ink*
  corridor looks empty. Neither color indicates a verified safe gameplay move.
- Removes all gesture-dispatch code from the accessibility service. There is no
  code path that can automatically tap a game piece in this version.

## Results on a supplied original Level 517 PNG

See `LEVEL517_VALIDATION.md` for the reproducible measurements.

| Measurement | V11.2 Level 517 |
|---|---:|
| Colored connected regions | 61 |
| Regions with one tentative tip/direction | 44 |
| Ambiguous/unclassified | 17 |
| Full-ink sweeps unobstructed | 0 |
| Gameplay-safe verified moves | 0 |
| Automatic taps | 0 |

This is **not** a solved arrow graph. Color segmentation, ambiguity, true sprite
hitboxes, and post-move board validation still require more evidence and work.
V11.2 does not guarantee correct classification on other levels/phones.

## Build an APK from your Android phone using GitHub Actions

1. Unzip `AmazeGoBot-V11.2-PhoneBuild.zip` on your phone.
2. Upload the **contents of the folder**, not just the ZIP, into the **root**
   of your existing GitHub repository. Replace previous project files.
3. Open GitHub → your repo → **Actions** → **Build Amaze GO Bot APK**.
4. Run the workflow or select the latest push-triggered run, wait for a green
   check mark, and open the `AmazeGoBot-debug` artifact.
5. Download and unzip that artifact, then open `app-debug.apk` to install it.
6. Enable the bot Accessibility service in Android Settings, turn on scanning,
   and leave the game level visible for one or more completed captures.
7. Return to the bot and tap **V11.2 SHOW ARROW TIP / DIRECTION AUDIT**.
8. If needed, save/share the *original* capture using **V11.2 SAVE ORIGINAL
   GAME CAPTURE TO PHOTOS**, rather than photographing a second phone.

The Android project depends on the runner's Android SDK and Gradle. A desktop
stub compilation validated the V11.2 audit code, but **a full APK build was
not available locally**. GitHub Actions is the compilation/install check.
