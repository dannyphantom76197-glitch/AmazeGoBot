# Amaze GO Bot V9.8 — Stroke Candidate Diagnostics

Retains boundary-touching stroke components and highlights connected pixels in alternating diagnostic colors, with candidate IDs and bounding boxes. Puzzle ROI is derived from dense rows.

IMPORTANT: Same-color connected components are not verified individual arrows. Automatic taps remain disabled. No complete swept-path solver is implemented.

Build with included GitHub Actions workflow, capture Level 413, then press V9.8 HIGHLIGHT STROKE CANDIDATES and share screenshot.
