# Amaze GO Bot — Android prototype

This is a native Android prototype for automatically solving Amaze GO (`com.oakever.arrows`).

## What it does

1. Uses an Android AccessibilityService.
2. Captures the visible screen.
3. Detects the brown/yellow arrow graphics.
4. Looks for an arrow whose path toward the edge is clear.
5. Dispatches a real tap at the arrow.
6. Waits and repeats.

The solver is intentionally conservative: if it cannot find a sufficiently confident move, it stops instead of guessing.

## Build

Open this folder in Android Studio and let Gradle sync. Build the `app` debug APK.

This project targets Android API 36 and requires Android 11+ because it uses `AccessibilityService.takeScreenshot()`.

## Install / enable

1. Install the debug APK.
2. Open **Amaze GO Bot**.
3. Tap **Open Accessibility Settings**.
4. Enable **Amaze GO Bot**.
5. Return to the bot app and switch **BOT ON**.
6. Open Amaze GO and leave a puzzle visible.

Start with Level 76 for testing.

## Important

This is a first-pass computer-vision solver, not a guaranteed all-level solver yet. Amaze GO has many layouts and the game can change its rendering between updates. If it stops on Level 76, send the bot log/screenshot and the detector can be tuned against the real board.

The game itself states that the player should find an arrow with a free path to the edge and tap it; a wrong tap can cost a heart. The bot therefore avoids tapping when it cannot identify a clear move.

## Android APIs

The implementation uses the official AccessibilityService screenshot and gesture APIs. `takeScreenshot()` is available from API 30, and `dispatchGesture()` is available from API 24.
