# Amaze GO Bot V11.1 — Clean-Stroke Segmentation & Sweep Audit

This package is a **diagnostic-only** Android project. **It does not tap arrows.** It is an
unpacked GitHub Actions phone-build project (upload the contents into your repository root).

## Why V11.0 could not verify moves

A true, pixel-perfect original Level 500 PNG (`1080 × 2408`) was supplied and analyzed.
The old board ROI included the blue lives/advertising UI and was too close to the
left/right arrow boundaries. The faint beige guide dots passed the previous yellow
ink filter. Each dot became a false connected ink fragment or collision obstacle.

**Offline replay of the supplied Level 500 capture:**
- Old chroma predicate, cropping the game area: 437 connected components, **380 below 45px**.
- Saturation-calibrated predicate, same game area: **57 substantial components, no fragments below 45px**.
- Previous ROI: approx `{x:108..972, y:236..1802}`.
- New ROI: approx `{x:85..997, y:637..1813}`.
- The dotted guide background and HUD are excluded from the updated audit.

The new components are **connected stroke shapes**, not automatically proven arrows.
Some touching ink could still merge multiple arrows. Some edges or arrowheads may
also be ambiguous. A promising swept corridor is not enough to prove a safe move.

## Changes in V11.1

1. Filter low-saturation beige dotted background from the detector's ink predicate.
2. Begin the puzzle-ROI search below the HUD (upper 20% ignored) and use a bigger margin.
3. Merge connected ink even when a drawn arrow changes its color along its body.
4. Run the swept-region test on that clean, color-neutral segmentation.
5. Display **V11.1 SHOW CLEAN INK / SWEEP AUDIT** and retain the raw capture/export buttons.
6. Keep a strict safe-hold: no gesture dispatch until independent arrowhead direction
   and complete rigid-body collision proof have been validated on actual game frames.

## Phone build

1. Unzip and upload the **contents**, not the ZIP itself, into the root of your GitHub repo.
2. In Actions, run `Build Amaze GO Bot APK`, or allow the push trigger to start it.
3. Download the `AmazeGoBot-debug` workflow artifact after the build completes, unzip it,
   and install the debug APK from Android's Files app.
4. Open a level (ideally Level 500), leave it visible for at least one scan.
5. Return to the bot and press **V11.1 SHOW CLEAN INK / SWEEP AUDIT**. Check whether
   the green border encloses **all actual arrow strokes** without including lives.

**Not solved by V11.1:** arrowhead direction, touching shapes, and full-path collision
validation. No verified safe moves or automatic taps are claimed.
