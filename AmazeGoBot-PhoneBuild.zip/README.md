# Amaze GO Bot V10.1 — Local Terminal Diagnostics

GitHub Actions Android build project. Upload all project contents to the repository and run the included build-apk workflow.

V10.1 adds local terminal-neighborhood evidence on each color-connected stroke candidate, in addition to V10.0 global extremity direction hypotheses. Local terminal clues and multi-terminal counts are diagnostic only: they do NOT establish individual arrow identity, correct direction, or collision-free exit paths.

**Safety:** Automatic taps remain disabled. The scanner does not yet reconstruct verified complete arrows or validate collision-free movement.

**Validation:** Source changes were inspected but APK compilation and runtime tests have not been performed here.
