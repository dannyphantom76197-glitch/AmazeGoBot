Amaze GO Bot V6.5 Verified Timing. Based on V6.4.1. Adds capture/copy/detection timing and verification mismatch counters. Detector and gesture logic unchanged.
