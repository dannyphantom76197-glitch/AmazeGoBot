# Amaze GO Bot V9.9 — Arrow Tip Hypothesis Diagnostics

Based on the uploaded V9.8 project. Preserves screenshot capture, same-color stroke-component overlays, and GitHub Actions phone build.

NEW: Each connected stroke component receives a conservative extremity-density test to propose a direction when exactly one extremity matches. Green dot and a label ending in ? mean a *hypothesis*, not a verified arrow. Ambiguous candidates are counted separately.

IMPORTANT: This does not yet reconstruct full arrow topology or test swept-path collisions. Automatic taps remain disabled to avoid losing lives.

Build using .github/workflows/build-apk.yml. On Level 413, press V9.9 HIGHLIGHT TIP HYPOTHESES and share the overlay and diagnostic count.
