# Amaze GO Bot V10.5 — Board Coverage Diagnostics

This update adds a **V10.5 SHOW BOARD COVERAGE CHECK** preview to help diagnose why the full-resolution mask sometimes contains only a handful of fragments even though the game board contains many arrows.

The green rectangle estimates the detected ink area using the saved raw screenshot and current color filter. Compare its boundaries to the actual board. The image also reports sampled ink pixels and estimated bounds. This is a heuristic, **not arrow identification**. The V10.4 bent-stroke diagnostic remains available.

**Automatic tapping remains disabled.** Neither full-arrow reconstruction nor complete-path collision validation has been achieved. This update does not claim to solve levels automatically.

Build: upload ZIP contents to GitHub repository, run Actions → Build Amaze GO Bot APK → Run workflow, and download the debug APK artifact. After installation, enable accessibility, open the game long enough for a capture, then return to the bot and select the V10.5 check.

# Amaze GO Bot V10.1 — Local Terminal Diagnostics

GitHub Actions Android build project. Upload all project contents to the repository and run the included build-apk workflow.

V10.1 adds local terminal-neighborhood evidence on each color-connected stroke candidate, in addition to V10.0 global extremity direction hypotheses. Local terminal clues and multi-terminal counts are diagnostic only: they do NOT establish individual arrow identity, correct direction, or collision-free exit paths.

**Safety:** Automatic taps remain disabled. The scanner does not yet reconstruct verified complete arrows or validate collision-free movement.

**Validation:** Source changes were inspected but APK compilation and runtime tests have not been performed here.


## V10.2 diagnostic update

A new **V10.2 SHOW HEAD / CORRIDOR EVIDENCE** button overlays potential arrowhead locations on the last raw screenshot. Green circles mean the forward *head-only* corridor looks clear; red means it looks blocked. Neither proves the complete bent arrow can move. This is a diagnostic, not a safe-move solver, and automatic taps remain disabled.

To use: enable scanning, open a game level until capture finishes, return to the bot, scroll to the V10.2 button, and open its preview. Build using the existing GitHub Actions workflow.


## V10.3 diagnostic update

Added **V10.3 SHOW BACKWARD STROKE CONTINUITY**. It probes short straight stroke runs behind head hypotheses, displays counts for head-ray clearance and backward continuity, and marks combined preliminary candidates green. This does **not** trace bends, identify complete arrows, or test full-body swept collisions. Automatic taps remain disabled. Build and test on the device; APK compilation was not performed in this environment.


## V10.4 diagnostic update
Adds bent-stroke hypothesis tracing with fork detection and a new preview button. These traces are not verified individual arrows; complete-path collision testing and automatic taps remain disabled.
