# Amaze GO Bot V8.5 — Geometry Fragment Diagnostics

This is a diagnostic-only iteration based on V8.4. Automatic tapping remains **disabled**.

Changes:
- Labels the larger connected mask regions and displays a count of regions of at least 20 mask pixels.
- Clarifies that labels are fragment IDs, **not** reconstructed complete arrows.
- Keeps arrowhead candidate reporting and the existing conservative safe hold.
- Does not use arrow color to choose a move.

**Not yet implemented:** reliable complete-arrow reconstruction, shape translation collision simulation, or automatic gameplay. No claims of safe moves are made.

Build using the included GitHub Actions workflow. On a level screen, capture the diagnostic mask and compare its fragment boundaries with the actual arrows. The next step requires resolving touching/crossing strokes and validating each arrowhead-to-tail trace before any automatic taps can be enabled.
