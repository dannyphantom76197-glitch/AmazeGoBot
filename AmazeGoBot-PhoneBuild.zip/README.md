Amaze GO Bot V9.7 - Puzzle Region Diagnostics

This build detects a high-density puzzle region and labels same-color connected components inside it. Edge-touching components are rejected. The boxes do not prove individual arrow identity. Full swept-path collision verification is NOT implemented; automatic tapping remains disabled.

Build using .github/workflows/build-apk.yml. Open game, allow capture, return to app and press V9.7 ANALYZE PUZZLE REGION. Send screenshot of results.
