# Amaze GO Bot V10.0 — Direction Evidence Diagnostics

GitHub Actions Android build project. Upload the project contents to your GitHub repository and run the included build-apk workflow.

V10.0 changes: adds per-component four-direction extremity evidence, marks multiple plausible directions as ambiguous, and prints evidence scores on the overlay. A green marker is a single plausible direction; orange indicates multiple plausible directions. Neither is a verified arrow or safe move. The legacy scanner and full-resolution stroke mask remain.

**Safety:** automatic taps are disabled. The app does not yet reconstruct verified complete arrow bodies or perform collision testing. No claim of accurate gameplay is made.

**Validation:** source updated; APK compilation and runtime testing have not been performed here.
