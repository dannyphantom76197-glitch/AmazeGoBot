# Amaze GO Bot — V6.1 Rapid Safe

Built from the known-correct V5.9 one-move-at-a-time version.

Changes only timing:
- scan loop: 900 ms -> 180 ms
- post-tap settle: 220 ms -> 70 ms
- gesture duration: 70 ms -> 35 ms
- immediate follow-up scan: 80 ms -> 20 ms

Detector, clear-path selection, screenshot pipeline, and one-fresh-frame-per-tap safety model are unchanged.
