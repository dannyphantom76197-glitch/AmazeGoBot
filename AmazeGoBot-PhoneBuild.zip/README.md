# Amaze GO Bot V7.9 — Board Color Mask Diagnostics

- Continues scan counters and per-color connected fragment counts.
- Uses a coarse 16x24 grid of classified board colors for frame signatures, excluding HUD/background brightness. Exact matches remain strict and are not proof of correct path detection.
- Adds **Show last color mask** button to inspect which colored pixels the classifier sees. This is a segmentation preview, not traced complete paths or a collision overlay.
- Adjusts orange-vs-red color classification ordering.
- No automatic taps. No complete-path reconstruction or collision verification yet.
- GitHub workflow builds the ZIP when uploaded as AmazeGoBot-PhoneBuild.zip. APK not locally compiled.
