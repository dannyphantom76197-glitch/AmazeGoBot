# Amaze GO Bot V7.4 — Color Scan Diagnostics

This is a diagnostic build, not a fully automatic puzzle solver.

- Visible UI and scan log now consistently say V7.4.
- Every screenshot samples colored pixels from the gameplay scan area and reports `color samples` alongside arrowhead candidate statistics.
- Automatic tapping remains disabled to avoid losing lives: full connected-path segmentation and swept-area collision verification are not implemented.
- The existing arrowhead detector is preliminary and its candidate counts do not represent solved arrows.
- Build via GitHub Actions using the exact root filename `AmazeGoBot-PhoneBuild.zip`.
- Android compilation and gameplay have not been verified in this environment.
