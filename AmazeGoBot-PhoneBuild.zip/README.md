# Amaze GO Bot V7.7 — Stable Components Diagnostics
- `LAST RESULT` is only updated on completed detection, not each screenshot phase.
- `SCAN PROGRESS` shows capture and detector progress.
- Every completed result includes `colored components=` and `color samples=`.
- Adds quantized color board signature and identical-consecutive-frame count (diagnostic only).
- Counts are not individual verified arrows; complete paths and verified safe moves remain zero.
- Automatic taps are disabled. No path tracing or collision solver has been implemented.
- Rename this ZIP to `AmazeGoBot-PhoneBuild.zip` for the existing GitHub workflow.
- APK compilation not tested locally.
