# Amaze GO Bot V8.6 — Continuous Scan and Thin Mask Diagnostics

Diagnostic-only build. **Automatic taps remain disabled** until complete arrow paths and translation collisions are validated.

Changes from V8.5:
- Refresh game visibility from the active accessibility window root on each 2-second scan tick.
- Ignore unrelated window events rather than treating them as proof that the game disappeared.
- Replace 3x3 any-hit mask dilation with centerline/majority sampling to reduce merged adjacent strokes.
- Save `v86-mask.png` diagnostic preview.
- Keep existing 15-second capture watchdog and live scan counters.

Build with GitHub Actions. Check that requests and completed scans continue increasing while the game is open for at least 60 seconds. The mask may still have broken or merged lines; it is **not** a verified arrow-path reconstruction.
