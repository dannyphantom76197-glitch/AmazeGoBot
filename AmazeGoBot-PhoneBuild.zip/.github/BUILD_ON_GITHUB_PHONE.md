# Build on your phone with GitHub Actions

1. Create a GitHub account at https://github.com/ if you do not already have one.
2. Create a new repository, e.g. `AmazeGoBot`.
3. Upload all files from this project into the repository, preserving folders.
4. Make sure `.github/workflows/build-apk.yml` is present.
5. Open the repository's **Actions** tab and select **Build Amaze GO Bot APK**.
6. Tap **Run workflow**. Wait for the run to finish successfully.
7. Open the completed workflow run, scroll to **Artifacts**, and download `AmazeGoBot-debug`.
8. Open the downloaded ZIP on your Android phone and install the APK inside it.

The APK is a debug build for testing. Android may ask you to allow installation from the browser/files app you used to download it.
