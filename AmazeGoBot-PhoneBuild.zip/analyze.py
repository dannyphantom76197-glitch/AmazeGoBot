import cv2,numpy as np
im=cv2.imread('/mnt/data/AmazeGoBot-Raw-1792471501136.png')[:,:,::-1].astype(np.int16)
h,w=im.shape[:2]
r,g,b=np.moveaxis(im,2,0);hi=np.maximum.reduce([r,g,b]);lo=np.minimum.reduce([r,g,b]);valid=(hi>=95)&(hi-lo>=24)&(lo<=235)&((hi-lo)*100>=32*hi)
red=(r>g+25)&(r>b+20)&(g>=b-18)
magenta=(r>g+30)&(b>g+25)&(abs(r-b)<115)
green=(g>r+15)&(g>b+8)
blue=(b>r+17)&(b>g+7)
yellow=(r>b+38)&(g>b+25)&(r>=g-20)
valid &= red|magenta|green|blue|yellow
leftLimit=max(24,w//24);rightLimit=w-leftLimit;topLimit=max(200,h//5);bottomLimit=min(h-70,h*9//10)
coords=np.mgrid[topLimit:bottomLimit:2,leftLimit:rightLimit:2]
rowc=valid[topLimit:bottomLimit:2,leftLimit:rightLimit:2].sum(1)
colc=valid[topLimit:bottomLimit:2,leftLimit:rightLimit:2].sum(0)
ys=np.where(rowc>=4)[0]*2+topLimit
xs=np.where(colc>=4)[0]*2+leftLimit
roi=(max(leftLimit,xs[0]-24),max(topLimit,ys[0]-24),min(rightLimit,xs[-1]+26),min(bottomLimit,ys[-1]+26))
print('shape', w,h,'roi',roi)
mask=np.zeros((h,w),np.uint8);x0,y0,x1,y1=roi;mask[y0:y1,x0:x1]=valid[y0:y1,x0:x1].astype('uint8')
for conn in (4,8):
 n,l,st,cent=cv2.connectedComponentsWithStats(mask,conn)
 sizes=st[:,4];good=sizes[1:]>=45
 print('connected',conn,'regions',good.sum(),'maxsizes',sorted(sizes[1:][good],reverse=True)[:10], 'tiny',(sizes[1:]<45).sum(), 'saturation_pixels',mask.sum())
for width in (0,1,2):
 # morphological erosion 3x3 may remove path strokes, test connectivity
 er=cv2.erode(mask, cv2.getStructuringElement(cv2.MORPH_CROSS,(3,3)),iterations=width) if width else mask
 n,l,st,cent=cv2.connectedComponentsWithStats(er,8)
 print('erode',width, 'numreg',sum(st[1:,4]>=45),'biggest',sorted(st[1:,4],reverse=True)[:7]);
for classes in ('max','tight'):
 # quantize hue avoid crossing different colors; same actual arrow may shade slightly; good for diagnostic only
 hue=np.zeros((h,w),np.uint8)
 if classes=='max':
  hue[(r>=g)&(r>=b)]=1;hue[(g>r)&(g>=b)]=2;hue[(b>r)&(b>g)]=3
 else:
  # cv2 hue posterization 15deg
  hsv=cv2.cvtColor(im.astype('uint8'),cv2.COLOR_RGB2HSV);hue=(hsv[:,:,0]//15).astype('uint8')+1
 groups=[]
 for k in np.unique(hue[mask==1]):
  m=np.uint8((hue==k)&(mask==1))
  n,l,st,cent=cv2.connectedComponentsWithStats(m,8)
  groups += list(st[1:,4])
 print('color', classes,'reg >=45',sum(x>=45 for x in groups),'big >=5000',sum(x>=5000 for x in groups), 'top',sorted(groups,reverse=True)[:10])
n,l,st,cent=cv2.connectedComponentsWithStats(mask,8)
candidates=[]
for id in range(1,n):
  if st[id,4]<45:continue
  yy,xx=np.where(l==id)
  possible=[]
  for d,(dx,dy) in enumerate([(0,-1),(1,0),(0,1),(-1,0)]):
   clear=True
   if dx:
    for y in np.unique(yy):
     posx=xx[yy==y]
     end=posx.max() if dx>0 else posx.min()
     line=l[max(y0,y-1):min(y1,y+2), end+1:x1] if dx>0 else l[max(y0,y-1):min(y1,y+2),x0:end]
     if np.any((line!=0)&(line!=id)):
      clear=False; break
   else:
    for x in np.unique(xx):
     posy=yy[xx==x]
     end=posy.max() if dy>0 else posy.min()
     line=l[end+1:y1,max(x0,x-1):min(x1,x+2)] if dy>0 else l[y0:end,max(x0,x-1):min(x1,x+2)]
     if np.any((line!=0)&(line!=id)):
      clear=False; break
   if clear:possible.append('URDL'[d])
  if possible: candidates.append((id,st[id,4], possible, (st[id,0],st[id,1],st[id,2],st[id,3])))
print('candidate sweeps',(len(candidates)),candidates[:20])
